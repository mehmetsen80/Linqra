--
-- PostgreSQL database dump
--

\restrict 3ZuAg1mdX4e3qBrBIuw7ZHS6XECsgWbFEzmxigs4BC6Z8GrNCkAZsXXiIVMwTBW

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64),
    details_json text
);


ALTER TABLE public.admin_event_entity OWNER TO keycloak;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO keycloak;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO keycloak;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO keycloak;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config (
    id character varying(36) CONSTRAINT authenticator_id_not_null NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO keycloak;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) CONSTRAINT authenticator_config_authenticator_id_not_null NOT NULL,
    value text,
    name character varying(255) CONSTRAINT authenticator_config_name_not_null NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO keycloak;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO keycloak;

--
-- Name: client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO keycloak;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO keycloak;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO keycloak;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO keycloak;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) CONSTRAINT app_node_registrations_application_id_not_null NOT NULL,
    value integer,
    name character varying(255) CONSTRAINT app_node_registrations_name_not_null NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO keycloak;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope (
    id character varying(36) CONSTRAINT client_template_id_not_null NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO keycloak;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) CONSTRAINT client_template_attributes_template_id_not_null NOT NULL,
    value character varying(2048),
    name character varying(255) CONSTRAINT client_template_attributes_name_not_null NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO keycloak;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO keycloak;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) CONSTRAINT template_scope_mapping_template_id_not_null NOT NULL,
    role_id character varying(36) CONSTRAINT template_scope_mapping_role_id_not_null NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO keycloak;

--
-- Name: component; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO keycloak;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.component_config OWNER TO keycloak;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO keycloak;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer,
    version integer DEFAULT 0
);


ALTER TABLE public.credential OWNER TO keycloak;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO keycloak;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO keycloak;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO keycloak;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255),
    details_json_long_value text
);


ALTER TABLE public.event_entity OWNER TO keycloak;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024),
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


ALTER TABLE public.fed_user_attribute OWNER TO keycloak;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO keycloak;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO keycloak;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO keycloak;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO keycloak;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO keycloak;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO keycloak;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO keycloak;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO keycloak;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO keycloak;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO keycloak;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL,
    organization_id character varying(255),
    hide_on_login boolean DEFAULT false
);


ALTER TABLE public.identity_provider OWNER TO keycloak;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO keycloak;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO keycloak;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO keycloak;

--
-- Name: jgroups_ping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.jgroups_ping (
    address character varying(200) NOT NULL,
    name character varying(200),
    cluster_name character varying(200) NOT NULL,
    ip character varying(200) NOT NULL,
    coord boolean
);


ALTER TABLE public.jgroups_ping OWNER TO keycloak;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36),
    type integer DEFAULT 0 NOT NULL,
    description character varying(255)
);


ALTER TABLE public.keycloak_group OWNER TO keycloak;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false CONSTRAINT keycloak_role_application_role_not_null NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO keycloak;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO keycloak;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL,
    version integer DEFAULT 0
);


ALTER TABLE public.offline_client_session OWNER TO keycloak;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL,
    broker_session_id character varying(1024),
    version integer DEFAULT 0
);


ALTER TABLE public.offline_user_session OWNER TO keycloak;

--
-- Name: org; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.org (
    id character varying(255) NOT NULL,
    enabled boolean NOT NULL,
    realm_id character varying(255) NOT NULL,
    group_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(4000),
    alias character varying(255) NOT NULL,
    redirect_url character varying(2048)
);


ALTER TABLE public.org OWNER TO keycloak;

--
-- Name: org_domain; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.org_domain (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    verified boolean NOT NULL,
    org_id character varying(255) NOT NULL
);


ALTER TABLE public.org_domain OWNER TO keycloak;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO keycloak;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO keycloak;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO keycloak;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO keycloak;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO keycloak;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO keycloak;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO keycloak;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO keycloak;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO keycloak;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO keycloak;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO keycloak;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO keycloak;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO keycloak;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO keycloak;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO keycloak;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO keycloak;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO keycloak;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO keycloak;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server (
    id character varying(36) CONSTRAINT resource_server_client_id_not_null NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO keycloak;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO keycloak;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) CONSTRAINT resource_server_policy_resource_server_client_id_not_null NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO keycloak;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) CONSTRAINT resource_server_resource_resource_server_client_id_not_null NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO keycloak;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) CONSTRAINT resource_server_scope_resource_server_client_id_not_null NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO keycloak;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO keycloak;

--
-- Name: revoked_token; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.revoked_token (
    id character varying(255) NOT NULL,
    expire bigint NOT NULL
);


ALTER TABLE public.revoked_token OWNER TO keycloak;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO keycloak;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO keycloak;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO keycloak;

--
-- Name: server_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.server_config (
    server_config_key character varying(255) NOT NULL,
    value text NOT NULL,
    version integer DEFAULT 0
);


ALTER TABLE public.server_config OWNER TO keycloak;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


ALTER TABLE public.user_attribute OWNER TO keycloak;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO keycloak;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO keycloak;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO keycloak;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO keycloak;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO keycloak;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) CONSTRAINT user_federation_mapper_confi_user_federation_mapper_id_not_null NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO keycloak;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO keycloak;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    membership_type character varying(255) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO keycloak;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO keycloak;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO keycloak;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO keycloak;

--
-- Name: workflow_state; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.workflow_state (
    execution_id character varying(255) NOT NULL,
    resource_id character varying(255) NOT NULL,
    workflow_id character varying(255) NOT NULL,
    workflow_provider_id character varying(255),
    resource_type character varying(255),
    scheduled_step_id character varying(255),
    scheduled_step_timestamp bigint
);


ALTER TABLE public.workflow_state OWNER TO keycloak;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type, details_json) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
dee6f7b2-7f1b-4fc1-ac12-d2e3155eeb3b	\N	auth-cookie	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	067cc22b-8326-4b60-b59b-fa2ca639a9fd	2	10	f	\N	\N
89c45fdd-9cf5-45fb-977f-0d967a84e0a1	\N	auth-spnego	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	067cc22b-8326-4b60-b59b-fa2ca639a9fd	3	20	f	\N	\N
db605353-645e-4b01-a3e0-d97bc4c0fd40	\N	identity-provider-redirector	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	067cc22b-8326-4b60-b59b-fa2ca639a9fd	2	25	f	\N	\N
27a1b1b8-697f-4ce6-bb21-d05ceba39c3e	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	067cc22b-8326-4b60-b59b-fa2ca639a9fd	2	30	t	0a7a739e-0cae-44a3-8871-73f31280d609	\N
3e38d8f2-6ef6-4bd0-b81e-1b74b8d14bf9	\N	auth-username-password-form	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	0a7a739e-0cae-44a3-8871-73f31280d609	0	10	f	\N	\N
978c3fa8-cfc4-46c2-9814-febde7c44a60	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	0a7a739e-0cae-44a3-8871-73f31280d609	1	20	t	2ac32127-2ab0-40ba-86dc-55b7e0a10094	\N
5d809d9e-929b-4b14-82bd-f959e46aefe1	\N	conditional-user-configured	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2ac32127-2ab0-40ba-86dc-55b7e0a10094	0	10	f	\N	\N
09e41ef9-a83b-4c01-bd75-924b66cf15e0	\N	conditional-credential	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2ac32127-2ab0-40ba-86dc-55b7e0a10094	0	20	f	\N	72c1cc4b-3652-40d7-87cd-49893fd36633
1475701d-d254-41dd-9971-8e8288c6b23d	\N	auth-otp-form	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2ac32127-2ab0-40ba-86dc-55b7e0a10094	2	30	f	\N	\N
424fa9c8-965f-4fd7-bae0-1516ef999625	\N	webauthn-authenticator	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2ac32127-2ab0-40ba-86dc-55b7e0a10094	3	40	f	\N	\N
d4f71d13-6f2b-4e4e-99d3-0afc351a150e	\N	auth-recovery-authn-code-form	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2ac32127-2ab0-40ba-86dc-55b7e0a10094	3	50	f	\N	\N
37592778-35e4-4cba-873c-eacb2012a62a	\N	direct-grant-validate-username	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	05ed9dde-a791-4d92-ba9c-65e0d1ddd305	0	10	f	\N	\N
90ec329e-5f5f-492d-b2a4-4f7524375b3d	\N	direct-grant-validate-password	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	05ed9dde-a791-4d92-ba9c-65e0d1ddd305	0	20	f	\N	\N
b355759d-7bf5-40b3-ad99-21c5dff3bb73	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	05ed9dde-a791-4d92-ba9c-65e0d1ddd305	1	30	t	5ae6b781-56f2-49b9-96e1-e2a45bd5c866	\N
4a573bd3-4d27-4bd9-bdee-233a9c54685e	\N	conditional-user-configured	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	5ae6b781-56f2-49b9-96e1-e2a45bd5c866	0	10	f	\N	\N
3420019f-d554-4794-b0e2-aa23b90a364e	\N	direct-grant-validate-otp	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	5ae6b781-56f2-49b9-96e1-e2a45bd5c866	0	20	f	\N	\N
35277344-dba7-4c23-a9d0-c335685030e0	\N	registration-page-form	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	eddeb59f-2cfa-43b4-98bd-a28132ec8573	0	10	t	4407c1e8-ba6a-4906-85af-f826a0333733	\N
1bf9c158-b89c-4946-9dff-c07e5233fc0c	\N	registration-user-creation	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	4407c1e8-ba6a-4906-85af-f826a0333733	0	20	f	\N	\N
c96f04c2-7ddf-48be-b5b1-329eeebd52c0	\N	registration-password-action	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	4407c1e8-ba6a-4906-85af-f826a0333733	0	50	f	\N	\N
627da7a6-b9e1-49d5-86e7-2ffb6e65d972	\N	registration-recaptcha-action	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	4407c1e8-ba6a-4906-85af-f826a0333733	3	60	f	\N	\N
d1ad4641-a3ec-4cb3-95ea-deeb29277f0c	\N	registration-terms-and-conditions	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	4407c1e8-ba6a-4906-85af-f826a0333733	3	70	f	\N	\N
bd3cc0f2-d997-4028-83d6-088b95c1d698	\N	reset-credentials-choose-user	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	bcd57c27-8337-4762-834b-38901958e885	0	10	f	\N	\N
ce9f6038-e304-4043-be5c-643a198068a6	\N	reset-credential-email	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	bcd57c27-8337-4762-834b-38901958e885	0	20	f	\N	\N
0755bb16-9dfa-42d4-93cd-5b279c6d3a18	\N	reset-password	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	bcd57c27-8337-4762-834b-38901958e885	0	30	f	\N	\N
d602215c-1a98-4332-b170-a8d5dbaefbd0	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	bcd57c27-8337-4762-834b-38901958e885	1	40	t	73740c3a-9257-4e97-8495-c6350fc589de	\N
39e3e399-7d48-432e-920a-3b6be879ed33	\N	conditional-user-configured	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	73740c3a-9257-4e97-8495-c6350fc589de	0	10	f	\N	\N
9c125a89-2f60-40e7-bc90-8850b85afd54	\N	reset-otp	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	73740c3a-9257-4e97-8495-c6350fc589de	0	20	f	\N	\N
58b1c0b8-a324-4745-8f2a-76b3fb850b26	\N	client-secret	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2f6cc1e2-d37b-4a08-8442-7ba42bc2a4d8	2	10	f	\N	\N
3444ca92-7451-435b-b253-ab7a5b0bbb0d	\N	client-jwt	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2f6cc1e2-d37b-4a08-8442-7ba42bc2a4d8	2	20	f	\N	\N
5ef23930-95ec-4e64-b4da-8a5550ed71b2	\N	client-secret-jwt	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2f6cc1e2-d37b-4a08-8442-7ba42bc2a4d8	2	30	f	\N	\N
2d06cee6-43cf-4db2-a9a4-a4da44fa01c5	\N	client-x509	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	2f6cc1e2-d37b-4a08-8442-7ba42bc2a4d8	2	40	f	\N	\N
fbc32185-ed45-4d7a-bf37-47577ee0d04f	\N	idp-review-profile	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	4773322d-ee6d-4a8f-ad31-6612a80030f1	0	10	f	\N	e885bc96-d217-435f-942a-1071283d40c8
9dce4bad-95e1-4bdd-9507-a51eab8c5536	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	4773322d-ee6d-4a8f-ad31-6612a80030f1	0	20	t	e7e4af31-5a9d-4674-b995-4bde845893fb	\N
51546d79-9ffc-4f47-ac3b-f3281972c7a5	\N	idp-create-user-if-unique	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e7e4af31-5a9d-4674-b995-4bde845893fb	2	10	f	\N	43e4660c-6dac-43a1-bb04-0730e2e51e22
3cec3a83-1831-460d-bf38-5631e5b718c3	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e7e4af31-5a9d-4674-b995-4bde845893fb	2	20	t	64e2d3d9-acb4-4f96-a1b0-506d71cb9c85	\N
08a5b429-73cb-4848-9492-c88a442f78d7	\N	idp-confirm-link	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	64e2d3d9-acb4-4f96-a1b0-506d71cb9c85	0	10	f	\N	\N
28ba0477-cf2e-4c17-91cc-ba0c55166b5c	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	64e2d3d9-acb4-4f96-a1b0-506d71cb9c85	0	20	t	6b78d4d2-c225-48df-b1c7-b80990f10de0	\N
ae7c81ef-9060-448b-b22c-10c4ef8999df	\N	idp-email-verification	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	6b78d4d2-c225-48df-b1c7-b80990f10de0	2	10	f	\N	\N
f7f24280-6d53-4d9e-aeb0-2512db3f77a9	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	6b78d4d2-c225-48df-b1c7-b80990f10de0	2	20	t	ae7eadfe-1ea8-4e6c-97b9-78683fd05c55	\N
5516374b-d458-4b8d-b42f-e0a48effeabf	\N	idp-username-password-form	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	ae7eadfe-1ea8-4e6c-97b9-78683fd05c55	0	10	f	\N	\N
189e1a26-c20b-4e51-a7e2-6c011976f07b	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	ae7eadfe-1ea8-4e6c-97b9-78683fd05c55	1	20	t	cfe0ffeb-e385-4efc-8722-37acc9c9428d	\N
9dad0bdc-f49c-4d7b-bd0e-858fd7540cff	\N	conditional-user-configured	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	cfe0ffeb-e385-4efc-8722-37acc9c9428d	0	10	f	\N	\N
fde7c6d6-0742-4779-8fba-b006f3256ec7	\N	conditional-credential	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	cfe0ffeb-e385-4efc-8722-37acc9c9428d	0	20	f	\N	96c1b774-9feb-4c53-b2c9-9ff045b49cc5
632b7810-3ec2-487a-9c40-47c97e3a621a	\N	auth-otp-form	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	cfe0ffeb-e385-4efc-8722-37acc9c9428d	2	30	f	\N	\N
9a8da2a7-fe5e-4bfb-9c93-f2cf882a21ff	\N	webauthn-authenticator	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	cfe0ffeb-e385-4efc-8722-37acc9c9428d	3	40	f	\N	\N
e8b9a81c-518f-415c-817e-f4ecee10232f	\N	auth-recovery-authn-code-form	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	cfe0ffeb-e385-4efc-8722-37acc9c9428d	3	50	f	\N	\N
74264ac6-2a1a-4c42-a521-3f001bc73859	\N	http-basic-authenticator	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	09a3ef2f-78c1-47d4-be75-95a0b53638d5	0	10	f	\N	\N
2868a156-885a-4251-8a4d-ea0493cf6d4b	\N	docker-http-basic-authenticator	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	38fd801f-4567-4956-b0df-fa5af6202886	0	10	f	\N	\N
8dcb89c9-26f6-48ee-841e-1ef562cb720e	\N	idp-email-verification	fa932e74-3d72-4028-b476-3620d13514ce	830a2719-f524-4697-82ce-66e1c5439159	2	10	f	\N	\N
0d54858e-949a-48f2-9aee-de50a7731bbf	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	830a2719-f524-4697-82ce-66e1c5439159	2	20	t	56592118-0a86-4c17-99a1-48bf906822b2	\N
b784e079-0049-4682-bf64-a44bcea58c87	\N	conditional-user-configured	fa932e74-3d72-4028-b476-3620d13514ce	525e3704-b2b2-4b8a-8598-c967c99f3ceb	0	10	f	\N	\N
518c4f96-9d72-44cd-a2fb-6d171a217db4	\N	auth-otp-form	fa932e74-3d72-4028-b476-3620d13514ce	525e3704-b2b2-4b8a-8598-c967c99f3ceb	2	20	f	\N	\N
fca3480a-1ca6-4055-a66c-6ccdf862bf43	\N	webauthn-authenticator	fa932e74-3d72-4028-b476-3620d13514ce	525e3704-b2b2-4b8a-8598-c967c99f3ceb	3	30	f	\N	\N
a3f73417-a6f0-4c06-a29e-ff702b7cf466	\N	auth-recovery-authn-code-form	fa932e74-3d72-4028-b476-3620d13514ce	525e3704-b2b2-4b8a-8598-c967c99f3ceb	3	40	f	\N	\N
3bf94a80-82d5-4950-b528-73074224c444	\N	conditional-user-configured	fa932e74-3d72-4028-b476-3620d13514ce	cfb55555-8831-40d1-ad15-edd91a28017b	0	10	f	\N	\N
af54bf66-a0be-42db-9e19-dd3c926bc560	\N	organization	fa932e74-3d72-4028-b476-3620d13514ce	cfb55555-8831-40d1-ad15-edd91a28017b	2	20	f	\N	\N
f182a44e-28a9-485c-adac-28ca803a380d	\N	conditional-user-configured	fa932e74-3d72-4028-b476-3620d13514ce	fc6f6d14-cb6e-4065-9050-d41f4d709fcb	0	10	f	\N	\N
70ad56ce-c73e-44eb-a652-b144e737edcc	\N	direct-grant-validate-otp	fa932e74-3d72-4028-b476-3620d13514ce	fc6f6d14-cb6e-4065-9050-d41f4d709fcb	0	20	f	\N	\N
06ffeb68-0a29-4b8a-b05e-0442e766abe1	\N	conditional-user-configured	fa932e74-3d72-4028-b476-3620d13514ce	13df57df-c15c-44e0-b65b-e072ef53371b	0	10	f	\N	\N
3426ea32-45bf-41ec-bfe2-44fd746b0207	\N	idp-add-organization-member	fa932e74-3d72-4028-b476-3620d13514ce	13df57df-c15c-44e0-b65b-e072ef53371b	0	20	f	\N	\N
8042e6b7-073c-4fcc-825d-d08aee990954	\N	conditional-user-configured	fa932e74-3d72-4028-b476-3620d13514ce	9d60f267-e882-4298-9e5a-b54d5cbcb403	0	10	f	\N	\N
6b88dc22-4651-4a10-992c-342ab67350b8	\N	auth-otp-form	fa932e74-3d72-4028-b476-3620d13514ce	9d60f267-e882-4298-9e5a-b54d5cbcb403	2	20	f	\N	\N
fcbf11f4-1edc-4edc-b1e6-c1ef7399f688	\N	webauthn-authenticator	fa932e74-3d72-4028-b476-3620d13514ce	9d60f267-e882-4298-9e5a-b54d5cbcb403	3	30	f	\N	\N
15bf08b8-71c3-417f-b361-ef2a98faa518	\N	auth-recovery-authn-code-form	fa932e74-3d72-4028-b476-3620d13514ce	9d60f267-e882-4298-9e5a-b54d5cbcb403	3	40	f	\N	\N
302e9da0-ee15-4531-9318-1cf27dd29617	\N	idp-confirm-link	fa932e74-3d72-4028-b476-3620d13514ce	fad70cbb-6178-46de-8773-a1e80ea9ebf8	0	10	f	\N	\N
e7e41f7f-6811-43bd-93c5-a6096388a579	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	fad70cbb-6178-46de-8773-a1e80ea9ebf8	0	20	t	830a2719-f524-4697-82ce-66e1c5439159	\N
c5deb9ee-834e-4fab-9548-43e130d725e2	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	796dbe87-2c0a-4891-b165-99198e92f12a	1	10	t	cfb55555-8831-40d1-ad15-edd91a28017b	\N
fbdd8335-d345-46e5-9833-8b7ae496f62d	\N	conditional-user-configured	fa932e74-3d72-4028-b476-3620d13514ce	c052c1ab-da9b-47cd-a5ca-66c7259f4a11	0	10	f	\N	\N
6d40c25d-1466-4e6a-8f63-c96a4a98fee4	\N	reset-otp	fa932e74-3d72-4028-b476-3620d13514ce	c052c1ab-da9b-47cd-a5ca-66c7259f4a11	0	20	f	\N	\N
df5a01b3-f3ec-4876-ba12-e4d12bf0a10f	\N	idp-create-user-if-unique	fa932e74-3d72-4028-b476-3620d13514ce	869ab8e5-4894-4909-ba27-f933bf7fa671	2	10	f	\N	ee64f232-cf93-4881-932d-6e8dc091210e
1aa9fc68-37fd-4cf1-ad26-5d16a67f7a33	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	869ab8e5-4894-4909-ba27-f933bf7fa671	2	20	t	fad70cbb-6178-46de-8773-a1e80ea9ebf8	\N
dcc545e1-a5ed-49ac-94f5-d486ffb8cfcd	\N	idp-username-password-form	fa932e74-3d72-4028-b476-3620d13514ce	56592118-0a86-4c17-99a1-48bf906822b2	0	10	f	\N	\N
280ab757-6da9-4d6e-bda6-8c039ee42043	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	56592118-0a86-4c17-99a1-48bf906822b2	1	20	t	9d60f267-e882-4298-9e5a-b54d5cbcb403	\N
7dab4f87-667e-463c-a247-13e64d93c20d	\N	auth-cookie	fa932e74-3d72-4028-b476-3620d13514ce	803ca1fd-289a-4c54-b30c-04718c0df84e	2	10	f	\N	\N
bfafcd99-9ece-4faa-82cd-303421c5c541	\N	auth-spnego	fa932e74-3d72-4028-b476-3620d13514ce	803ca1fd-289a-4c54-b30c-04718c0df84e	3	20	f	\N	\N
bb5409c1-1294-420c-82d9-a79ff10e4f68	\N	identity-provider-redirector	fa932e74-3d72-4028-b476-3620d13514ce	803ca1fd-289a-4c54-b30c-04718c0df84e	2	25	f	\N	\N
e603427b-48c3-48c6-9a8e-a863a2986500	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	803ca1fd-289a-4c54-b30c-04718c0df84e	2	26	t	796dbe87-2c0a-4891-b165-99198e92f12a	\N
0c2c741f-6ced-4296-ab7e-9dbe61da9395	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	803ca1fd-289a-4c54-b30c-04718c0df84e	2	30	t	31b0319e-585e-4dc3-bbe3-afb7aa5f2d7b	\N
7091310e-3954-4583-8617-aee142dfb64a	\N	client-secret	fa932e74-3d72-4028-b476-3620d13514ce	68c9a0f5-5a94-41de-994e-1d42d0bed85f	2	10	f	\N	\N
f7cabea9-5565-478b-a3c4-529f8a38f85d	\N	client-jwt	fa932e74-3d72-4028-b476-3620d13514ce	68c9a0f5-5a94-41de-994e-1d42d0bed85f	2	20	f	\N	\N
e5e01acc-6c30-45f3-b8cd-d36333fca36e	\N	client-secret-jwt	fa932e74-3d72-4028-b476-3620d13514ce	68c9a0f5-5a94-41de-994e-1d42d0bed85f	2	30	f	\N	\N
03c628b5-b174-4c42-b2dd-e925ce64a969	\N	client-x509	fa932e74-3d72-4028-b476-3620d13514ce	68c9a0f5-5a94-41de-994e-1d42d0bed85f	2	40	f	\N	\N
960020ab-7820-490b-8458-14601184a5ae	\N	direct-grant-validate-username	fa932e74-3d72-4028-b476-3620d13514ce	90c1ffd5-ef3f-44b6-928f-a5329357ae09	0	10	f	\N	\N
0f446f54-afc1-4421-8049-61f2d2238a14	\N	direct-grant-validate-password	fa932e74-3d72-4028-b476-3620d13514ce	90c1ffd5-ef3f-44b6-928f-a5329357ae09	0	20	f	\N	\N
ce4b9a18-2bf9-4509-9951-8e3e7f9d6f5b	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	90c1ffd5-ef3f-44b6-928f-a5329357ae09	1	30	t	fc6f6d14-cb6e-4065-9050-d41f4d709fcb	\N
f5335b4d-780d-4c72-a222-c1178db599e2	\N	docker-http-basic-authenticator	fa932e74-3d72-4028-b476-3620d13514ce	0b39e949-21bd-421d-b721-5a3b57f6c368	0	10	f	\N	\N
edb78f0e-adb3-4108-bbb2-064293fb4ddb	\N	idp-review-profile	fa932e74-3d72-4028-b476-3620d13514ce	8684d5c1-cd79-4cf7-82cb-1180982b96f4	0	10	f	\N	4d2324d1-9a0c-4126-a538-026645632bcf
b4d5e325-b481-427f-af05-9f231ffe604a	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	8684d5c1-cd79-4cf7-82cb-1180982b96f4	0	20	t	869ab8e5-4894-4909-ba27-f933bf7fa671	\N
e4b47804-9b11-407d-9b6f-2847e2356092	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	8684d5c1-cd79-4cf7-82cb-1180982b96f4	1	50	t	13df57df-c15c-44e0-b65b-e072ef53371b	\N
f74d13bf-aff3-4d28-a359-a772bf5d3389	\N	auth-username-password-form	fa932e74-3d72-4028-b476-3620d13514ce	31b0319e-585e-4dc3-bbe3-afb7aa5f2d7b	0	10	f	\N	\N
59133746-ddb5-41a7-be12-e50d87eda819	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	31b0319e-585e-4dc3-bbe3-afb7aa5f2d7b	1	20	t	525e3704-b2b2-4b8a-8598-c967c99f3ceb	\N
d403887d-8f91-434e-81cb-48ec910d7e2c	\N	registration-page-form	fa932e74-3d72-4028-b476-3620d13514ce	adc517ec-2579-46f0-890a-0767e4164933	0	10	t	b73563ad-2bef-4702-8380-4ae25ac72bbf	\N
2f5b0c68-ea30-47ea-835d-ad781fe98684	\N	registration-user-creation	fa932e74-3d72-4028-b476-3620d13514ce	b73563ad-2bef-4702-8380-4ae25ac72bbf	0	20	f	\N	\N
e8380e10-b821-433a-b5d4-e8c8edf75585	\N	registration-password-action	fa932e74-3d72-4028-b476-3620d13514ce	b73563ad-2bef-4702-8380-4ae25ac72bbf	0	50	f	\N	\N
f8f5b78e-f885-4308-a07b-196a85fc4ff1	\N	registration-recaptcha-action	fa932e74-3d72-4028-b476-3620d13514ce	b73563ad-2bef-4702-8380-4ae25ac72bbf	3	60	f	\N	\N
d4704602-bdac-4d07-bac0-002fb49023f7	\N	registration-terms-and-conditions	fa932e74-3d72-4028-b476-3620d13514ce	b73563ad-2bef-4702-8380-4ae25ac72bbf	3	70	f	\N	\N
c922e1f3-2078-48c5-941e-6fa71e65bcac	\N	reset-credentials-choose-user	fa932e74-3d72-4028-b476-3620d13514ce	d3cab41a-a046-47fa-82bd-102f2eaa30bd	0	10	f	\N	\N
97324541-5947-4dab-9e21-2f1c15e5825b	\N	reset-credential-email	fa932e74-3d72-4028-b476-3620d13514ce	d3cab41a-a046-47fa-82bd-102f2eaa30bd	0	20	f	\N	\N
9a945c78-e349-48d4-8cbf-25540885b807	\N	reset-password	fa932e74-3d72-4028-b476-3620d13514ce	d3cab41a-a046-47fa-82bd-102f2eaa30bd	0	30	f	\N	\N
1098c913-392b-4e63-9bb7-589cf27127c4	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	d3cab41a-a046-47fa-82bd-102f2eaa30bd	1	40	t	c052c1ab-da9b-47cd-a5ca-66c7259f4a11	\N
d105cc48-7aac-4ea3-9ea7-e995dbcf4ae2	\N	http-basic-authenticator	fa932e74-3d72-4028-b476-3620d13514ce	27ac7dcb-b4d6-4213-bcfc-58283b2d3f4f	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
067cc22b-8326-4b60-b59b-fa2ca639a9fd	browser	Browser based authentication	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	t	t
0a7a739e-0cae-44a3-8871-73f31280d609	forms	Username, password, otp and other auth forms.	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
2ac32127-2ab0-40ba-86dc-55b7e0a10094	Browser - Conditional 2FA	Flow to determine if any 2FA is required for the authentication	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
05ed9dde-a791-4d92-ba9c-65e0d1ddd305	direct grant	OpenID Connect Resource Owner Grant	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	t	t
5ae6b781-56f2-49b9-96e1-e2a45bd5c866	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
eddeb59f-2cfa-43b4-98bd-a28132ec8573	registration	Registration flow	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	t	t
4407c1e8-ba6a-4906-85af-f826a0333733	registration form	Registration form	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	form-flow	f	t
bcd57c27-8337-4762-834b-38901958e885	reset credentials	Reset credentials for a user if they forgot their password or something	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	t	t
73740c3a-9257-4e97-8495-c6350fc589de	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
2f6cc1e2-d37b-4a08-8442-7ba42bc2a4d8	clients	Base authentication for clients	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	client-flow	t	t
4773322d-ee6d-4a8f-ad31-6612a80030f1	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	t	t
e7e4af31-5a9d-4674-b995-4bde845893fb	User creation or linking	Flow for the existing/non-existing user alternatives	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
64e2d3d9-acb4-4f96-a1b0-506d71cb9c85	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
6b78d4d2-c225-48df-b1c7-b80990f10de0	Account verification options	Method with which to verity the existing account	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
ae7eadfe-1ea8-4e6c-97b9-78683fd05c55	Verify Existing Account by Re-authentication	Reauthentication of existing account	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
cfe0ffeb-e385-4efc-8722-37acc9c9428d	First broker login - Conditional 2FA	Flow to determine if any 2FA is required for the authentication	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	f	t
09a3ef2f-78c1-47d4-be75-95a0b53638d5	saml ecp	SAML ECP Profile Authentication Flow	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	t	t
38fd801f-4567-4956-b0df-fa5af6202886	docker auth	Used by Docker clients to authenticate against the IDP	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	basic-flow	t	t
830a2719-f524-4697-82ce-66e1c5439159	Account verification options	Method with which to verity the existing account	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
525e3704-b2b2-4b8a-8598-c967c99f3ceb	Browser - Conditional 2FA	Flow to determine if any 2FA is required for the authentication	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
cfb55555-8831-40d1-ad15-edd91a28017b	Browser - Conditional Organization	Flow to determine if the organization identity-first login is to be used	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
fc6f6d14-cb6e-4065-9050-d41f4d709fcb	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
13df57df-c15c-44e0-b65b-e072ef53371b	First Broker Login - Conditional Organization	Flow to determine if the authenticator that adds organization members is to be used	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
9d60f267-e882-4298-9e5a-b54d5cbcb403	First broker login - Conditional 2FA	Flow to determine if any 2FA is required for the authentication	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
fad70cbb-6178-46de-8773-a1e80ea9ebf8	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
796dbe87-2c0a-4891-b165-99198e92f12a	Organization	\N	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
c052c1ab-da9b-47cd-a5ca-66c7259f4a11	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
869ab8e5-4894-4909-ba27-f933bf7fa671	User creation or linking	Flow for the existing/non-existing user alternatives	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
56592118-0a86-4c17-99a1-48bf906822b2	Verify Existing Account by Re-authentication	Reauthentication of existing account	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
803ca1fd-289a-4c54-b30c-04718c0df84e	browser	Browser based authentication	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	t	t
68c9a0f5-5a94-41de-994e-1d42d0bed85f	clients	Base authentication for clients	fa932e74-3d72-4028-b476-3620d13514ce	client-flow	t	t
90c1ffd5-ef3f-44b6-928f-a5329357ae09	direct grant	OpenID Connect Resource Owner Grant	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	t	t
0b39e949-21bd-421d-b721-5a3b57f6c368	docker auth	Used by Docker clients to authenticate against the IDP	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	t	t
8684d5c1-cd79-4cf7-82cb-1180982b96f4	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	t	t
31b0319e-585e-4dc3-bbe3-afb7aa5f2d7b	forms	Username, password, otp and other auth forms.	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	f	t
adc517ec-2579-46f0-890a-0767e4164933	registration	Registration flow	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	t	t
b73563ad-2bef-4702-8380-4ae25ac72bbf	registration form	Registration form	fa932e74-3d72-4028-b476-3620d13514ce	form-flow	f	t
d3cab41a-a046-47fa-82bd-102f2eaa30bd	reset credentials	Reset credentials for a user if they forgot their password or something	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	t	t
27ac7dcb-b4d6-4213-bcfc-58283b2d3f4f	saml ecp	SAML ECP Profile Authentication Flow	fa932e74-3d72-4028-b476-3620d13514ce	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
72c1cc4b-3652-40d7-87cd-49893fd36633	browser-conditional-credential	064b05aa-b123-4727-a3ba-cbcb0f63c5d5
e885bc96-d217-435f-942a-1071283d40c8	review profile config	064b05aa-b123-4727-a3ba-cbcb0f63c5d5
43e4660c-6dac-43a1-bb04-0730e2e51e22	create unique user config	064b05aa-b123-4727-a3ba-cbcb0f63c5d5
96c1b774-9feb-4c53-b2c9-9ff045b49cc5	first-broker-login-conditional-credential	064b05aa-b123-4727-a3ba-cbcb0f63c5d5
ee64f232-cf93-4881-932d-6e8dc091210e	create unique user config	fa932e74-3d72-4028-b476-3620d13514ce
4d2324d1-9a0c-4126-a538-026645632bcf	review profile config	fa932e74-3d72-4028-b476-3620d13514ce
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
43e4660c-6dac-43a1-bb04-0730e2e51e22	false	require.password.update.after.registration
72c1cc4b-3652-40d7-87cd-49893fd36633	webauthn-passwordless	credentials
96c1b774-9feb-4c53-b2c9-9ff045b49cc5	webauthn-passwordless	credentials
e885bc96-d217-435f-942a-1071283d40c8	missing	update.profile.on.first.login
4d2324d1-9a0c-4126-a538-026645632bcf	missing	update.profile.on.first.login
ee64f232-cf93-4881-932d-6e8dc091210e	false	require.password.update.after.registration
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
14d66edd-004a-4fd0-af78-44f38b17dd06	t	f	master-realm	0	f	\N	\N	t	\N	f	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
e685bf33-6dc9-45b6-b45e-0613070a3f57	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
43b0209c-b0f6-48fd-b331-172944afaab9	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
06330188-1212-410f-8c88-9995499f332e	t	f	broker	0	f	\N	\N	t	\N	f	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
8395b40e-acfd-4834-b2bd-605b68e96a3c	t	t	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
3f322b29-20df-4448-b44a-3b9f8f753b16	t	t	admin-cli	0	t	\N	\N	f	\N	f	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	f	realm-management	0	f	\N	\N	t	\N	f	fa932e74-3d72-4028-b476-3620d13514ce	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	t	t	security-admin-console	0	t	\N	/admin/Linqra/console/	f	\N	f	fa932e74-3d72-4028-b476-3620d13514ce	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	f	Linqra-realm	0	f	\N	\N	t	\N	f	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N	0	f	f	Linqra Realm	f	client-secret	\N	\N	\N	t	f	f	f
a64e78ff-429f-461c-85ca-11095df7667f	t	f	account	0	t	\N	/realms/Linqra/account/	f	\N	f	fa932e74-3d72-4028-b476-3620d13514ce	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	t	f	account-console	0	t	\N	/realms/Linqra/account/	f	\N	f	fa932e74-3d72-4028-b476-3620d13514ce	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
cd6b3799-4945-4098-bde9-ca33bbcb3597	t	t	admin-cli	0	t	\N	\N	f	\N	f	fa932e74-3d72-4028-b476-3620d13514ce	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
be4928ae-99f3-4bd5-81a4-9fecedc0340c	t	f	broker	0	f	\N	\N	t	\N	f	fa932e74-3d72-4028-b476-3620d13514ce	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
c6f5ede9-6791-43d3-8430-f485361bf7d5	t	t	linqra-gateway-client	0	f	HrjvST9kAZYQXoLP8Wn3g012Ui7Loqah	http://localhost:3000	f	https://localhost:3000	f	fa932e74-3d72-4028-b476-3620d13514ce	openid-connect	-1	t	f	Linqra Gateway Client	t	client-secret	http://localhost:3000	Linqra Gateway Client	\N	t	f	f	t
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
e685bf33-6dc9-45b6-b45e-0613070a3f57	post.logout.redirect.uris	+
43b0209c-b0f6-48fd-b331-172944afaab9	post.logout.redirect.uris	+
43b0209c-b0f6-48fd-b331-172944afaab9	pkce.code.challenge.method	S256
8395b40e-acfd-4834-b2bd-605b68e96a3c	post.logout.redirect.uris	+
8395b40e-acfd-4834-b2bd-605b68e96a3c	pkce.code.challenge.method	S256
8395b40e-acfd-4834-b2bd-605b68e96a3c	client.use.lightweight.access.token.enabled	true
3f322b29-20df-4448-b44a-3b9f8f753b16	client.use.lightweight.access.token.enabled	true
a64e78ff-429f-461c-85ca-11095df7667f	realm_client	false
a64e78ff-429f-461c-85ca-11095df7667f	post.logout.redirect.uris	+
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	realm_client	false
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	post.logout.redirect.uris	+
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	pkce.code.challenge.method	S256
cd6b3799-4945-4098-bde9-ca33bbcb3597	realm_client	false
cd6b3799-4945-4098-bde9-ca33bbcb3597	client.use.lightweight.access.token.enabled	true
cd6b3799-4945-4098-bde9-ca33bbcb3597	post.logout.redirect.uris	+
be4928ae-99f3-4bd5-81a4-9fecedc0340c	realm_client	true
be4928ae-99f3-4bd5-81a4-9fecedc0340c	post.logout.redirect.uris	+
c6f5ede9-6791-43d3-8430-f485361bf7d5	realm_client	false
c6f5ede9-6791-43d3-8430-f485361bf7d5	oidc.ciba.grant.enabled	false
c6f5ede9-6791-43d3-8430-f485361bf7d5	backchannel.logout.session.required	true
c6f5ede9-6791-43d3-8430-f485361bf7d5	standard.token.exchange.enabled	false
c6f5ede9-6791-43d3-8430-f485361bf7d5	oauth2.device.authorization.grant.enabled	false
c6f5ede9-6791-43d3-8430-f485361bf7d5	backchannel.logout.revoke.offline.tokens	false
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	realm_client	true
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	post.logout.redirect.uris	+
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	realm_client	false
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	client.use.lightweight.access.token.enabled	true
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	post.logout.redirect.uris	+
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	pkce.code.challenge.method	S256
c6f5ede9-6791-43d3-8430-f485361bf7d5	client.secret.creation.time	1759689834
c6f5ede9-6791-43d3-8430-f485361bf7d5	dpop.bound.access.tokens	false
c6f5ede9-6791-43d3-8430-f485361bf7d5	display.on.consent.screen	false
c6f5ede9-6791-43d3-8430-f485361bf7d5	frontchannel.logout.session.required	true
c6f5ede9-6791-43d3-8430-f485361bf7d5	post.logout.redirect.uris	http://localhost:3000/login,https://localhost:3000/login
c6f5ede9-6791-43d3-8430-f485361bf7d5	redirect.uris	http://localhost:3000/*
c6f5ede9-6791-43d3-8430-f485361bf7d5	client.secret	VPbfqJZiyMDsyIdXxHPpfkw8HDqkg0uhdA9mmjQQWto=
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
19b176e1-4a7e-42be-8de5-6407f497c093	offline_access	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect built-in scope: offline_access	openid-connect
b53929e1-a35f-4ce5-9657-da1a05edd3e5	role_list	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	SAML role list	saml
5499f689-3ad8-47f1-8442-0fde64fdc8ac	saml_organization	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	Organization Membership	saml
eab31880-af7f-4af2-83d8-b69977819fad	profile	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect built-in scope: profile	openid-connect
e3f1ad84-d45f-4ef0-b18f-767339bf436e	email	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect built-in scope: email	openid-connect
982f6961-08bd-4741-acaa-d0444f1d1f90	address	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect built-in scope: address	openid-connect
e0f3bf3c-84b1-4c54-972c-a1968fffe728	phone	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect built-in scope: phone	openid-connect
4e78c483-16fc-4c51-a8f7-1c906bd42e91	roles	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect scope for add user roles to the access token	openid-connect
6f111df2-7083-4774-a033-bd644b61b48e	web-origins	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect scope for add allowed web origins to the access token	openid-connect
bbb3bc76-0f3f-4988-9df6-67713326a19f	microprofile-jwt	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	Microprofile - JWT built-in scope	openid-connect
955521bd-156f-4ade-a60a-036f859c9600	acr	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
a38bb110-7d1c-433e-a5b9-04197257357c	basic	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	OpenID Connect scope for add all basic claims to the token	openid-connect
d59eaa29-cc6d-458b-929f-7a298bf3960d	service_account	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	Specific scope for a client enabled for service accounts	openid-connect
3f969fa3-d862-4656-835e-07ea2f6f2c5e	organization	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	Additional claims about the organization a subject belongs to	openid-connect
0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	basic	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect scope for add all basic claims to the token	openid-connect
1267b092-d449-4b01-8bcc-dfcbd2763276	service_account	fa932e74-3d72-4028-b476-3620d13514ce	Specific scope for a client enabled for service accounts	openid-connect
d729010f-7c64-4a75-9eae-71f211ae4de2	profile	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect built-in scope: profile	openid-connect
943f5b4d-0bb5-4864-bace-22399ada546b	microprofile-jwt	fa932e74-3d72-4028-b476-3620d13514ce	Microprofile - JWT built-in scope	openid-connect
79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	organization	fa932e74-3d72-4028-b476-3620d13514ce	Additional claims about the organization a subject belongs to	openid-connect
6a4f95f0-80dc-4ca3-92e2-bd44b229837b	role_list	fa932e74-3d72-4028-b476-3620d13514ce	SAML role list	saml
9e9fc66a-2d58-4305-b20f-35a78aba8e23	gateway.read	fa932e74-3d72-4028-b476-3620d13514ce	To read the gateway end points	openid-connect
9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	phone	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect built-in scope: phone	openid-connect
42a8e654-6d1e-48e7-806d-2c72dc42c30d	saml_organization	fa932e74-3d72-4028-b476-3620d13514ce	Organization Membership	saml
1538aa9f-9009-4e70-b7fc-626af0cebfb2	email	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect built-in scope: email	openid-connect
82460a4f-02d3-4320-b9df-2d124ab1a3ff	address	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect built-in scope: address	openid-connect
59b64ca7-8476-4387-a6d1-946cb16bc586	acr	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
4d0a91b8-6958-4930-997c-83bf8b67bc34	offline_access	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect built-in scope: offline_access	openid-connect
b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	roles	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect scope for add user roles to the access token	openid-connect
72a2873f-bbb0-4ede-92d4-a6a541ee07e8	web-origins	fa932e74-3d72-4028-b476-3620d13514ce	OpenID Connect scope for add allowed web origins to the access token	openid-connect
6fe2d901-9820-4971-a3a9-7990f11d8523	teams.scope	fa932e74-3d72-4028-b476-3620d13514ce	Restricts access to specific teams	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
19b176e1-4a7e-42be-8de5-6407f497c093	true	display.on.consent.screen
19b176e1-4a7e-42be-8de5-6407f497c093	${offlineAccessScopeConsentText}	consent.screen.text
b53929e1-a35f-4ce5-9657-da1a05edd3e5	true	display.on.consent.screen
b53929e1-a35f-4ce5-9657-da1a05edd3e5	${samlRoleListScopeConsentText}	consent.screen.text
5499f689-3ad8-47f1-8442-0fde64fdc8ac	false	display.on.consent.screen
eab31880-af7f-4af2-83d8-b69977819fad	true	display.on.consent.screen
eab31880-af7f-4af2-83d8-b69977819fad	${profileScopeConsentText}	consent.screen.text
eab31880-af7f-4af2-83d8-b69977819fad	true	include.in.token.scope
e3f1ad84-d45f-4ef0-b18f-767339bf436e	true	display.on.consent.screen
e3f1ad84-d45f-4ef0-b18f-767339bf436e	${emailScopeConsentText}	consent.screen.text
e3f1ad84-d45f-4ef0-b18f-767339bf436e	true	include.in.token.scope
982f6961-08bd-4741-acaa-d0444f1d1f90	true	display.on.consent.screen
982f6961-08bd-4741-acaa-d0444f1d1f90	${addressScopeConsentText}	consent.screen.text
982f6961-08bd-4741-acaa-d0444f1d1f90	true	include.in.token.scope
e0f3bf3c-84b1-4c54-972c-a1968fffe728	true	display.on.consent.screen
e0f3bf3c-84b1-4c54-972c-a1968fffe728	${phoneScopeConsentText}	consent.screen.text
e0f3bf3c-84b1-4c54-972c-a1968fffe728	true	include.in.token.scope
4e78c483-16fc-4c51-a8f7-1c906bd42e91	true	display.on.consent.screen
4e78c483-16fc-4c51-a8f7-1c906bd42e91	${rolesScopeConsentText}	consent.screen.text
4e78c483-16fc-4c51-a8f7-1c906bd42e91	false	include.in.token.scope
6f111df2-7083-4774-a033-bd644b61b48e	false	display.on.consent.screen
6f111df2-7083-4774-a033-bd644b61b48e		consent.screen.text
6f111df2-7083-4774-a033-bd644b61b48e	false	include.in.token.scope
bbb3bc76-0f3f-4988-9df6-67713326a19f	false	display.on.consent.screen
bbb3bc76-0f3f-4988-9df6-67713326a19f	true	include.in.token.scope
955521bd-156f-4ade-a60a-036f859c9600	false	display.on.consent.screen
955521bd-156f-4ade-a60a-036f859c9600	false	include.in.token.scope
a38bb110-7d1c-433e-a5b9-04197257357c	false	display.on.consent.screen
a38bb110-7d1c-433e-a5b9-04197257357c	false	include.in.token.scope
d59eaa29-cc6d-458b-929f-7a298bf3960d	false	display.on.consent.screen
d59eaa29-cc6d-458b-929f-7a298bf3960d	false	include.in.token.scope
3f969fa3-d862-4656-835e-07ea2f6f2c5e	true	display.on.consent.screen
3f969fa3-d862-4656-835e-07ea2f6f2c5e	${organizationScopeConsentText}	consent.screen.text
3f969fa3-d862-4656-835e-07ea2f6f2c5e	true	include.in.token.scope
0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	false	include.in.token.scope
0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	false	display.on.consent.screen
1267b092-d449-4b01-8bcc-dfcbd2763276	false	include.in.token.scope
1267b092-d449-4b01-8bcc-dfcbd2763276	false	display.on.consent.screen
d729010f-7c64-4a75-9eae-71f211ae4de2	true	include.in.token.scope
d729010f-7c64-4a75-9eae-71f211ae4de2	${profileScopeConsentText}	consent.screen.text
d729010f-7c64-4a75-9eae-71f211ae4de2	true	display.on.consent.screen
943f5b4d-0bb5-4864-bace-22399ada546b	true	include.in.token.scope
943f5b4d-0bb5-4864-bace-22399ada546b	false	display.on.consent.screen
79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	true	include.in.token.scope
79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	${organizationScopeConsentText}	consent.screen.text
79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	true	display.on.consent.screen
6a4f95f0-80dc-4ca3-92e2-bd44b229837b	${samlRoleListScopeConsentText}	consent.screen.text
6a4f95f0-80dc-4ca3-92e2-bd44b229837b	true	display.on.consent.screen
9e9fc66a-2d58-4305-b20f-35a78aba8e23	true	include.in.token.scope
9e9fc66a-2d58-4305-b20f-35a78aba8e23	true	display.on.consent.screen
9e9fc66a-2d58-4305-b20f-35a78aba8e23		gui.order
9e9fc66a-2d58-4305-b20f-35a78aba8e23		consent.screen.text
9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	true	include.in.token.scope
9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	${phoneScopeConsentText}	consent.screen.text
9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	true	display.on.consent.screen
42a8e654-6d1e-48e7-806d-2c72dc42c30d	false	display.on.consent.screen
1538aa9f-9009-4e70-b7fc-626af0cebfb2	true	include.in.token.scope
1538aa9f-9009-4e70-b7fc-626af0cebfb2	${emailScopeConsentText}	consent.screen.text
1538aa9f-9009-4e70-b7fc-626af0cebfb2	true	display.on.consent.screen
82460a4f-02d3-4320-b9df-2d124ab1a3ff	true	include.in.token.scope
82460a4f-02d3-4320-b9df-2d124ab1a3ff	${addressScopeConsentText}	consent.screen.text
82460a4f-02d3-4320-b9df-2d124ab1a3ff	true	display.on.consent.screen
59b64ca7-8476-4387-a6d1-946cb16bc586	false	include.in.token.scope
59b64ca7-8476-4387-a6d1-946cb16bc586	false	display.on.consent.screen
4d0a91b8-6958-4930-997c-83bf8b67bc34	${offlineAccessScopeConsentText}	consent.screen.text
4d0a91b8-6958-4930-997c-83bf8b67bc34	true	display.on.consent.screen
b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	false	include.in.token.scope
b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	${rolesScopeConsentText}	consent.screen.text
b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	true	display.on.consent.screen
6fe2d901-9820-4971-a3a9-7990f11d8523	true	include.in.token.scope
6fe2d901-9820-4971-a3a9-7990f11d8523	true	display.on.consent.screen
6fe2d901-9820-4971-a3a9-7990f11d8523		gui.order
6fe2d901-9820-4971-a3a9-7990f11d8523		consent.screen.text
72a2873f-bbb0-4ede-92d4-a6a541ee07e8	false	include.in.token.scope
72a2873f-bbb0-4ede-92d4-a6a541ee07e8		consent.screen.text
72a2873f-bbb0-4ede-92d4-a6a541ee07e8	false	display.on.consent.screen
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
e685bf33-6dc9-45b6-b45e-0613070a3f57	6f111df2-7083-4774-a033-bd644b61b48e	t
e685bf33-6dc9-45b6-b45e-0613070a3f57	eab31880-af7f-4af2-83d8-b69977819fad	t
e685bf33-6dc9-45b6-b45e-0613070a3f57	4e78c483-16fc-4c51-a8f7-1c906bd42e91	t
e685bf33-6dc9-45b6-b45e-0613070a3f57	e3f1ad84-d45f-4ef0-b18f-767339bf436e	t
e685bf33-6dc9-45b6-b45e-0613070a3f57	955521bd-156f-4ade-a60a-036f859c9600	t
e685bf33-6dc9-45b6-b45e-0613070a3f57	a38bb110-7d1c-433e-a5b9-04197257357c	t
e685bf33-6dc9-45b6-b45e-0613070a3f57	19b176e1-4a7e-42be-8de5-6407f497c093	f
e685bf33-6dc9-45b6-b45e-0613070a3f57	e0f3bf3c-84b1-4c54-972c-a1968fffe728	f
e685bf33-6dc9-45b6-b45e-0613070a3f57	982f6961-08bd-4741-acaa-d0444f1d1f90	f
e685bf33-6dc9-45b6-b45e-0613070a3f57	3f969fa3-d862-4656-835e-07ea2f6f2c5e	f
e685bf33-6dc9-45b6-b45e-0613070a3f57	bbb3bc76-0f3f-4988-9df6-67713326a19f	f
43b0209c-b0f6-48fd-b331-172944afaab9	6f111df2-7083-4774-a033-bd644b61b48e	t
43b0209c-b0f6-48fd-b331-172944afaab9	eab31880-af7f-4af2-83d8-b69977819fad	t
43b0209c-b0f6-48fd-b331-172944afaab9	4e78c483-16fc-4c51-a8f7-1c906bd42e91	t
43b0209c-b0f6-48fd-b331-172944afaab9	e3f1ad84-d45f-4ef0-b18f-767339bf436e	t
43b0209c-b0f6-48fd-b331-172944afaab9	955521bd-156f-4ade-a60a-036f859c9600	t
43b0209c-b0f6-48fd-b331-172944afaab9	a38bb110-7d1c-433e-a5b9-04197257357c	t
43b0209c-b0f6-48fd-b331-172944afaab9	19b176e1-4a7e-42be-8de5-6407f497c093	f
43b0209c-b0f6-48fd-b331-172944afaab9	e0f3bf3c-84b1-4c54-972c-a1968fffe728	f
43b0209c-b0f6-48fd-b331-172944afaab9	982f6961-08bd-4741-acaa-d0444f1d1f90	f
43b0209c-b0f6-48fd-b331-172944afaab9	3f969fa3-d862-4656-835e-07ea2f6f2c5e	f
43b0209c-b0f6-48fd-b331-172944afaab9	bbb3bc76-0f3f-4988-9df6-67713326a19f	f
3f322b29-20df-4448-b44a-3b9f8f753b16	6f111df2-7083-4774-a033-bd644b61b48e	t
3f322b29-20df-4448-b44a-3b9f8f753b16	eab31880-af7f-4af2-83d8-b69977819fad	t
3f322b29-20df-4448-b44a-3b9f8f753b16	4e78c483-16fc-4c51-a8f7-1c906bd42e91	t
3f322b29-20df-4448-b44a-3b9f8f753b16	e3f1ad84-d45f-4ef0-b18f-767339bf436e	t
3f322b29-20df-4448-b44a-3b9f8f753b16	955521bd-156f-4ade-a60a-036f859c9600	t
3f322b29-20df-4448-b44a-3b9f8f753b16	a38bb110-7d1c-433e-a5b9-04197257357c	t
3f322b29-20df-4448-b44a-3b9f8f753b16	19b176e1-4a7e-42be-8de5-6407f497c093	f
3f322b29-20df-4448-b44a-3b9f8f753b16	e0f3bf3c-84b1-4c54-972c-a1968fffe728	f
3f322b29-20df-4448-b44a-3b9f8f753b16	982f6961-08bd-4741-acaa-d0444f1d1f90	f
3f322b29-20df-4448-b44a-3b9f8f753b16	3f969fa3-d862-4656-835e-07ea2f6f2c5e	f
3f322b29-20df-4448-b44a-3b9f8f753b16	bbb3bc76-0f3f-4988-9df6-67713326a19f	f
06330188-1212-410f-8c88-9995499f332e	6f111df2-7083-4774-a033-bd644b61b48e	t
06330188-1212-410f-8c88-9995499f332e	eab31880-af7f-4af2-83d8-b69977819fad	t
06330188-1212-410f-8c88-9995499f332e	4e78c483-16fc-4c51-a8f7-1c906bd42e91	t
06330188-1212-410f-8c88-9995499f332e	e3f1ad84-d45f-4ef0-b18f-767339bf436e	t
06330188-1212-410f-8c88-9995499f332e	955521bd-156f-4ade-a60a-036f859c9600	t
06330188-1212-410f-8c88-9995499f332e	a38bb110-7d1c-433e-a5b9-04197257357c	t
06330188-1212-410f-8c88-9995499f332e	19b176e1-4a7e-42be-8de5-6407f497c093	f
06330188-1212-410f-8c88-9995499f332e	e0f3bf3c-84b1-4c54-972c-a1968fffe728	f
06330188-1212-410f-8c88-9995499f332e	982f6961-08bd-4741-acaa-d0444f1d1f90	f
06330188-1212-410f-8c88-9995499f332e	3f969fa3-d862-4656-835e-07ea2f6f2c5e	f
06330188-1212-410f-8c88-9995499f332e	bbb3bc76-0f3f-4988-9df6-67713326a19f	f
14d66edd-004a-4fd0-af78-44f38b17dd06	6f111df2-7083-4774-a033-bd644b61b48e	t
14d66edd-004a-4fd0-af78-44f38b17dd06	eab31880-af7f-4af2-83d8-b69977819fad	t
14d66edd-004a-4fd0-af78-44f38b17dd06	4e78c483-16fc-4c51-a8f7-1c906bd42e91	t
14d66edd-004a-4fd0-af78-44f38b17dd06	e3f1ad84-d45f-4ef0-b18f-767339bf436e	t
14d66edd-004a-4fd0-af78-44f38b17dd06	955521bd-156f-4ade-a60a-036f859c9600	t
14d66edd-004a-4fd0-af78-44f38b17dd06	a38bb110-7d1c-433e-a5b9-04197257357c	t
14d66edd-004a-4fd0-af78-44f38b17dd06	19b176e1-4a7e-42be-8de5-6407f497c093	f
14d66edd-004a-4fd0-af78-44f38b17dd06	e0f3bf3c-84b1-4c54-972c-a1968fffe728	f
14d66edd-004a-4fd0-af78-44f38b17dd06	982f6961-08bd-4741-acaa-d0444f1d1f90	f
14d66edd-004a-4fd0-af78-44f38b17dd06	3f969fa3-d862-4656-835e-07ea2f6f2c5e	f
14d66edd-004a-4fd0-af78-44f38b17dd06	bbb3bc76-0f3f-4988-9df6-67713326a19f	f
8395b40e-acfd-4834-b2bd-605b68e96a3c	6f111df2-7083-4774-a033-bd644b61b48e	t
8395b40e-acfd-4834-b2bd-605b68e96a3c	eab31880-af7f-4af2-83d8-b69977819fad	t
8395b40e-acfd-4834-b2bd-605b68e96a3c	4e78c483-16fc-4c51-a8f7-1c906bd42e91	t
8395b40e-acfd-4834-b2bd-605b68e96a3c	e3f1ad84-d45f-4ef0-b18f-767339bf436e	t
8395b40e-acfd-4834-b2bd-605b68e96a3c	955521bd-156f-4ade-a60a-036f859c9600	t
8395b40e-acfd-4834-b2bd-605b68e96a3c	a38bb110-7d1c-433e-a5b9-04197257357c	t
8395b40e-acfd-4834-b2bd-605b68e96a3c	19b176e1-4a7e-42be-8de5-6407f497c093	f
8395b40e-acfd-4834-b2bd-605b68e96a3c	e0f3bf3c-84b1-4c54-972c-a1968fffe728	f
8395b40e-acfd-4834-b2bd-605b68e96a3c	982f6961-08bd-4741-acaa-d0444f1d1f90	f
8395b40e-acfd-4834-b2bd-605b68e96a3c	3f969fa3-d862-4656-835e-07ea2f6f2c5e	f
8395b40e-acfd-4834-b2bd-605b68e96a3c	bbb3bc76-0f3f-4988-9df6-67713326a19f	f
a64e78ff-429f-461c-85ca-11095df7667f	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	t
a64e78ff-429f-461c-85ca-11095df7667f	1538aa9f-9009-4e70-b7fc-626af0cebfb2	t
a64e78ff-429f-461c-85ca-11095df7667f	d729010f-7c64-4a75-9eae-71f211ae4de2	t
a64e78ff-429f-461c-85ca-11095df7667f	59b64ca7-8476-4387-a6d1-946cb16bc586	t
a64e78ff-429f-461c-85ca-11095df7667f	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	t
a64e78ff-429f-461c-85ca-11095df7667f	72a2873f-bbb0-4ede-92d4-a6a541ee07e8	t
a64e78ff-429f-461c-85ca-11095df7667f	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	f
a64e78ff-429f-461c-85ca-11095df7667f	82460a4f-02d3-4320-b9df-2d124ab1a3ff	f
a64e78ff-429f-461c-85ca-11095df7667f	4d0a91b8-6958-4930-997c-83bf8b67bc34	f
a64e78ff-429f-461c-85ca-11095df7667f	943f5b4d-0bb5-4864-bace-22399ada546b	f
a64e78ff-429f-461c-85ca-11095df7667f	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	f
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	t
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	1538aa9f-9009-4e70-b7fc-626af0cebfb2	t
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	d729010f-7c64-4a75-9eae-71f211ae4de2	t
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	59b64ca7-8476-4387-a6d1-946cb16bc586	t
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	t
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	72a2873f-bbb0-4ede-92d4-a6a541ee07e8	t
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	f
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	82460a4f-02d3-4320-b9df-2d124ab1a3ff	f
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	4d0a91b8-6958-4930-997c-83bf8b67bc34	f
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	943f5b4d-0bb5-4864-bace-22399ada546b	f
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	f
cd6b3799-4945-4098-bde9-ca33bbcb3597	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	t
cd6b3799-4945-4098-bde9-ca33bbcb3597	1538aa9f-9009-4e70-b7fc-626af0cebfb2	t
cd6b3799-4945-4098-bde9-ca33bbcb3597	d729010f-7c64-4a75-9eae-71f211ae4de2	t
cd6b3799-4945-4098-bde9-ca33bbcb3597	59b64ca7-8476-4387-a6d1-946cb16bc586	t
cd6b3799-4945-4098-bde9-ca33bbcb3597	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	t
cd6b3799-4945-4098-bde9-ca33bbcb3597	72a2873f-bbb0-4ede-92d4-a6a541ee07e8	t
cd6b3799-4945-4098-bde9-ca33bbcb3597	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	f
cd6b3799-4945-4098-bde9-ca33bbcb3597	82460a4f-02d3-4320-b9df-2d124ab1a3ff	f
cd6b3799-4945-4098-bde9-ca33bbcb3597	4d0a91b8-6958-4930-997c-83bf8b67bc34	f
cd6b3799-4945-4098-bde9-ca33bbcb3597	943f5b4d-0bb5-4864-bace-22399ada546b	f
cd6b3799-4945-4098-bde9-ca33bbcb3597	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	f
be4928ae-99f3-4bd5-81a4-9fecedc0340c	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	t
be4928ae-99f3-4bd5-81a4-9fecedc0340c	1538aa9f-9009-4e70-b7fc-626af0cebfb2	t
be4928ae-99f3-4bd5-81a4-9fecedc0340c	d729010f-7c64-4a75-9eae-71f211ae4de2	t
be4928ae-99f3-4bd5-81a4-9fecedc0340c	59b64ca7-8476-4387-a6d1-946cb16bc586	t
be4928ae-99f3-4bd5-81a4-9fecedc0340c	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	t
be4928ae-99f3-4bd5-81a4-9fecedc0340c	72a2873f-bbb0-4ede-92d4-a6a541ee07e8	t
be4928ae-99f3-4bd5-81a4-9fecedc0340c	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	f
be4928ae-99f3-4bd5-81a4-9fecedc0340c	82460a4f-02d3-4320-b9df-2d124ab1a3ff	f
be4928ae-99f3-4bd5-81a4-9fecedc0340c	4d0a91b8-6958-4930-997c-83bf8b67bc34	f
be4928ae-99f3-4bd5-81a4-9fecedc0340c	943f5b4d-0bb5-4864-bace-22399ada546b	f
be4928ae-99f3-4bd5-81a4-9fecedc0340c	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	f
c6f5ede9-6791-43d3-8430-f485361bf7d5	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	t
c6f5ede9-6791-43d3-8430-f485361bf7d5	1538aa9f-9009-4e70-b7fc-626af0cebfb2	t
c6f5ede9-6791-43d3-8430-f485361bf7d5	d729010f-7c64-4a75-9eae-71f211ae4de2	t
c6f5ede9-6791-43d3-8430-f485361bf7d5	59b64ca7-8476-4387-a6d1-946cb16bc586	t
c6f5ede9-6791-43d3-8430-f485361bf7d5	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	t
c6f5ede9-6791-43d3-8430-f485361bf7d5	72a2873f-bbb0-4ede-92d4-a6a541ee07e8	t
c6f5ede9-6791-43d3-8430-f485361bf7d5	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	f
c6f5ede9-6791-43d3-8430-f485361bf7d5	82460a4f-02d3-4320-b9df-2d124ab1a3ff	f
c6f5ede9-6791-43d3-8430-f485361bf7d5	4d0a91b8-6958-4930-997c-83bf8b67bc34	f
c6f5ede9-6791-43d3-8430-f485361bf7d5	943f5b4d-0bb5-4864-bace-22399ada546b	f
c6f5ede9-6791-43d3-8430-f485361bf7d5	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	f
c6f5ede9-6791-43d3-8430-f485361bf7d5	1267b092-d449-4b01-8bcc-dfcbd2763276	t
c6f5ede9-6791-43d3-8430-f485361bf7d5	6fe2d901-9820-4971-a3a9-7990f11d8523	t
c6f5ede9-6791-43d3-8430-f485361bf7d5	9e9fc66a-2d58-4305-b20f-35a78aba8e23	t
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	t
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	1538aa9f-9009-4e70-b7fc-626af0cebfb2	t
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	d729010f-7c64-4a75-9eae-71f211ae4de2	t
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	59b64ca7-8476-4387-a6d1-946cb16bc586	t
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	t
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	72a2873f-bbb0-4ede-92d4-a6a541ee07e8	t
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	f
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	82460a4f-02d3-4320-b9df-2d124ab1a3ff	f
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	4d0a91b8-6958-4930-997c-83bf8b67bc34	f
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	943f5b4d-0bb5-4864-bace-22399ada546b	f
c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	f
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	t
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	1538aa9f-9009-4e70-b7fc-626af0cebfb2	t
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	d729010f-7c64-4a75-9eae-71f211ae4de2	t
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	59b64ca7-8476-4387-a6d1-946cb16bc586	t
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	t
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	72a2873f-bbb0-4ede-92d4-a6a541ee07e8	t
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	f
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	82460a4f-02d3-4320-b9df-2d124ab1a3ff	f
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	4d0a91b8-6958-4930-997c-83bf8b67bc34	f
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	943f5b4d-0bb5-4864-bace-22399ada546b	f
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
19b176e1-4a7e-42be-8de5-6407f497c093	49327fa4-6460-4648-b0de-bad086225537
4d0a91b8-6958-4930-997c-83bf8b67bc34	51cb8d42-5a64-480b-b631-8e4c81dc90b2
9e9fc66a-2d58-4305-b20f-35a78aba8e23	8df9234a-22b6-496e-817f-f02ffcf641ca
9e9fc66a-2d58-4305-b20f-35a78aba8e23	fa8d2230-c1a1-4b74-ab06-054303837057
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
42dba752-44f7-4545-8ce0-42cab09816d8	Trusted Hosts	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	anonymous
cc183cef-e28d-4293-b2d4-b064c537608a	Consent Required	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	anonymous
ec8d16ad-5276-423d-b163-51521201e6d1	Full Scope Disabled	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	anonymous
d57b4546-e9aa-4763-8027-c176d17f4636	Max Clients Limit	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	anonymous
69eb6919-7ffb-4a0d-9c40-8b636647ce57	Allowed Protocol Mapper Types	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	anonymous
97a90b37-6075-4607-9fd3-dce152c2019e	Allowed Client Scopes	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	anonymous
02eeb8f0-5f04-4eec-b469-da8ac26cc304	Allowed Protocol Mapper Types	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	authenticated
3cc03830-6568-4002-a2f4-5021f25784b0	Allowed Client Scopes	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	authenticated
d3abe082-28de-4121-be41-e11ab38ae8b2	rsa-generated	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	rsa-generated	org.keycloak.keys.KeyProvider	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N
d65feeb0-30f4-4ad8-9b16-6668c427e5fb	rsa-enc-generated	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	rsa-enc-generated	org.keycloak.keys.KeyProvider	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N
77e115e7-7333-4891-8657-e69de605134f	hmac-generated-hs512	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	hmac-generated	org.keycloak.keys.KeyProvider	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N
ad42ddbf-9dc3-4162-be91-5ba38deacc7e	aes-generated	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	aes-generated	org.keycloak.keys.KeyProvider	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N
8e41abbf-8b8b-44da-9443-ef7584c9885c	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	declarative-user-profile	org.keycloak.userprofile.UserProfileProvider	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N
7018e516-f9ce-452d-a609-9a12b48e9ff0	Allowed Protocol Mapper Types	fa932e74-3d72-4028-b476-3620d13514ce	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fa932e74-3d72-4028-b476-3620d13514ce	authenticated
00f66f74-8551-4598-9828-8c300f9d4535	Full Scope Disabled	fa932e74-3d72-4028-b476-3620d13514ce	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fa932e74-3d72-4028-b476-3620d13514ce	anonymous
267bafb8-d5a1-4a40-9d2d-1aa59c498c02	Max Clients Limit	fa932e74-3d72-4028-b476-3620d13514ce	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fa932e74-3d72-4028-b476-3620d13514ce	anonymous
ef527b51-4327-408b-ac4f-e1bc9b5f148b	Allowed Protocol Mapper Types	fa932e74-3d72-4028-b476-3620d13514ce	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fa932e74-3d72-4028-b476-3620d13514ce	anonymous
f3990661-0819-4a67-892a-b92ad2fbe1a8	Allowed Client Scopes	fa932e74-3d72-4028-b476-3620d13514ce	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fa932e74-3d72-4028-b476-3620d13514ce	authenticated
822808d7-d95f-4ef2-a67a-d33613d09cd9	Allowed Client Scopes	fa932e74-3d72-4028-b476-3620d13514ce	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fa932e74-3d72-4028-b476-3620d13514ce	anonymous
23bd4700-e352-4ad4-960e-06bcfa3903c3	Trusted Hosts	fa932e74-3d72-4028-b476-3620d13514ce	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fa932e74-3d72-4028-b476-3620d13514ce	anonymous
8911680c-04ee-4f97-a9ab-ffb739a58c92	Consent Required	fa932e74-3d72-4028-b476-3620d13514ce	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	fa932e74-3d72-4028-b476-3620d13514ce	anonymous
a69e9517-3d30-4f80-af2f-49ad1340b089	rsa-enc-generated	fa932e74-3d72-4028-b476-3620d13514ce	rsa-enc-generated	org.keycloak.keys.KeyProvider	fa932e74-3d72-4028-b476-3620d13514ce	\N
2da1798a-fce4-47c6-a2f3-a793044e49fe	rsa-generated	fa932e74-3d72-4028-b476-3620d13514ce	rsa-generated	org.keycloak.keys.KeyProvider	fa932e74-3d72-4028-b476-3620d13514ce	\N
343b222d-b239-4d7d-a881-a4daa9d1b2a1	hmac-generated-hs512	fa932e74-3d72-4028-b476-3620d13514ce	hmac-generated	org.keycloak.keys.KeyProvider	fa932e74-3d72-4028-b476-3620d13514ce	\N
78585f6d-7b4b-4424-9d21-6328b1cf5a02	aes-generated	fa932e74-3d72-4028-b476-3620d13514ce	aes-generated	org.keycloak.keys.KeyProvider	fa932e74-3d72-4028-b476-3620d13514ce	\N
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
bf2b2a81-cb89-4c11-bd96-e8ba671ad6b2	69eb6919-7ffb-4a0d-9c40-8b636647ce57	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
898d3338-b574-4eb6-80e1-423d21f05a1c	69eb6919-7ffb-4a0d-9c40-8b636647ce57	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
b4cce299-344e-41ec-b7be-51844807ab5c	69eb6919-7ffb-4a0d-9c40-8b636647ce57	allowed-protocol-mapper-types	oidc-full-name-mapper
15ad1172-49a6-409c-9506-e4a20ea6ac41	69eb6919-7ffb-4a0d-9c40-8b636647ce57	allowed-protocol-mapper-types	saml-user-attribute-mapper
3b86cae0-5e18-48db-9173-8129a6e30265	69eb6919-7ffb-4a0d-9c40-8b636647ce57	allowed-protocol-mapper-types	saml-role-list-mapper
9c920873-d5d3-4a78-8762-f4023564e8d8	69eb6919-7ffb-4a0d-9c40-8b636647ce57	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
a8626162-3727-4937-bc7b-cfb416e511f5	69eb6919-7ffb-4a0d-9c40-8b636647ce57	allowed-protocol-mapper-types	oidc-address-mapper
452b13b2-5c55-482e-93d3-fa4bf6442a60	69eb6919-7ffb-4a0d-9c40-8b636647ce57	allowed-protocol-mapper-types	saml-user-property-mapper
eaa4cc34-6ab0-40ef-81db-1490edde384f	3cc03830-6568-4002-a2f4-5021f25784b0	allow-default-scopes	true
96b11ec1-52d1-4cf8-80da-12589d066d65	42dba752-44f7-4545-8ce0-42cab09816d8	host-sending-registration-request-must-match	true
26401b60-bb2b-4ca0-8ddc-ddff652f0492	42dba752-44f7-4545-8ce0-42cab09816d8	client-uris-must-match	true
4081c0e0-c783-44fe-9862-cf50d97e6fcf	d57b4546-e9aa-4763-8027-c176d17f4636	max-clients	200
08dd1d92-1785-466c-8dbc-356e8e577489	02eeb8f0-5f04-4eec-b469-da8ac26cc304	allowed-protocol-mapper-types	saml-user-property-mapper
31c6aa67-82a6-47bb-943b-64330dddbc7d	02eeb8f0-5f04-4eec-b469-da8ac26cc304	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
cd0f7f55-dfde-492a-93df-5e636d0f9880	02eeb8f0-5f04-4eec-b469-da8ac26cc304	allowed-protocol-mapper-types	saml-role-list-mapper
b6df59cc-383f-4045-9c3a-5be0511e13f1	02eeb8f0-5f04-4eec-b469-da8ac26cc304	allowed-protocol-mapper-types	oidc-address-mapper
3133fe74-742d-46c7-b288-00bbd89204aa	02eeb8f0-5f04-4eec-b469-da8ac26cc304	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
6e0e215d-c9df-47a6-ad95-e9aad63f744f	02eeb8f0-5f04-4eec-b469-da8ac26cc304	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
01385134-e02e-461e-b37f-65de5f022877	02eeb8f0-5f04-4eec-b469-da8ac26cc304	allowed-protocol-mapper-types	oidc-full-name-mapper
9df04027-5378-43ca-b7ad-ec81b8c79ae3	02eeb8f0-5f04-4eec-b469-da8ac26cc304	allowed-protocol-mapper-types	saml-user-attribute-mapper
c0f96169-5807-4a81-b284-5765904cde9c	97a90b37-6075-4607-9fd3-dce152c2019e	allow-default-scopes	true
2386e4dd-3dc8-4ad3-bed7-a2e4780d17e5	d65feeb0-30f4-4ad8-9b16-6668c427e5fb	keyUse	ENC
9712b08a-9641-4329-8a21-31113aa21c0a	d65feeb0-30f4-4ad8-9b16-6668c427e5fb	certificate	MIICmzCCAYMCBgGZtZmj4TANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjUxMDA1MTgxNzQ5WhcNMzUxMDA1MTgxOTI5WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDWREl/zBl4g6YDThU1hTfQsuLNxrUx1o4tvy9KXKfCdTvcpaL1iWeqALC6tk2o/v1m9YhjmdcElL4SKtxh4YxsJnUraJpXN/RBToILIJMyPZfrHzRD2JgZ8ouv7YGzXGFmg9YL3UHBflI157QRr/N/rIHRe14uIpv9y9yXdhUxmg/ivhTDzkExM6k8D0QlU1WKpxKDFpoSfyMSYCOxEgA5BTKQm1+pRUmEofIPAeOSCSusroARbYofgZZppAko5LwFWiNJbqdJ5TLFZ9sc6c2bprqrsOncm2ZWVLin4VAkzxVqpus5rFo+LzrlhAEGhlszyK3frJ3Kd2FVd6sHG4nZAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAIRta3IreYDjwvv3k5dymIj5gj5gnW/v5pyMou+Nux6ECUgMqtNLp6NAW7iBB6hjtCc8pezpORBkHdhsQ+XCPxsj/JITg8ECt1XNNt/SLJItAHw6e/l0IlXkNRnZfXSGh9oa/ifdEc6+bYZr8KKMx9MH6oKCgBib93WAZe9ish47h546Qxzfjr3gU2Sw4kfcNL3PHwGyMgE7ySqKpVckurK59M3WpPY01mSGZsOJBcwOWKZev5v9YxBMegOu1NL04ok6Gz7sRo7L+l06rQ/CGITpzlq3WDYZLmbuXXq665DW9s+DeiCJwYcr+zDbg6DC4RWmsrh2md1q2+PM08+Fl+k=
552de100-0161-4b23-b6c9-ddfadc17646a	d65feeb0-30f4-4ad8-9b16-6668c427e5fb	priority	100
efc5c5cb-3c01-4525-a40c-41767cc495fb	d65feeb0-30f4-4ad8-9b16-6668c427e5fb	privateKey	MIIEogIBAAKCAQEA1kRJf8wZeIOmA04VNYU30LLizca1MdaOLb8vSlynwnU73KWi9YlnqgCwurZNqP79ZvWIY5nXBJS+EircYeGMbCZ1K2iaVzf0QU6CCyCTMj2X6x80Q9iYGfKLr+2Bs1xhZoPWC91BwX5SNee0Ea/zf6yB0XteLiKb/cvcl3YVMZoP4r4Uw85BMTOpPA9EJVNViqcSgxaaEn8jEmAjsRIAOQUykJtfqUVJhKHyDwHjkgkrrK6AEW2KH4GWaaQJKOS8BVojSW6nSeUyxWfbHOnNm6a6q7Dp3JtmVlS4p+FQJM8VaqbrOaxaPi865YQBBoZbM8it36ydyndhVXerBxuJ2QIDAQABAoIBABEX3wYxNdn5pKmQVdxQbaC6WKIiZ0ubynlnTmJADIkUmaszUpIEfW7gQbkPeJgSCYyoa1JI0FC2/gfMgArV98Ib+k51eJSbK+L23KR/G4cPR1qUQXLlKVMumIq3J5jztnh7bXzCUK/bQDs5KhIcJ5CIpk2cKioDjE69r/IsUyoC80Gin1d9xl79mfnSAwNLnq+B/Fs5D48jqif8NySQVpOGEi1/Cvvb6nMyhOyqCgBJnntHLUVH9K7nChcFfdaa/gwqpajyE/F13iYF1fCF1LgzMUogdAenVYYAjoZZxK7CNl5+0sRMJag5G6h6P3A7eLCdkzdFpvEK8V6AShMRvTUCgYEA6vngSk+R9mRz0+QlDTOg4fw4Lgvm/VMwxURQS3No9Onn2nxO0jMKzSvMjwpX9Aqz9j3ybAlwYUvnHBVp7r2/HFNDl92lmN1cFUvThXlwOfzpXouJJxPKVtrIUT2CXFar9tWC4YavDwjlbioN00h6xNNo0jpMihyYbppKzzOQdm0CgYEA6XAQYoIvTH0C9zf3S9+vDJ0s6Cb2FuFNGnV0RwKMbf3158NZd8/dBXefI96Cgsxz9Si7V2WDQ3Ij8mAY0GQtgwsiGLdvwARr2nWzIpyq9T33E9zK2tVI6uO0bmwImfQdT5YMqBghXuw+jk9s7a9owkgGpwdS0koZProp56Vg7Z0CgYBL/ScFoRno/q9elOdOj6W1r2VTrtGyltas1NzKqbYFjidGxvCOlacmlsV+dK/g4h00wu/E9IB9VpiUwnARnxdQx7SSRkGpX9zJnk33WkBq4FlwE9v04TeMQxCJBUVFK1pNZtr+qBmw2QWpTLxP2Z6qTFwXsHbUK084ZXlP7LMJOQKBgBLsq9dgmHcJ93CVT+4Nv0I1h8t2RSMLttV7SibrlPjhysq0Mo+dAV0NGpCs3EXAT3JDkBSAvUh9e16N3dUfGfVytJvuWxflA91dB125974T/PDWSHe/LL8mIJ2HEpdwi+PE1VfXRPVOD7A3ziviuYpujmOCG3vC2BMWwojuBlKdAoGATrJ6XEoOi6+b9xw+v5bSYtI2TWIkZFMr14J6JcGtw4YkVIZ1uA/d0TSzd59Xw+9sYxIokm/ajYZwInUiqRLznr9b9FRHWFdBmw98HG95pDxFcUaS+6uJPB1xID34fDWLx1HYBERP5f6gWjSQgFGcCTSjpM2M+dH/Rh9QHhgDqGQ=
ba89e0fe-fe1b-4dbc-93b0-62b0802b3cca	d65feeb0-30f4-4ad8-9b16-6668c427e5fb	algorithm	RSA-OAEP
1d4e75c8-7d3c-4cfd-90bb-8eec09730f4a	8e41abbf-8b8b-44da-9443-ef7584c9885c	kc.user.profile.config	{"attributes":[{"name":"username","displayName":"${username}","validations":{"length":{"min":3,"max":255},"username-prohibited-characters":{},"up-username-not-idn-homograph":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"email","displayName":"${email}","validations":{"email":{},"length":{"max":255}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"firstName","displayName":"${firstName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"lastName","displayName":"${lastName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false}],"groups":[{"name":"user-metadata","displayHeader":"User metadata","displayDescription":"Attributes, which refer to user metadata"}]}
92ae123c-e09b-40c3-80c8-416b900e206f	d3abe082-28de-4121-be41-e11ab38ae8b2	privateKey	MIIEogIBAAKCAQEAmHDEAPDhPAwd5CtW1bwcN0/NDoO+nfZCFZe+7H6Aa2uHz6Jw2uHUAdFtC0Sel4nVON2nK9FVAJrYio95xEkVWLOyhR9JsEutGbOhU/CeyBiyN3/FAghoZyNE/6UFqMz14HPHqV8zzeIuD4gYXv6bOIAkvCVh/8admwySE6YBTSFk2DGnMGUfxgWjRrP9Jer5tGhW/NCQPnb3yznBTW7D8gmgc44w0sJ/ITRT+jMFHROBYoZQqS0z+NmELiq+cl9kKMCq5MONQpULYOPi8MRWRM4dyDyLSTjc8PC43qg2nvIqupL+dlSaQV/SeBazQrEMtEnECOoXrOlzcn3FsfZIRQIDAQABAoIBAD+lUUh9SeTawD4sFCC/3d4AHQLS4aqtDxFZ3nZ6KJ7w8e6wiULx56TsrgT23OozO4l3Dd1/FGjgvck4NyRLSTTULhRjqE4JgpfJBnH39CtiGEKQv43mOcTaFmxQF4lPLddNL88Y9xWeOhH1BgvfbKpN4kiFqSFz6Qi72l+Gv2NWiYCuEGaRlIvUsQ7gMw1DEzJqgiWj8bXyhFNFMRe8o+kE2MxA/PllzZ6JGHH4y5VHosuTpcEPvbshlrnGDTuvYy4vHSjGK7WGpQJa70YbSTWv33vT0H5qlc4kqY1vwQ3EzXCa5nbOrz6tizchyxjmEopEidOMXNbH0wQZft+jDc8CgYEAxohF7E5veuyplAPVGFi62JirrXMCLqW2rqujnCAqVvJk19WNNSy5VaJZlY9fyr/usGbPlzn24vGB8ENO7H4qdEyJ4URHfUeqOccVkqh08LPIXDihH18ER8FV7T9EE3b2SC+AUnhUOfjHhSolXPKKi9BQrRQFqkoDzMkNyQUWTRMCgYEAxJD56tztH9Uy3ePAduc0m0Nq/7uIIlLuSTDcqWUH4L0UNYhaB7DOdWHrX8I2HBLRmF09ab055HR64i45F+o34D6dxhiZ/ybakmutZM3eixRAd56hPhjVlfqkMjtxt6vKb+zj2rtwD7K03c8U64mUb36ph/mGv3354o8RXKuCeEcCgYBxkzwNN8Hm3MUWfCrIRtp9Vrm//G9fKEYeHur2QiB2pSyznOOva+qK5tnBCciPQMXX/Lj9lpd6tRbU0GyyNmsrJS4rxNfw/7KOYyogQGbF3NPejjb+r2jPc/coRm03hXLXUPVkOJpWn8/kinvddJN18LJ2kWG8TaNm4A4W1eYwKQKBgDl+cisZHZ5+/JbcQ/JDZCa5zHUqhAIOIbZ0vUYqz+gTRfL2g+bV9z1sO61RoAQMGRQoyYrBF0rUKxE3FeoBzwAfMIS9s2VnFu1W42ulr58ceFLEqkMAfpCUtCwhKPzhGaAtOOREiN1+ltp99I+EOU93S90CxkACd/GliR2C6PGHAoGAP2ckS3FOhhzmItrUYWxW0VFERuzvnD3Lt0hOBr6A+8cO9mMKTqVW2lgLOYeyPEPyOFIepJkfMbipNKtGUNqgeKpLD6z76Nk8kqJxE3a9ve93VOZjYZYY7cM6nLfYI5QgMtNsyALLEpoGhpJ2fRS6/6R7AvVZ6k2vH8N3OFtL3YY=
a23ff25b-73f6-48ad-bd42-b2489e0df675	d3abe082-28de-4121-be41-e11ab38ae8b2	priority	100
23bbbc9e-3369-413d-af43-43d4a9616571	d3abe082-28de-4121-be41-e11ab38ae8b2	certificate	MIICmzCCAYMCBgGZtZmjdDANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjUxMDA1MTgxNzQ5WhcNMzUxMDA1MTgxOTI5WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCYcMQA8OE8DB3kK1bVvBw3T80Og76d9kIVl77sfoBra4fPonDa4dQB0W0LRJ6XidU43acr0VUAmtiKj3nESRVYs7KFH0mwS60Zs6FT8J7IGLI3f8UCCGhnI0T/pQWozPXgc8epXzPN4i4PiBhe/ps4gCS8JWH/xp2bDJITpgFNIWTYMacwZR/GBaNGs/0l6vm0aFb80JA+dvfLOcFNbsPyCaBzjjDSwn8hNFP6MwUdE4FihlCpLTP42YQuKr5yX2QowKrkw41ClQtg4+LwxFZEzh3IPItJONzw8LjeqDae8iq6kv52VJpBX9J4FrNCsQy0ScQI6hes6XNyfcWx9khFAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAG31bEwbZBDo5ofu7uAFN/vn92F+K7oDXpMnJwQ8vshdzwwy1nrfOxwTjBMTOD5mZ+xukorZmIgVQ3yvla8QYdeLfErqSa153/dcSTyzcWKq5nOvGcOj4gxOFakZ27OknekHmNPRpTgxaurPL9FTGy73Utk+zrSJqbdHsuu2aLHm/kwrboXKD14XqJdxvonOPAUD2IfWad/ruk/xpKIqtVH6RhUL7F8GJre3FUJm4oeb7fXZ7FD7raHIc6ejFMQdczmpbrwxJPVSVXZu0ixcIBW5i/1IsctYRHPWyx5fmpiHaenilHNLjvvXXe8QDr/KVsFjyZXJMVOpkuWO51LAL4M=
3d66ec0c-30d9-4a59-97ad-dce3dd889ba7	d3abe082-28de-4121-be41-e11ab38ae8b2	keyUse	SIG
37733c9a-02b4-48b9-a912-7941173096f1	ad42ddbf-9dc3-4162-be91-5ba38deacc7e	kid	4ed767d4-6638-4d1f-894f-8c58568b30e5
c0dfa3c7-1bd8-4e0c-b0b1-15d758e303e5	ad42ddbf-9dc3-4162-be91-5ba38deacc7e	secret	5-GnIh4zKH4yD4hBeaDK8w
05347fe9-4d23-4943-9bd9-dc2366cb819c	ad42ddbf-9dc3-4162-be91-5ba38deacc7e	priority	100
a9da98b7-4673-4ae8-842c-a04a2821fa25	77e115e7-7333-4891-8657-e69de605134f	secret	rRBMwbcZi1Hxtb91QTZakbtfNPTNUVIsB7_ssfp447Gcda9tGiFh-TTXP7AZKexPk0wpp3UXlZh5QvDHxSsswoOEHassrLSxyOOFe-Hbz96rUwdVu9l1znvIjT4RSKNybbvac_6tw5b8lITnk2q986ZNizmay-OEpnuYeyFbl8c
321a81c8-086a-45bd-b2a4-63d4949ebe6c	77e115e7-7333-4891-8657-e69de605134f	algorithm	HS512
177b2cf4-30d3-4766-8c01-9ad7bd37a5b8	77e115e7-7333-4891-8657-e69de605134f	priority	100
2b673a19-4edf-4739-982f-5e4a0dfeb004	77e115e7-7333-4891-8657-e69de605134f	kid	ec80841f-aa0f-4319-9105-f2af7bbff279
0fabd4be-fdbc-4e86-bf7c-1b32d44cb7ef	267bafb8-d5a1-4a40-9d2d-1aa59c498c02	max-clients	200
729a7aca-edf7-4ca7-a360-bef0037f77e6	ef527b51-4327-408b-ac4f-e1bc9b5f148b	allowed-protocol-mapper-types	saml-user-property-mapper
599ac216-136b-4aad-aab0-7ee58a53c4dc	ef527b51-4327-408b-ac4f-e1bc9b5f148b	allowed-protocol-mapper-types	saml-role-list-mapper
38628144-fcc8-4bfb-9afa-b1ce55373954	ef527b51-4327-408b-ac4f-e1bc9b5f148b	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
50844bf5-84e0-4afd-a057-03c8495d4202	ef527b51-4327-408b-ac4f-e1bc9b5f148b	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
2ae51ebb-3b26-442b-942c-3220d6e819e5	ef527b51-4327-408b-ac4f-e1bc9b5f148b	allowed-protocol-mapper-types	saml-user-attribute-mapper
7e9677ed-018a-4156-9e40-f2e39198447a	ef527b51-4327-408b-ac4f-e1bc9b5f148b	allowed-protocol-mapper-types	oidc-address-mapper
8357be03-0ac7-463f-b4d8-a975af2a6a3a	ef527b51-4327-408b-ac4f-e1bc9b5f148b	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
cc445302-4a22-4d0c-913b-ef4e458428d1	ef527b51-4327-408b-ac4f-e1bc9b5f148b	allowed-protocol-mapper-types	oidc-full-name-mapper
9258c177-ebb4-4685-bb02-0eef747f8232	7018e516-f9ce-452d-a609-9a12b48e9ff0	allowed-protocol-mapper-types	oidc-full-name-mapper
75b17f40-88e2-46ca-a50f-cf38fdd09a9e	7018e516-f9ce-452d-a609-9a12b48e9ff0	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
5badc011-330a-4663-8118-bfdeb4a852bb	7018e516-f9ce-452d-a609-9a12b48e9ff0	allowed-protocol-mapper-types	saml-role-list-mapper
60537523-05fd-4581-b4b2-6012b88e4e10	7018e516-f9ce-452d-a609-9a12b48e9ff0	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
336c8cf5-584c-4001-b564-1d0dd5162060	7018e516-f9ce-452d-a609-9a12b48e9ff0	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
4df4108f-2b9f-4410-a739-dba9e05acb63	7018e516-f9ce-452d-a609-9a12b48e9ff0	allowed-protocol-mapper-types	saml-user-attribute-mapper
4a6fa418-5149-4529-96f7-c1ffed1c84b3	7018e516-f9ce-452d-a609-9a12b48e9ff0	allowed-protocol-mapper-types	saml-user-property-mapper
f2bdec4a-c1c5-4e44-a7bc-8ecb7ac26b54	7018e516-f9ce-452d-a609-9a12b48e9ff0	allowed-protocol-mapper-types	oidc-address-mapper
0c1d0a14-ed25-436c-b524-25d360bffb68	f3990661-0819-4a67-892a-b92ad2fbe1a8	allow-default-scopes	true
d7df0bc1-1eaa-4f99-82a1-88b0b041a7d2	a69e9517-3d30-4f80-af2f-49ad1340b089	certificate	MIICmzCCAYMCBgGZtaLMqDANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZMaW5xcmEwHhcNMjUxMDA1MTgyNzQ5WhcNMzUxMDA1MTgyOTI5WjARMQ8wDQYDVQQDDAZMaW5xcmEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCOJSMD0VoKTSk5iazDNdFWlX2oZt5+ojKbRB9vd/j3cTDoP/mtwga3HGe2n5IU7ysV2RhTO8VzlXh+qUmC8vkuaMaSVDmdEEdCSocCn2m1OBW0vbJFf6gyBaf87YyNPdjIwKjN2EXYXoHyYAxjQc1ryoEw2fjm5nYi6wTern8qwmPZRsktVcECYrgglumv3GhiLF6rhQoWPZik+FBc5H2FNddV8psrd6Z6mLjD24vm/aj2KmrTzmrs0B3R62eEiuYUSr9STP62PaESiRWbeCg87cIr42qdwRhKtffHAhHVWT3dTzbBSEjnVdEIKY5Sawe1tROu7M5/KjlNOr2JbSEFAgMBAAEwDQYJKoZIhvcNAQELBQADggEBACp3mMYprZVrcMGzVjkhSOSZ1vR+AF35wG++jVsaqnYupnVIVGFLze+ru8oEBgJLO9wuLP9Nu3tyj1jT85ABAgflZurF/zm1+2hTHgBxbqX3/lC/DjT69ipy0T3wjxWUtlIBx8pA5+Amf6SrtR6bq8cJJWV4WU3AgNMn/8QGwsXTKB/KoTJMKrbQMvG7+4JoArYgLQmuYUw8O2j2R/LxsCCP46zZjvzModvgqujIHJCBBBDs/MlT7r7CxRQpOU2M8TEJsD+TJIBERe/Gh21p/eu4IKqGgAqNTMLOsFUQyHw0CQ0ZOgGMTxWx/H/db0uw7KGg3KpSOxN1GFPVB0/ydi8=
ef341e09-5951-419e-870a-2ac0eb479d7c	a69e9517-3d30-4f80-af2f-49ad1340b089	priority	100
f3c9a99b-d5bb-4e06-b1e2-4c822450e117	a69e9517-3d30-4f80-af2f-49ad1340b089	algorithm	RSA-OAEP
7b20c47e-34a4-4cb2-b3ab-523465c19f1f	a69e9517-3d30-4f80-af2f-49ad1340b089	privateKey	MIIEogIBAAKCAQEAjiUjA9FaCk0pOYmswzXRVpV9qGbefqIym0Qfb3f493Ew6D/5rcIGtxxntp+SFO8rFdkYUzvFc5V4fqlJgvL5LmjGklQ5nRBHQkqHAp9ptTgVtL2yRX+oMgWn/O2MjT3YyMCozdhF2F6B8mAMY0HNa8qBMNn45uZ2IusE3q5/KsJj2UbJLVXBAmK4IJbpr9xoYixeq4UKFj2YpPhQXOR9hTXXVfKbK3emepi4w9uL5v2o9ipq085q7NAd0etnhIrmFEq/Ukz+tj2hEokVm3goPO3CK+NqncEYSrX3xwIR1Vk93U82wUhI51XRCCmOUmsHtbUTruzOfyo5TTq9iW0hBQIDAQABAoIBACHcW124tIIBNQmRkA/VhWdih5NC5AwW/8aoYPOpCOwK8PtWaBgaAQcEM3mXxBEMEz+qXkbPlX7t84z6rzoMPsstJuZrPWk6nDsArW40wtXqRRNv3+R53zuBSO3xuZpYyggyitO0ShkblEmEU1cesPxVOlbEiewZKLmzMg8I0t7Aol+7m2cUN+vzOtuMPkor34DZQ+eQEIkq7gia06QBW48kCBHtft/IurwtVhnXnVbyAMJaaUDt1ANT/c9tKV61iQikeAbwIzmdyMl5Ij3SmiInITGyAj1/3v2eCQQnGRuoLWSZsl95W9EP7Plxvo0lOz2MVuk2qDDcHT82wymiFNkCgYEAxXpSAn7JWf5qOUVBw53dWP5ni/4RNyZdxIRXSkVVBi8AaY6EhWzHu8yN9rhAVcHbOlKxjDVEf4or+zqEzlCxT2ZejOLhmVRs7xewkn5AHuOIRChT3DNGYeoW/e94mblo9V8ZoJz9hPYo5hO83lPS0DxPIbWvGfXHPnI0ogGRUu0CgYEAuET9id8KBtjkEizTDv/1xqpcjHK5TevtVlJ5BF99Zx6HM6QTNxCfKGHyRXevefDzZDUva/BmXI+kGqoUFVt4Bngc5WD/u59p7l+L7SO9WBE4ijZ037ZnZ28aoV9F2zjbEUwVY7+KHjfMGZBZQYtL2XPFvhCuRB/pCgr3kqSHy3kCgYArcp0mhWShkzMlxJISiuIPWXHIwC5jduJ8gS1/Xr+1K5QopT2M6YEMVZYKaUFmXM9yBo2frnySnwDMNnTPu7s3H+u/jY9bH9MTy5+Cq5pJ8X+il0jUEsfydQF3/z8Ge1+XVMQbrU6t+UbIUCFmvQSN4ib64LFUwdmDaLchybyChQKBgELOQF1Lz4bL+2PbfGljwudTvFnu/d+SOWmiXN2JAR3xo3LFeXHtRMaPPBaTXbsH8DXUUmz/qxzDtusz3jQgBVPTGCbRE+Yh1XXmjgRbgLn9BFKXi6fPqY2GalE3CUyBQGr0+ow/VQO/lu9tte5dYhJkNrzBr2xjZUmO0FMJ83GBAoGARwc1mozF1lOVlle8ekikt6qk4QZU26SjER/95tS1dBFs05ifLCVV2fo1b1QbpdqB3GqjiLriyAOm+Cdgkq2ua4h2/O/ObhToJQ9qLZPMIoIEEvo+nh8lfqv4NHiUkkGTyCWixw9Y13uJ6s9beAj9Kd90vIDeu8EdK4rxhXNr89s=
56dbfbcf-d655-4352-8363-d55f0bbc78be	2da1798a-fce4-47c6-a2f3-a793044e49fe	priority	100
e5ee99af-24e7-44ac-9709-75c85aef0865	2da1798a-fce4-47c6-a2f3-a793044e49fe	privateKey	MIIEpAIBAAKCAQEAqXjGIlMa48zRXkY9vGack1xR4CKJJcgxu+XDHw2RA3KjOv1iA0JcZY3mkhgvZ03f1jic2BMSPOrmNdPweqrUbK6KqaUm8dROGSflys7w+QZWvfsHkX08CWQuJ36u/3p3D5+cjIFJWcQdZnnAsD5yq4D2ar6mAbWQ8QfnEdktPu7XfXoARPTo5wc2Ceqaq0DrngE5mY34PFfmmj5cetCCQPLe7yZMNCTkGL9lnIH94RiL0zjXT6QWpzri77ADUGzL8wETBirJumzTvEMWwNbUEgVTUdwIuBt8bOhAqX+gOx2XHReGnMQqV+PQ6MJAESJge4snjcONPnT06wUckWA5dQIDAQABAoIBABZCu3/pu6f9kOjZwCU9s0Z2A3k2AB7a35GHWix7izdRORi4DMZR0rIyQ/2fuKZQp9zLPeryAlzHHCso5jcutk16VdN30phEY2fRglE0AporV3yH+1QEh7zSEG/2p4T+cKI4PIeGOfzVEmmSB5n+8fAONhAKb+LclyfZ+mOxS8yuuw4ql/uNKh5sdfQ4vINOG0EE+R8UeGT0zf/gnjgpY2tdgUUKs4RXfy/nxYVb2qFClSoK+j68rL4QuZ/USC6ubiTtxvQFqqtvS+hDiZ5gIB34t7ZZrsh8tx3AdyuI2zexMuJ3C+AxyPzaz0irRnJrMStbmbHJqWj0S4b92v1xsvcCgYEA2oEVPbJNjFD2GB8KHXteGroJOFgf7rQmDJ8+jxk3DcJf5/IX437xJiW1MHvL6JWLBqPreFin/gfPY1Eyu1VFUqFXFgbwmENiDNcRvdFZox1LpH4f6NpxfURuCrWsiuAPBB9unetxO9cfFECjjhDO0LA+Pqv7cobEx+ab2b3zQP8CgYEAxo2wdC3WX1lmHKIhyWtX+21ScvFMRTu7dzM6+mV2UTAVLwdJe13+sD44CTsErmIaUTqJ+8CU1NezPGUF/JTSfNytRyACjDFaG54AYx+VQ7AjsY+brSGlMOGQiA8nLNUauErY0lor+/hduGAEq8uNVxE8fiP7mtNadNsX+P4FEYsCgYEAm6MgVx7e/9hXQl0xnkhWgmEK2jhjHmrxQ0JWlCUYwtM17wfRHjk4Wby4L72uQ4/pRCSUP9eeaWJ0xUB8C1W0mCPV3Rm6XCp697xlpbgtyfK/A37XCcw21ExeuYAoU48/AufEqfWfZUlYmNtl5HZyadFvtMJZy3zVQ7IuRs13LE8CgYBuLpKM5iLgJqwTl6VIMNlSHQhz4JOCl/Mf4r4H1eYih5w5zMFqRG7hPqW5+ZZPbwFLskCABA6TTl+YVDdOQwfLYmqF3a2MPpbSXIu6dfxO45/rGNY67UDOL14VItOKfXembWKE2KUv3lOjzSTKcNquRlJbbXxiHodD8ZEMC2qkoQKBgQDFsq16fX5vrxM2XmJ53r1avEURc3u2e2fnVKf108oyZCrIWu0M0mO1WkyAJHzopozSXfTkG5Y32oY9+g8p0l2y65G2iYvcfPZj1JZHnwzzZuC4iV7sfEW+hgSx/NtJaY8KbUAgqsIzwCVg7vpxV5S7+I2sbNF5wY5tXMbxSbuTSQ==
f35bf078-18d2-4fda-8454-a3d76811a18b	2da1798a-fce4-47c6-a2f3-a793044e49fe	certificate	MIICmzCCAYMCBgGZtaLNFzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZMaW5xcmEwHhcNMjUxMDA1MTgyNzQ5WhcNMzUxMDA1MTgyOTI5WjARMQ8wDQYDVQQDDAZMaW5xcmEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpeMYiUxrjzNFeRj28ZpyTXFHgIoklyDG75cMfDZEDcqM6/WIDQlxljeaSGC9nTd/WOJzYExI86uY10/B6qtRsroqppSbx1E4ZJ+XKzvD5Bla9+weRfTwJZC4nfq7/encPn5yMgUlZxB1mecCwPnKrgPZqvqYBtZDxB+cR2S0+7td9egBE9OjnBzYJ6pqrQOueATmZjfg8V+aaPlx60IJA8t7vJkw0JOQYv2Wcgf3hGIvTONdPpBanOuLvsANQbMvzARMGKsm6bNO8QxbA1tQSBVNR3Ai4G3xs6ECpf6A7HZcdF4acxCpX49DowkARImB7iyeNw40+dPTrBRyRYDl1AgMBAAEwDQYJKoZIhvcNAQELBQADggEBAABagqPpxs37Cjm4/+HLLWFmb+tmXiW2fbWuzAp0Fa7T9TxuU3QUkx6Dnc3Sv/7uQ35HmClbGPgGJLmWpkQao6ihmB3glZioFqpID9vjvq+2EXwDqSfSoK2tZ1rnaPddavvdk6Tf+WZyEXMbsv0saepce5hm/52iKrakvEzZo7kIUigHtt7ofDMx2hiKdaVrAmP+pEFAEAxlp/FQpwx6t28XYFAXREGw919BEpKnk1qeC9tTmKR5dcM2JAVOo+IFIpgXBaykrGmcqh/g/YE7M6GUDRkK/gOlNc2nw1D7zfViG8PeG0yCf7iA4huqjTYP89qgHLWtTWtGC3RzLFR9mq4=
b1d4ad58-a512-4040-8a80-356b756791b3	78585f6d-7b4b-4424-9d21-6328b1cf5a02	secret	fqsgeya0jHMDVft1Th5ErQ
cf04a829-6353-45ef-92d4-5924c0523d1b	78585f6d-7b4b-4424-9d21-6328b1cf5a02	priority	100
2b6b6984-787f-4f20-9491-9d8dd62302af	78585f6d-7b4b-4424-9d21-6328b1cf5a02	kid	6d9bfd7f-0008-400e-9735-01eaa1822aef
2e570a12-26dd-4221-b04a-60ce19b75904	822808d7-d95f-4ef2-a67a-d33613d09cd9	allow-default-scopes	true
f28c92ad-37bf-4441-b7e9-2e6d71f30562	23bd4700-e352-4ad4-960e-06bcfa3903c3	host-sending-registration-request-must-match	true
a6ecc205-0d2f-4655-833a-2ddb48baaaaf	23bd4700-e352-4ad4-960e-06bcfa3903c3	client-uris-must-match	true
e70e78aa-9f53-456f-a9dd-ff4a42c00822	343b222d-b239-4d7d-a881-a4daa9d1b2a1	kid	05d729f8-cc6b-4923-bd1c-0964ea14f933
e93bc94d-59be-4374-ae37-6827864f1d52	343b222d-b239-4d7d-a881-a4daa9d1b2a1	secret	25kI1TTpHbHYVEtDA7RjEZ7sCAzZl9lW6PAvZRIdMqqVkHvplPYl8QMl40XhzOeh6W7GWUYoITit1wnp9GAhf1pwFQdfxGK5ELEJeNrvvsQtdxWxqRQufPJLh3_tA7a86fZqEf--gCiYAVKop24CcH1JLfsqNx-w-P0EvDf5lrU
2e83c158-fa53-4263-9211-cf5a387a63c5	343b222d-b239-4d7d-a881-a4daa9d1b2a1	priority	100
544ebfe4-f111-49c3-ad1d-53f4ecc05e49	343b222d-b239-4d7d-a881-a4daa9d1b2a1	algorithm	HS512
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.composite_role (composite, child_role) FROM stdin;
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	8017d7aa-a428-4d16-bc2d-dd5dfc217ac3
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	100a12fa-3668-44db-8ee0-38f5ef711ee7
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	ad7a0692-e5bf-476e-b6f9-882f88a67a07
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	d4d9992e-5171-411f-b0c8-b84e670c2129
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	f2ff7d0e-bafb-4d8b-872c-31245765864d
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	bc0ad0a3-fcc9-4bbb-94f4-d923e9ce5942
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	11437b36-4950-4456-8702-9706d1c7bd8c
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	2bf4e056-0e22-4a99-98bf-2b3491f2a766
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	453503b1-2b35-4382-83d8-ade9d9ecd72f
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	ee3b751e-18f4-4b7f-b9f1-8e536b217590
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	a0838c35-3f89-4772-b1ae-c53f0a419776
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	736a1881-50a0-4f27-96f4-c85f39ef372e
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	116bcb74-6aa1-40c8-9e68-a57ad284829f
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	8dbb9bdb-376b-4dd1-8ec5-209aaac29dfe
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	a33ad304-b52a-4a94-9fcc-30dc4af7e0e0
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	c41995fa-cdd5-49db-93f2-c410ee5f9c5b
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	225d6cb4-92ad-4a86-9af2-b47bc4e788d0
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	572efbe2-dbe8-41ad-acba-4c0bd3a21d83
1b500e6d-2a2e-4210-b0b9-4abd2cad2a1d	5edb528e-7120-4238-97ff-7148f397a336
d4d9992e-5171-411f-b0c8-b84e670c2129	572efbe2-dbe8-41ad-acba-4c0bd3a21d83
d4d9992e-5171-411f-b0c8-b84e670c2129	a33ad304-b52a-4a94-9fcc-30dc4af7e0e0
f2ff7d0e-bafb-4d8b-872c-31245765864d	c41995fa-cdd5-49db-93f2-c410ee5f9c5b
1b500e6d-2a2e-4210-b0b9-4abd2cad2a1d	9d14fd06-b39e-4f9a-8fa5-e010efd2f9a6
9d14fd06-b39e-4f9a-8fa5-e010efd2f9a6	7f33fc43-2229-44fb-a8a6-b8e23716acfa
d182172d-1128-4742-9723-60520429b75f	c46cd14e-b235-4094-ae05-88f09cc51e1e
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	7c567c96-f8c4-4e5b-abb4-b9933752ec96
1b500e6d-2a2e-4210-b0b9-4abd2cad2a1d	49327fa4-6460-4648-b0de-bad086225537
1b500e6d-2a2e-4210-b0b9-4abd2cad2a1d	c573f251-6ba8-414e-b351-ffb48a3f6ae7
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	680023c2-1a2a-460a-a330-5ac153b9c19c
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	ce3f1433-028d-4be5-88ec-753aa795b915
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	68b451e2-2fa3-4d39-8559-6df698e041f6
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	edfe465f-eeed-4c6d-a3b1-f0fc259c292c
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	6080dda4-68c4-4e11-9574-379e4e626b85
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	aba6e9b2-d130-4fc0-b06e-3e1c93118bd7
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	770e2ccb-f480-4d9b-8587-63dc5ef1519a
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	7d98bd5d-e4d2-4744-9ff1-4eeb9aeec487
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	c491c41d-7071-4e59-b819-d98f9c372964
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	29980031-1c3e-4809-8c1f-6ec7c0f27000
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	5f57c72b-a797-4545-86e2-bb5b198eb998
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	45df6300-7208-4245-a47f-38ed021d6de2
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	103c4cda-d3ba-49b8-921f-a3f0ef5d2a7f
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	cafbfc65-2e52-42e5-ba70-2485039d4daf
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	1e8ff368-dbd5-4591-b2ea-4916771cbf4a
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	70735a16-4e3b-444f-8cc8-423ea5014382
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	7c07f825-9cba-4b66-aa6f-e50e8ef3521f
68b451e2-2fa3-4d39-8559-6df698e041f6	7c07f825-9cba-4b66-aa6f-e50e8ef3521f
68b451e2-2fa3-4d39-8559-6df698e041f6	cafbfc65-2e52-42e5-ba70-2485039d4daf
edfe465f-eeed-4c6d-a3b1-f0fc259c292c	1e8ff368-dbd5-4591-b2ea-4916771cbf4a
31394836-54ec-4ed7-b108-bdef64964f48	a770d584-34e2-4421-b1f6-67b224890e83
328102d3-b939-4b9e-ab11-d8fa76c59484	68c9e30d-77e9-4b6d-93d4-7405083e25ca
328102d3-b939-4b9e-ab11-d8fa76c59484	834407e8-51cc-4949-be0b-6869b18295b6
328102d3-b939-4b9e-ab11-d8fa76c59484	be737ea0-aaf8-4d70-84c1-76e16323d06f
328102d3-b939-4b9e-ab11-d8fa76c59484	71c1cf12-4aca-4fb1-927a-8254f24fbb1e
328102d3-b939-4b9e-ab11-d8fa76c59484	6eeae823-2513-422e-9fb6-0ddef3bbedec
328102d3-b939-4b9e-ab11-d8fa76c59484	f1da62f3-04d5-45b8-955b-02ed23f070ce
328102d3-b939-4b9e-ab11-d8fa76c59484	ce23597f-6f5c-4e23-8c7c-fdb9fcf749e5
328102d3-b939-4b9e-ab11-d8fa76c59484	96f3eee2-e472-4eef-9506-25e22bf9bed6
328102d3-b939-4b9e-ab11-d8fa76c59484	b4d16d50-0a15-4a69-b5bc-875298832827
328102d3-b939-4b9e-ab11-d8fa76c59484	ea4a2945-780c-42a8-b82b-99725f6ff7a3
328102d3-b939-4b9e-ab11-d8fa76c59484	ee613a7e-ff96-4bee-84d6-930f8582529b
328102d3-b939-4b9e-ab11-d8fa76c59484	d2f429e8-a9d0-4e5f-bcd9-084129eaffab
328102d3-b939-4b9e-ab11-d8fa76c59484	e1a77158-c744-4d96-9fc0-7da6e4c8de2d
328102d3-b939-4b9e-ab11-d8fa76c59484	8c57d95d-6c99-4423-95ab-fe4e53cb9b83
328102d3-b939-4b9e-ab11-d8fa76c59484	70d56dfb-07fd-4239-a00a-046fe35a92bb
328102d3-b939-4b9e-ab11-d8fa76c59484	9ceea42c-cf36-4800-9ce1-6b9fdaef9aa9
328102d3-b939-4b9e-ab11-d8fa76c59484	571552b5-a472-4959-a080-3d174bccfb00
328102d3-b939-4b9e-ab11-d8fa76c59484	55c0bd79-2b6f-49b7-82bb-e9f64ac357ca
45609a37-719b-40d8-bcc8-e4e9cc614416	50956bc7-d0ee-4039-a9c9-c26c97099337
45609a37-719b-40d8-bcc8-e4e9cc614416	51cb8d42-5a64-480b-b631-8e4c81dc90b2
45609a37-719b-40d8-bcc8-e4e9cc614416	31394836-54ec-4ed7-b108-bdef64964f48
45609a37-719b-40d8-bcc8-e4e9cc614416	c7bdb876-a200-472c-a003-3a5fd1520190
b4d16d50-0a15-4a69-b5bc-875298832827	70d56dfb-07fd-4239-a00a-046fe35a92bb
e1a77158-c744-4d96-9fc0-7da6e4c8de2d	571552b5-a472-4959-a080-3d174bccfb00
e1a77158-c744-4d96-9fc0-7da6e4c8de2d	55c0bd79-2b6f-49b7-82bb-e9f64ac357ca
fedbc438-7b78-4c5f-8f91-61461aa58331	5833d875-ca90-49a4-9701-9bc1c761dc00
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	256689bf-3110-4e6a-9eac-3392f765e4dc
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority, version) FROM stdin;
543727fb-a5c9-4a1f-9201-26c14d5b0461	\N	password	bba243e8-4c79-4da5-8063-667c7e041b0e	1759689412696	My password	{"value":"2a0paGpBtJc7ihlZ5yGT8Oj95AcKMWGBHURLeBXz1Rk=","salt":"NFgzVsQlrI8vtlKLFAFPiA==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10	1
ea043c13-bfc1-445c-94b2-26b97be7a317	\N	password	8697b1cc-57e8-4536-88d8-d6cf67d29485	1765409128253	My password	{"value":"qsqx7wG8XuLxtFoOJWHMDxF4EGb35YoZUj0z8BorLJ8=","salt":"F1Ol1edtg2XmlI1SXOtxrg==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10	2
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2025-10-05 18:19:24.900509	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.33.0	\N	\N	9688362888
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2025-10-05 18:19:24.91004	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.33.0	\N	\N	9688362888
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2025-10-05 18:19:24.931574	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.33.0	\N	\N	9688362888
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2025-10-05 18:19:24.933451	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.33.0	\N	\N	9688362888
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2025-10-05 18:19:24.976257	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.33.0	\N	\N	9688362888
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2025-10-05 18:19:24.978858	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.33.0	\N	\N	9688362888
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2025-10-05 18:19:25.011266	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.33.0	\N	\N	9688362888
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2025-10-05 18:19:25.013565	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.33.0	\N	\N	9688362888
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2025-10-05 18:19:25.015625	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.33.0	\N	\N	9688362888
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2025-10-05 18:19:25.050775	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.33.0	\N	\N	9688362888
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2025-10-05 18:19:25.068326	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.33.0	\N	\N	9688362888
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2025-10-05 18:19:25.069646	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.33.0	\N	\N	9688362888
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2025-10-05 18:19:25.075166	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.33.0	\N	\N	9688362888
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-10-05 18:19:25.082155	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.33.0	\N	\N	9688362888
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-10-05 18:19:25.082612	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-10-05 18:19:25.083294	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.33.0	\N	\N	9688362888
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-10-05 18:19:25.084054	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.33.0	\N	\N	9688362888
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2025-10-05 18:19:25.099139	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.33.0	\N	\N	9688362888
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2025-10-05 18:19:25.115078	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.33.0	\N	\N	9688362888
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2025-10-05 18:19:25.117034	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.33.0	\N	\N	9688362888
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2025-10-05 18:19:26.569401	119	MARK_RAN	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.33.0	\N	\N	9688362888
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2025-10-05 18:19:25.118284	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.33.0	\N	\N	9688362888
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2025-10-05 18:19:25.120093	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.33.0	\N	\N	9688362888
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2025-10-05 18:19:25.150831	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.33.0	\N	\N	9688362888
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2025-10-05 18:19:25.15321	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.33.0	\N	\N	9688362888
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2025-10-05 18:19:25.154022	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.33.0	\N	\N	9688362888
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2025-10-05 18:19:25.27101	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.33.0	\N	\N	9688362888
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2025-10-05 18:19:25.299685	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.33.0	\N	\N	9688362888
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2025-10-05 18:19:25.305219	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.33.0	\N	\N	9688362888
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2025-10-05 18:19:25.336171	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.33.0	\N	\N	9688362888
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2025-10-05 18:19:25.342733	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.33.0	\N	\N	9688362888
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2025-10-05 18:19:25.349705	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.33.0	\N	\N	9688362888
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2025-10-05 18:19:25.350993	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.33.0	\N	\N	9688362888
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-10-05 18:19:25.352904	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-10-05 18:19:25.353596	34	MARK_RAN	9:f9753208029f582525ed12011a19d054	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.33.0	\N	\N	9688362888
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-10-05 18:19:25.361958	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.33.0	\N	\N	9688362888
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2025-10-05 18:19:25.36374	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.33.0	\N	\N	9688362888
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-10-05 18:19:25.365423	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.33.0	\N	\N	9688362888
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2025-10-05 18:19:25.366554	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.33.0	\N	\N	9688362888
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2025-10-05 18:19:25.367441	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.33.0	\N	\N	9688362888
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-10-05 18:19:25.367893	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.33.0	\N	\N	9688362888
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-10-05 18:19:25.368455	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.33.0	\N	\N	9688362888
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2025-10-05 18:19:25.369991	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.33.0	\N	\N	9688362888
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-10-05 18:19:25.807251	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.33.0	\N	\N	9688362888
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2025-10-05 18:19:25.808732	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.33.0	\N	\N	9688362888
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-10-05 18:19:25.809885	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.33.0	\N	\N	9688362888
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-10-05 18:19:25.811314	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.33.0	\N	\N	9688362888
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-10-05 18:19:25.811733	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.33.0	\N	\N	9688362888
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-10-05 18:19:25.845632	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.33.0	\N	\N	9688362888
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-10-05 18:19:25.847268	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.33.0	\N	\N	9688362888
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2025-10-05 18:19:25.858348	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.33.0	\N	\N	9688362888
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2025-10-05 18:19:25.986487	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.33.0	\N	\N	9688362888
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2025-10-05 18:19:25.987746	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2025-10-05 18:19:25.988705	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.33.0	\N	\N	9688362888
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2025-10-05 18:19:25.989523	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.33.0	\N	\N	9688362888
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-10-05 18:19:25.991621	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.33.0	\N	\N	9688362888
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-10-05 18:19:25.993923	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.33.0	\N	\N	9688362888
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-10-05 18:19:26.01451	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.33.0	\N	\N	9688362888
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-10-05 18:19:26.189582	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.33.0	\N	\N	9688362888
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2025-10-05 18:19:26.200067	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.33.0	\N	\N	9688362888
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2025-10-05 18:19:26.202159	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.33.0	\N	\N	9688362888
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2025-10-05 18:19:26.205106	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.33.0	\N	\N	9688362888
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2025-10-05 18:19:26.206496	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.33.0	\N	\N	9688362888
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2025-10-05 18:19:26.207437	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.33.0	\N	\N	9688362888
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2025-10-05 18:19:26.208702	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.33.0	\N	\N	9688362888
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2025-10-05 18:19:26.209736	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.33.0	\N	\N	9688362888
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2025-10-05 18:19:26.228087	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.33.0	\N	\N	9688362888
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2025-10-05 18:19:26.244278	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.33.0	\N	\N	9688362888
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2025-10-05 18:19:26.245917	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.33.0	\N	\N	9688362888
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2025-10-05 18:19:26.266059	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.33.0	\N	\N	9688362888
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2025-10-05 18:19:26.268806	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.33.0	\N	\N	9688362888
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2025-10-05 18:19:26.271168	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.33.0	\N	\N	9688362888
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-10-05 18:19:26.273119	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.33.0	\N	\N	9688362888
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-10-05 18:19:26.276407	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.33.0	\N	\N	9688362888
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-10-05 18:19:26.277328	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.33.0	\N	\N	9688362888
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-10-05 18:19:26.285527	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.33.0	\N	\N	9688362888
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-10-05 18:19:26.302324	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.33.0	\N	\N	9688362888
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-10-05 18:19:26.303624	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.33.0	\N	\N	9688362888
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-10-05 18:19:26.304132	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.33.0	\N	\N	9688362888
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-10-05 18:19:26.310589	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.33.0	\N	\N	9688362888
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-10-05 18:19:26.311236	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.33.0	\N	\N	9688362888
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-10-05 18:19:26.327356	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.33.0	\N	\N	9688362888
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-10-05 18:19:26.327972	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.33.0	\N	\N	9688362888
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-10-05 18:19:26.330014	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.33.0	\N	\N	9688362888
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-10-05 18:19:26.330421	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.33.0	\N	\N	9688362888
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-10-05 18:19:26.34583	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.33.0	\N	\N	9688362888
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2025-10-05 18:19:26.347185	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.33.0	\N	\N	9688362888
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2025-10-05 18:19:26.349194	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.33.0	\N	\N	9688362888
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2025-10-05 18:19:26.352212	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.33.0	\N	\N	9688362888
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-10-05 18:19:26.353763	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.33.0	\N	\N	9688362888
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-10-05 18:19:26.356827	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.33.0	\N	\N	9688362888
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-10-05 18:19:26.370513	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-10-05 18:19:26.372404	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.33.0	\N	\N	9688362888
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-10-05 18:19:26.372802	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.33.0	\N	\N	9688362888
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-10-05 18:19:26.376203	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.33.0	\N	\N	9688362888
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-10-05 18:19:26.376853	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.33.0	\N	\N	9688362888
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-10-05 18:19:26.379075	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.33.0	\N	\N	9688362888
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-10-05 18:19:26.421698	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-10-05 18:19:26.422313	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-10-05 18:19:26.429145	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-10-05 18:19:26.444169	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-10-05 18:19:26.444691	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-10-05 18:19:26.459194	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.33.0	\N	\N	9688362888
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-10-05 18:19:26.460483	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.33.0	\N	\N	9688362888
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2025-10-05 18:19:26.46277	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.33.0	\N	\N	9688362888
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2025-10-05 18:19:26.479301	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.33.0	\N	\N	9688362888
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2025-10-05 18:19:26.494932	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.33.0	\N	\N	9688362888
18.0.15-30992-index-consent	keycloak	META-INF/jpa-changelog-18.0.15.xml	2025-10-05 18:19:26.511764	107	EXECUTED	9:80071ede7a05604b1f4906f3bf3b00f0	createIndex indexName=IDX_USCONSENT_SCOPE_ID, tableName=USER_CONSENT_CLIENT_SCOPE		\N	4.33.0	\N	\N	9688362888
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2025-10-05 18:19:26.513288	108	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.33.0	\N	\N	9688362888
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-10-05 18:19:26.528902	109	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.33.0	\N	\N	9688362888
20.0.0-12964-supported-dbs-edb-migration	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-10-05 18:19:26.549841	110	EXECUTED	9:a6b18a8e38062df5793edbe064f4aecd	dropIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE; createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.33.0	\N	\N	9688362888
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-10-05 18:19:26.550476	111	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.33.0	\N	\N	9688362888
client-attributes-string-accomodation-fixed-pre-drop-index	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-10-05 18:19:26.551893	112	EXECUTED	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-10-05 18:19:26.553375	113	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
client-attributes-string-accomodation-fixed-post-create-index	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-10-05 18:19:26.553808	114	MARK_RAN	9:bd2bd0fc7768cf0845ac96a8786fa735	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2025-10-05 18:19:26.555182	115	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.33.0	\N	\N	9688362888
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2025-10-05 18:19:26.566723	116	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.33.0	\N	\N	9688362888
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2025-10-05 18:19:26.567714	117	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.33.0	\N	\N	9688362888
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2025-10-05 18:19:26.56904	118	EXECUTED	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.33.0	\N	\N	9688362888
23.0.0-12062	keycloak	META-INF/jpa-changelog-23.0.0.xml	2025-10-05 18:19:26.571995	120	EXECUTED	9:2168fbe728fec46ae9baf15bf80927b8	addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG		\N	4.33.0	\N	\N	9688362888
23.0.0-17258	keycloak	META-INF/jpa-changelog-23.0.0.xml	2025-10-05 18:19:26.573946	121	EXECUTED	9:36506d679a83bbfda85a27ea1864dca8	addColumn tableName=EVENT_ENTITY		\N	4.33.0	\N	\N	9688362888
24.0.0-9758	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-10-05 18:19:26.630006	122	EXECUTED	9:502c557a5189f600f0f445a9b49ebbce	addColumn tableName=USER_ATTRIBUTE; addColumn tableName=FED_USER_ATTRIBUTE; createIndex indexName=USER_ATTR_LONG_VALUES, tableName=USER_ATTRIBUTE; createIndex indexName=FED_USER_ATTR_LONG_VALUES, tableName=FED_USER_ATTRIBUTE; createIndex indexName...		\N	4.33.0	\N	\N	9688362888
24.0.0-9758-2	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-10-05 18:19:26.632025	123	EXECUTED	9:bf0fdee10afdf597a987adbf291db7b2	customChange		\N	4.33.0	\N	\N	9688362888
24.0.0-26618-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-10-05 18:19:26.634147	124	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
24.0.0-26618-reindex	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-10-05 18:19:26.648566	125	EXECUTED	9:08707c0f0db1cef6b352db03a60edc7f	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
24.0.0-26618-edb-migration	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-10-05 18:19:26.667297	126	EXECUTED	9:2f684b29d414cd47efe3a3599f390741	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES; createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
24.0.2-27228	keycloak	META-INF/jpa-changelog-24.0.2.xml	2025-10-05 18:19:26.668869	127	EXECUTED	9:eaee11f6b8aa25d2cc6a84fb86fc6238	customChange		\N	4.33.0	\N	\N	9688362888
24.0.2-27967-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.2.xml	2025-10-05 18:19:26.669317	128	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
24.0.2-27967-reindex	keycloak	META-INF/jpa-changelog-24.0.2.xml	2025-10-05 18:19:26.671243	129	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.33.0	\N	\N	9688362888
25.0.0-28265-tables	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.672501	130	EXECUTED	9:deda2df035df23388af95bbd36c17cef	addColumn tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_CLIENT_SESSION		\N	4.33.0	\N	\N	9688362888
25.0.0-28265-index-creation	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.686636	131	EXECUTED	9:3e96709818458ae49f3c679ae58d263a	createIndex indexName=IDX_OFFLINE_USS_BY_LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
25.0.0-28265-index-cleanup-uss-createdon	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.68903	132	EXECUTED	9:78ab4fc129ed5e8265dbcc3485fba92f	dropIndex indexName=IDX_OFFLINE_USS_CREATEDON, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
25.0.0-28265-index-cleanup-uss-preload	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.691147	133	EXECUTED	9:de5f7c1f7e10994ed8b62e621d20eaab	dropIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
25.0.0-28265-index-cleanup-uss-by-usersess	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.694076	134	EXECUTED	9:6eee220d024e38e89c799417ec33667f	dropIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
25.0.0-28265-index-cleanup-css-preload	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.696721	135	EXECUTED	9:5411d2fb2891d3e8d63ddb55dfa3c0c9	dropIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION		\N	4.33.0	\N	\N	9688362888
25.0.0-28265-index-2-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.697343	136	MARK_RAN	9:b7ef76036d3126bb83c2423bf4d449d6	createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
25.0.0-28265-index-2-not-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.714002	137	EXECUTED	9:23396cf51ab8bc1ae6f0cac7f9f6fcf7	createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION		\N	4.33.0	\N	\N	9688362888
25.0.0-org	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.720239	138	EXECUTED	9:5c859965c2c9b9c72136c360649af157	createTable tableName=ORG; addUniqueConstraint constraintName=UK_ORG_NAME, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_GROUP, tableName=ORG; createTable tableName=ORG_DOMAIN		\N	4.33.0	\N	\N	9688362888
unique-consentuser	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.724196	139	EXECUTED	9:5857626a2ea8767e9a6c66bf3a2cb32f	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.33.0	\N	\N	9688362888
unique-consentuser-edb-migration	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.729859	140	MARK_RAN	9:5857626a2ea8767e9a6c66bf3a2cb32f	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.33.0	\N	\N	9688362888
unique-consentuser-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.73055	141	MARK_RAN	9:b79478aad5adaa1bc428e31563f55e8e	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.33.0	\N	\N	9688362888
25.0.0-28861-index-creation	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-10-05 18:19:26.760326	142	EXECUTED	9:b9acb58ac958d9ada0fe12a5d4794ab1	createIndex indexName=IDX_PERM_TICKET_REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; createIndex indexName=IDX_PERM_TICKET_OWNER, tableName=RESOURCE_SERVER_PERM_TICKET		\N	4.33.0	\N	\N	9688362888
26.0.0-org-alias	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.763315	143	EXECUTED	9:6ef7d63e4412b3c2d66ed179159886a4	addColumn tableName=ORG; update tableName=ORG; addNotNullConstraint columnName=ALIAS, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_ALIAS, tableName=ORG		\N	4.33.0	\N	\N	9688362888
26.0.0-org-group	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.766188	144	EXECUTED	9:da8e8087d80ef2ace4f89d8c5b9ca223	addColumn tableName=KEYCLOAK_GROUP; update tableName=KEYCLOAK_GROUP; addNotNullConstraint columnName=TYPE, tableName=KEYCLOAK_GROUP; customChange		\N	4.33.0	\N	\N	9688362888
26.0.0-org-indexes	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.785363	145	EXECUTED	9:79b05dcd610a8c7f25ec05135eec0857	createIndex indexName=IDX_ORG_DOMAIN_ORG_ID, tableName=ORG_DOMAIN		\N	4.33.0	\N	\N	9688362888
26.0.0-org-group-membership	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.787462	146	EXECUTED	9:a6ace2ce583a421d89b01ba2a28dc2d4	addColumn tableName=USER_GROUP_MEMBERSHIP; update tableName=USER_GROUP_MEMBERSHIP; addNotNullConstraint columnName=MEMBERSHIP_TYPE, tableName=USER_GROUP_MEMBERSHIP		\N	4.33.0	\N	\N	9688362888
31296-persist-revoked-access-tokens	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.789764	147	EXECUTED	9:64ef94489d42a358e8304b0e245f0ed4	createTable tableName=REVOKED_TOKEN; addPrimaryKey constraintName=CONSTRAINT_RT, tableName=REVOKED_TOKEN		\N	4.33.0	\N	\N	9688362888
31725-index-persist-revoked-access-tokens	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.802893	148	EXECUTED	9:b994246ec2bf7c94da881e1d28782c7b	createIndex indexName=IDX_REV_TOKEN_ON_EXPIRE, tableName=REVOKED_TOKEN		\N	4.33.0	\N	\N	9688362888
26.0.0-idps-for-login	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.834711	149	EXECUTED	9:51f5fffadf986983d4bd59582c6c1604	addColumn tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_REALM_ORG, tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_FOR_LOGIN, tableName=IDENTITY_PROVIDER; customChange		\N	4.33.0	\N	\N	9688362888
26.0.0-32583-drop-redundant-index-on-client-session	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.839444	150	EXECUTED	9:24972d83bf27317a055d234187bb4af9	dropIndex indexName=IDX_US_SESS_ID_ON_CL_SESS, tableName=OFFLINE_CLIENT_SESSION		\N	4.33.0	\N	\N	9688362888
26.0.0.32582-remove-tables-user-session-user-session-note-and-client-session	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.848277	151	EXECUTED	9:febdc0f47f2ed241c59e60f58c3ceea5	dropTable tableName=CLIENT_SESSION_ROLE; dropTable tableName=CLIENT_SESSION_NOTE; dropTable tableName=CLIENT_SESSION_PROT_MAPPER; dropTable tableName=CLIENT_SESSION_AUTH_STATUS; dropTable tableName=CLIENT_USER_SESSION_NOTE; dropTable tableName=CLI...		\N	4.33.0	\N	\N	9688362888
26.0.0-33201-org-redirect-url	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-10-05 18:19:26.849372	152	EXECUTED	9:4d0e22b0ac68ebe9794fa9cb752ea660	addColumn tableName=ORG		\N	4.33.0	\N	\N	9688362888
29399-jdbc-ping-default	keycloak	META-INF/jpa-changelog-26.1.0.xml	2025-10-05 18:19:26.852544	153	EXECUTED	9:007dbe99d7203fca403b89d4edfdf21e	createTable tableName=JGROUPS_PING; addPrimaryKey constraintName=CONSTRAINT_JGROUPS_PING, tableName=JGROUPS_PING		\N	4.33.0	\N	\N	9688362888
26.1.0-34013	keycloak	META-INF/jpa-changelog-26.1.0.xml	2025-10-05 18:19:26.854548	154	EXECUTED	9:e6b686a15759aef99a6d758a5c4c6a26	addColumn tableName=ADMIN_EVENT_ENTITY		\N	4.33.0	\N	\N	9688362888
26.1.0-34380	keycloak	META-INF/jpa-changelog-26.1.0.xml	2025-10-05 18:19:26.856566	155	EXECUTED	9:ac8b9edb7c2b6c17a1c7a11fcf5ccf01	dropTable tableName=USERNAME_LOGIN_FAILURE		\N	4.33.0	\N	\N	9688362888
26.2.0-36750	keycloak	META-INF/jpa-changelog-26.2.0.xml	2025-10-05 18:19:26.859289	156	EXECUTED	9:b49ce951c22f7eb16480ff085640a33a	createTable tableName=SERVER_CONFIG		\N	4.33.0	\N	\N	9688362888
26.2.0-26106	keycloak	META-INF/jpa-changelog-26.2.0.xml	2025-10-05 18:19:26.860351	157	EXECUTED	9:b5877d5dab7d10ff3a9d209d7beb6680	addColumn tableName=CREDENTIAL		\N	4.33.0	\N	\N	9688362888
26.2.6-39866-duplicate	keycloak	META-INF/jpa-changelog-26.2.6.xml	2025-10-05 18:19:26.861527	158	EXECUTED	9:1dc67ccee24f30331db2cba4f372e40e	customChange		\N	4.33.0	\N	\N	9688362888
26.2.6-39866-uk	keycloak	META-INF/jpa-changelog-26.2.6.xml	2025-10-05 18:19:26.863511	159	EXECUTED	9:b70b76f47210cf0a5f4ef0e219eac7cd	addUniqueConstraint constraintName=UK_MIGRATION_VERSION, tableName=MIGRATION_MODEL		\N	4.33.0	\N	\N	9688362888
26.2.6-40088-duplicate	keycloak	META-INF/jpa-changelog-26.2.6.xml	2025-10-05 18:19:26.864484	160	EXECUTED	9:cc7e02ed69ab31979afb1982f9670e8f	customChange		\N	4.33.0	\N	\N	9688362888
26.2.6-40088-uk	keycloak	META-INF/jpa-changelog-26.2.6.xml	2025-10-05 18:19:26.865772	161	EXECUTED	9:5bb848128da7bc4595cc507383325241	addUniqueConstraint constraintName=UK_MIGRATION_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.33.0	\N	\N	9688362888
26.3.0-groups-description	keycloak	META-INF/jpa-changelog-26.3.0.xml	2025-10-05 18:19:26.867622	162	EXECUTED	9:e1a3c05574326fb5b246b73b9a4c4d49	addColumn tableName=KEYCLOAK_GROUP		\N	4.33.0	\N	\N	9688362888
26.4.0-40933-saml-encryption-attributes	keycloak	META-INF/jpa-changelog-26.4.0.xml	2025-10-05 18:19:26.868762	163	EXECUTED	9:7e9eaba362ca105efdda202303a4fe49	customChange		\N	4.33.0	\N	\N	9688362888
26.4.0-51321	keycloak	META-INF/jpa-changelog-26.4.0.xml	2025-10-05 18:19:26.883495	164	EXECUTED	9:34bab2bc56f75ffd7e347c580874e306	createIndex indexName=IDX_EVENT_ENTITY_USER_ID_TYPE, tableName=EVENT_ENTITY		\N	4.33.0	\N	\N	9688362888
40343-workflow-state-table	keycloak	META-INF/jpa-changelog-26.4.0.xml	2025-10-05 18:19:26.910437	165	EXECUTED	9:ed3ab4723ceed210e5b5e60ac4562106	createTable tableName=WORKFLOW_STATE; addPrimaryKey constraintName=PK_WORKFLOW_STATE, tableName=WORKFLOW_STATE; addUniqueConstraint constraintName=UQ_WORKFLOW_RESOURCE, tableName=WORKFLOW_STATE; createIndex indexName=IDX_WORKFLOW_STATE_STEP, table...		\N	4.33.0	\N	\N	9688362888
26.5.0-index-offline-css-by-client	keycloak	META-INF/jpa-changelog-26.5.0.xml	2025-11-24 00:18:13.861067	166	EXECUTED	9:383e981ce95d16e32af757b7998820f7	createIndex indexName=IDX_OFFLINE_CSS_BY_CLIENT, tableName=OFFLINE_CLIENT_SESSION		\N	4.33.0	\N	\N	3943492295
26.5.0-index-offline-css-by-client-storage-provider	keycloak	META-INF/jpa-changelog-26.5.0.xml	2025-11-24 00:18:13.888171	167	EXECUTED	9:f5bc200e6fa7d7e483854dee535ca425	createIndex indexName=IDX_OFFLINE_CSS_BY_CLIENT_STORAGE_PROVIDER, tableName=OFFLINE_CLIENT_SESSION		\N	4.33.0	\N	\N	3943492295
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	19b176e1-4a7e-42be-8de5-6407f497c093	f
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	b53929e1-a35f-4ce5-9657-da1a05edd3e5	t
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	5499f689-3ad8-47f1-8442-0fde64fdc8ac	t
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	eab31880-af7f-4af2-83d8-b69977819fad	t
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e3f1ad84-d45f-4ef0-b18f-767339bf436e	t
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	982f6961-08bd-4741-acaa-d0444f1d1f90	f
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e0f3bf3c-84b1-4c54-972c-a1968fffe728	f
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	4e78c483-16fc-4c51-a8f7-1c906bd42e91	t
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	6f111df2-7083-4774-a033-bd644b61b48e	t
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	bbb3bc76-0f3f-4988-9df6-67713326a19f	f
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	955521bd-156f-4ade-a60a-036f859c9600	t
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	a38bb110-7d1c-433e-a5b9-04197257357c	t
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	3f969fa3-d862-4656-835e-07ea2f6f2c5e	f
fa932e74-3d72-4028-b476-3620d13514ce	6a4f95f0-80dc-4ca3-92e2-bd44b229837b	t
fa932e74-3d72-4028-b476-3620d13514ce	42a8e654-6d1e-48e7-806d-2c72dc42c30d	t
fa932e74-3d72-4028-b476-3620d13514ce	d729010f-7c64-4a75-9eae-71f211ae4de2	t
fa932e74-3d72-4028-b476-3620d13514ce	1538aa9f-9009-4e70-b7fc-626af0cebfb2	t
fa932e74-3d72-4028-b476-3620d13514ce	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36	t
fa932e74-3d72-4028-b476-3620d13514ce	72a2873f-bbb0-4ede-92d4-a6a541ee07e8	t
fa932e74-3d72-4028-b476-3620d13514ce	59b64ca7-8476-4387-a6d1-946cb16bc586	t
fa932e74-3d72-4028-b476-3620d13514ce	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af	t
fa932e74-3d72-4028-b476-3620d13514ce	4d0a91b8-6958-4930-997c-83bf8b67bc34	f
fa932e74-3d72-4028-b476-3620d13514ce	82460a4f-02d3-4320-b9df-2d124ab1a3ff	f
fa932e74-3d72-4028-b476-3620d13514ce	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b	f
fa932e74-3d72-4028-b476-3620d13514ce	943f5b4d-0bb5-4864-bace-22399ada546b	f
fa932e74-3d72-4028-b476-3620d13514ce	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66	f
fa932e74-3d72-4028-b476-3620d13514ce	9e9fc66a-2d58-4305-b20f-35a78aba8e23	t
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id, details_json_long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only, organization_id, hide_on_login) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: jgroups_ping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.jgroups_ping (address, name, cluster_name, ip, coord) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_group (id, name, parent_group, realm_id, type, description) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
1b500e6d-2a2e-4210-b0b9-4abd2cad2a1d	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	f	${role_default-roles}	default-roles-master	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N	\N
8017d7aa-a428-4d16-bc2d-dd5dfc217ac3	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	f	${role_create-realm}	create-realm	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N	\N
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	f	${role_admin}	admin	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N	\N
100a12fa-3668-44db-8ee0-38f5ef711ee7	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_create-client}	create-client	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
ad7a0692-e5bf-476e-b6f9-882f88a67a07	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_view-realm}	view-realm	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
d4d9992e-5171-411f-b0c8-b84e670c2129	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_view-users}	view-users	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
f2ff7d0e-bafb-4d8b-872c-31245765864d	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_view-clients}	view-clients	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
bc0ad0a3-fcc9-4bbb-94f4-d923e9ce5942	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_view-events}	view-events	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
11437b36-4950-4456-8702-9706d1c7bd8c	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_view-identity-providers}	view-identity-providers	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
2bf4e056-0e22-4a99-98bf-2b3491f2a766	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_view-authorization}	view-authorization	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
453503b1-2b35-4382-83d8-ade9d9ecd72f	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_manage-realm}	manage-realm	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
ee3b751e-18f4-4b7f-b9f1-8e536b217590	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_manage-users}	manage-users	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
a0838c35-3f89-4772-b1ae-c53f0a419776	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_manage-clients}	manage-clients	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
736a1881-50a0-4f27-96f4-c85f39ef372e	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_manage-events}	manage-events	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
116bcb74-6aa1-40c8-9e68-a57ad284829f	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_manage-identity-providers}	manage-identity-providers	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
8dbb9bdb-376b-4dd1-8ec5-209aaac29dfe	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_manage-authorization}	manage-authorization	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
a33ad304-b52a-4a94-9fcc-30dc4af7e0e0	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_query-users}	query-users	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
c41995fa-cdd5-49db-93f2-c410ee5f9c5b	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_query-clients}	query-clients	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
225d6cb4-92ad-4a86-9af2-b47bc4e788d0	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_query-realms}	query-realms	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
572efbe2-dbe8-41ad-acba-4c0bd3a21d83	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_query-groups}	query-groups	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
5edb528e-7120-4238-97ff-7148f397a336	e685bf33-6dc9-45b6-b45e-0613070a3f57	t	${role_view-profile}	view-profile	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e685bf33-6dc9-45b6-b45e-0613070a3f57	\N
9d14fd06-b39e-4f9a-8fa5-e010efd2f9a6	e685bf33-6dc9-45b6-b45e-0613070a3f57	t	${role_manage-account}	manage-account	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e685bf33-6dc9-45b6-b45e-0613070a3f57	\N
7f33fc43-2229-44fb-a8a6-b8e23716acfa	e685bf33-6dc9-45b6-b45e-0613070a3f57	t	${role_manage-account-links}	manage-account-links	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e685bf33-6dc9-45b6-b45e-0613070a3f57	\N
2745831b-1908-4dd2-a190-4bce958c44e4	e685bf33-6dc9-45b6-b45e-0613070a3f57	t	${role_view-applications}	view-applications	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e685bf33-6dc9-45b6-b45e-0613070a3f57	\N
c46cd14e-b235-4094-ae05-88f09cc51e1e	e685bf33-6dc9-45b6-b45e-0613070a3f57	t	${role_view-consent}	view-consent	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e685bf33-6dc9-45b6-b45e-0613070a3f57	\N
d182172d-1128-4742-9723-60520429b75f	e685bf33-6dc9-45b6-b45e-0613070a3f57	t	${role_manage-consent}	manage-consent	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e685bf33-6dc9-45b6-b45e-0613070a3f57	\N
7dd2f528-14d0-4254-8df6-e0a8ae7f2722	e685bf33-6dc9-45b6-b45e-0613070a3f57	t	${role_view-groups}	view-groups	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e685bf33-6dc9-45b6-b45e-0613070a3f57	\N
e7ef9f47-0370-43fb-ae4c-598d1adde4b8	e685bf33-6dc9-45b6-b45e-0613070a3f57	t	${role_delete-account}	delete-account	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	e685bf33-6dc9-45b6-b45e-0613070a3f57	\N
2afa4155-0d6b-4d37-8a60-bc03f565e03f	06330188-1212-410f-8c88-9995499f332e	t	${role_read-token}	read-token	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	06330188-1212-410f-8c88-9995499f332e	\N
7c567c96-f8c4-4e5b-abb4-b9933752ec96	14d66edd-004a-4fd0-af78-44f38b17dd06	t	${role_impersonation}	impersonation	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	14d66edd-004a-4fd0-af78-44f38b17dd06	\N
49327fa4-6460-4648-b0de-bad086225537	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	f	${role_offline-access}	offline_access	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N	\N
c573f251-6ba8-414e-b351-ffb48a3f6ae7	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	f	${role_uma_authorization}	uma_authorization	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	\N	\N
680023c2-1a2a-460a-a330-5ac153b9c19c	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_create-client}	create-client	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
ce3f1433-028d-4be5-88ec-753aa795b915	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_view-realm}	view-realm	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
45609a37-719b-40d8-bcc8-e4e9cc614416	fa932e74-3d72-4028-b476-3620d13514ce	f	${role_default-roles}	default-roles-linqra	fa932e74-3d72-4028-b476-3620d13514ce	\N	\N
68b451e2-2fa3-4d39-8559-6df698e041f6	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_view-users}	view-users	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
edfe465f-eeed-4c6d-a3b1-f0fc259c292c	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_view-clients}	view-clients	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
6080dda4-68c4-4e11-9574-379e4e626b85	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_view-events}	view-events	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
aba6e9b2-d130-4fc0-b06e-3e1c93118bd7	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_view-identity-providers}	view-identity-providers	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
770e2ccb-f480-4d9b-8587-63dc5ef1519a	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_view-authorization}	view-authorization	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
7d98bd5d-e4d2-4744-9ff1-4eeb9aeec487	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_manage-realm}	manage-realm	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
c491c41d-7071-4e59-b819-d98f9c372964	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_manage-users}	manage-users	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
29980031-1c3e-4809-8c1f-6ec7c0f27000	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_manage-clients}	manage-clients	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
5f57c72b-a797-4545-86e2-bb5b198eb998	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_manage-events}	manage-events	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
45df6300-7208-4245-a47f-38ed021d6de2	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_manage-identity-providers}	manage-identity-providers	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
103c4cda-d3ba-49b8-921f-a3f0ef5d2a7f	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_manage-authorization}	manage-authorization	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
cafbfc65-2e52-42e5-ba70-2485039d4daf	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_query-users}	query-users	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
1e8ff368-dbd5-4591-b2ea-4916771cbf4a	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_query-clients}	query-clients	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
70735a16-4e3b-444f-8cc8-423ea5014382	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_query-realms}	query-realms	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
7c07f825-9cba-4b66-aa6f-e50e8ef3521f	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_query-groups}	query-groups	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
50956bc7-d0ee-4039-a9c9-c26c97099337	fa932e74-3d72-4028-b476-3620d13514ce	f	${role_uma_authorization}	uma_authorization	fa932e74-3d72-4028-b476-3620d13514ce	\N	\N
8df9234a-22b6-496e-817f-f02ffcf641ca	fa932e74-3d72-4028-b476-3620d13514ce	f	Role to identify the belongings of the Linqra realm	gateway_admin_realm	fa932e74-3d72-4028-b476-3620d13514ce	\N	\N
51cb8d42-5a64-480b-b631-8e4c81dc90b2	fa932e74-3d72-4028-b476-3620d13514ce	f	${role_offline-access}	offline_access	fa932e74-3d72-4028-b476-3620d13514ce	\N	\N
68c9e30d-77e9-4b6d-93d4-7405083e25ca	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_impersonation}	impersonation	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
834407e8-51cc-4949-be0b-6869b18295b6	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_create-client}	create-client	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
be737ea0-aaf8-4d70-84c1-76e16323d06f	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_manage-clients}	manage-clients	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
71c1cf12-4aca-4fb1-927a-8254f24fbb1e	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_manage-events}	manage-events	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
6eeae823-2513-422e-9fb6-0ddef3bbedec	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_manage-identity-providers}	manage-identity-providers	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
f1da62f3-04d5-45b8-955b-02ed23f070ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_manage-users}	manage-users	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
ce23597f-6f5c-4e23-8c7c-fdb9fcf749e5	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_query-realms}	query-realms	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
96f3eee2-e472-4eef-9506-25e22bf9bed6	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_view-authorization}	view-authorization	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
328102d3-b939-4b9e-ab11-d8fa76c59484	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_realm-admin}	realm-admin	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
b4d16d50-0a15-4a69-b5bc-875298832827	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_view-clients}	view-clients	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
ea4a2945-780c-42a8-b82b-99725f6ff7a3	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_manage-realm}	manage-realm	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
ee613a7e-ff96-4bee-84d6-930f8582529b	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_manage-authorization}	manage-authorization	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
d2f429e8-a9d0-4e5f-bcd9-084129eaffab	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_view-identity-providers}	view-identity-providers	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
e1a77158-c744-4d96-9fc0-7da6e4c8de2d	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_view-users}	view-users	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
8c57d95d-6c99-4423-95ab-fe4e53cb9b83	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_view-realm}	view-realm	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
70d56dfb-07fd-4239-a00a-046fe35a92bb	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_query-clients}	query-clients	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
9ceea42c-cf36-4800-9ce1-6b9fdaef9aa9	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_view-events}	view-events	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
571552b5-a472-4959-a080-3d174bccfb00	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_query-groups}	query-groups	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
55c0bd79-2b6f-49b7-82bb-e9f64ac357ca	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	t	${role_query-users}	query-users	fa932e74-3d72-4028-b476-3620d13514ce	c52c3529-f2d0-4da6-9dd1-7c30ba98ba6e	\N
fa8d2230-c1a1-4b74-ab06-054303837057	c6f5ede9-6791-43d3-8430-f485361bf7d5	t	Gateway admin role for the client id: linqra-gateway-client	gateway_admin	fa932e74-3d72-4028-b476-3620d13514ce	c6f5ede9-6791-43d3-8430-f485361bf7d5	\N
351522f9-2060-4bb5-8994-e5e973db1b76	be4928ae-99f3-4bd5-81a4-9fecedc0340c	t	${role_read-token}	read-token	fa932e74-3d72-4028-b476-3620d13514ce	be4928ae-99f3-4bd5-81a4-9fecedc0340c	\N
2f16d410-87ff-4121-b1a1-fb900a722fea	a64e78ff-429f-461c-85ca-11095df7667f	t	${role_view-applications}	view-applications	fa932e74-3d72-4028-b476-3620d13514ce	a64e78ff-429f-461c-85ca-11095df7667f	\N
5833d875-ca90-49a4-9701-9bc1c761dc00	a64e78ff-429f-461c-85ca-11095df7667f	t	${role_view-consent}	view-consent	fa932e74-3d72-4028-b476-3620d13514ce	a64e78ff-429f-461c-85ca-11095df7667f	\N
43fc98b5-72ce-4e2e-872e-d4e3d4043833	a64e78ff-429f-461c-85ca-11095df7667f	t	${role_view-groups}	view-groups	fa932e74-3d72-4028-b476-3620d13514ce	a64e78ff-429f-461c-85ca-11095df7667f	\N
a770d584-34e2-4421-b1f6-67b224890e83	a64e78ff-429f-461c-85ca-11095df7667f	t	${role_manage-account-links}	manage-account-links	fa932e74-3d72-4028-b476-3620d13514ce	a64e78ff-429f-461c-85ca-11095df7667f	\N
fedbc438-7b78-4c5f-8f91-61461aa58331	a64e78ff-429f-461c-85ca-11095df7667f	t	${role_manage-consent}	manage-consent	fa932e74-3d72-4028-b476-3620d13514ce	a64e78ff-429f-461c-85ca-11095df7667f	\N
07dba17e-75f4-465c-ba8f-d93fd9168469	a64e78ff-429f-461c-85ca-11095df7667f	t	${role_delete-account}	delete-account	fa932e74-3d72-4028-b476-3620d13514ce	a64e78ff-429f-461c-85ca-11095df7667f	\N
31394836-54ec-4ed7-b108-bdef64964f48	a64e78ff-429f-461c-85ca-11095df7667f	t	${role_manage-account}	manage-account	fa932e74-3d72-4028-b476-3620d13514ce	a64e78ff-429f-461c-85ca-11095df7667f	\N
c7bdb876-a200-472c-a003-3a5fd1520190	a64e78ff-429f-461c-85ca-11095df7667f	t	${role_view-profile}	view-profile	fa932e74-3d72-4028-b476-3620d13514ce	a64e78ff-429f-461c-85ca-11095df7667f	\N
256689bf-3110-4e6a-9eac-3392f765e4dc	7b932313-b8f6-4d43-a1c1-ed146786e0c0	t	${role_impersonation}	impersonation	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	7b932313-b8f6-4d43-a1c1-ed146786e0c0	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.migration_model (id, version, update_time) FROM stdin;
f7brh	26.4.0	1759688368
drh1k	26.4.2	1762123731
cn36r	26.4.5	1763943495
gxy00	26.4.6	1764121429
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id, version) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh, broker_session_id, version) FROM stdin;
\.


--
-- Data for Name: org; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.org (id, enabled, realm_id, group_id, name, description, alias, redirect_url) FROM stdin;
\.


--
-- Data for Name: org_domain; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.org_domain (id, name, verified, org_id) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
98162f2c-4ca5-48d1-ba29-7fd35d2a01dd	audience resolve	openid-connect	oidc-audience-resolve-mapper	43b0209c-b0f6-48fd-b331-172944afaab9	\N
cfb40192-c666-4e42-811b-326380aa483c	locale	openid-connect	oidc-usermodel-attribute-mapper	8395b40e-acfd-4834-b2bd-605b68e96a3c	\N
95c35fee-10b7-44be-b242-104ab24e5b31	role list	saml	saml-role-list-mapper	\N	b53929e1-a35f-4ce5-9657-da1a05edd3e5
1774d1fd-d53f-45af-aedc-1c81aa075748	organization	saml	saml-organization-membership-mapper	\N	5499f689-3ad8-47f1-8442-0fde64fdc8ac
90411d1a-68c1-49e3-9bfb-b44ad40bc7c7	full name	openid-connect	oidc-full-name-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
5ba64cec-826e-45d4-a4d0-201a9c287f41	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
7e3a9cba-298b-4605-b907-5642cb3819e8	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
d80ab5bd-7412-45b7-a08a-adaf29939a81	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
2564dd2d-06b4-48d6-a561-e988a491984c	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
f5bd048e-d59e-44b5-97e1-578cae24125b	username	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
bd609757-2ad5-413f-9fdf-0266e58b435c	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
b36cfe17-fde1-4934-af6b-2de7b3bedb06	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
45385339-b446-4565-8a56-44b8fc65df32	website	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
88449648-4220-4272-a7aa-24300ac4aa8b	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
91a8ac9a-a8cf-46ad-bd2d-18f305c95c01	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
654a6315-4225-484c-b1ad-0d5e201670ad	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
7e15a3ab-1e1a-488c-97d6-de6c31ed85f0	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
9c0def1a-35fd-4e05-8ac9-7d4c17bbaef2	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	eab31880-af7f-4af2-83d8-b69977819fad
dbb24bef-e160-4cce-9c9e-0cae66d1659f	email	openid-connect	oidc-usermodel-attribute-mapper	\N	e3f1ad84-d45f-4ef0-b18f-767339bf436e
804549e4-25c1-435f-9581-8c52e604dbe8	email verified	openid-connect	oidc-usermodel-property-mapper	\N	e3f1ad84-d45f-4ef0-b18f-767339bf436e
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	address	openid-connect	oidc-address-mapper	\N	982f6961-08bd-4741-acaa-d0444f1d1f90
7cc02f0f-9ffe-45b2-964d-914af1db4537	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	e0f3bf3c-84b1-4c54-972c-a1968fffe728
ac9e1b85-4fe9-4ccc-ad25-fc76807bf7db	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	e0f3bf3c-84b1-4c54-972c-a1968fffe728
11496a1f-2a28-4f70-b771-e25397930653	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	4e78c483-16fc-4c51-a8f7-1c906bd42e91
aad8526e-9f3e-4730-99ad-e63cfb325224	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	4e78c483-16fc-4c51-a8f7-1c906bd42e91
41d29636-bc39-442c-b54c-bbfd0bc8be77	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	4e78c483-16fc-4c51-a8f7-1c906bd42e91
02b81481-f22b-4f10-a761-4afdb29efafa	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	6f111df2-7083-4774-a033-bd644b61b48e
800b578a-8db3-401c-876a-7d576ad487e7	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	bbb3bc76-0f3f-4988-9df6-67713326a19f
9a0b55d4-8000-49ef-9efc-d4e00a765da6	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	bbb3bc76-0f3f-4988-9df6-67713326a19f
ea7e3cb2-a436-4225-9d0f-b16577444cff	acr loa level	openid-connect	oidc-acr-mapper	\N	955521bd-156f-4ade-a60a-036f859c9600
7ca2206b-f49c-4dd4-8a01-2c3fe677aa48	auth_time	openid-connect	oidc-usersessionmodel-note-mapper	\N	a38bb110-7d1c-433e-a5b9-04197257357c
84ce1341-9e4f-41ed-9daf-ad1cc75b96e1	sub	openid-connect	oidc-sub-mapper	\N	a38bb110-7d1c-433e-a5b9-04197257357c
f8b1e57e-b507-4bc0-a75b-e2865e497bc3	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	\N	d59eaa29-cc6d-458b-929f-7a298bf3960d
6fb655e7-0983-438c-8d38-64aa2cb67b59	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	\N	d59eaa29-cc6d-458b-929f-7a298bf3960d
5d6e7f82-8ef5-4e4c-9605-d8078e9554c8	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	\N	d59eaa29-cc6d-458b-929f-7a298bf3960d
c7ab2a8c-61ce-4054-9752-0548bc27344a	organization	openid-connect	oidc-organization-membership-mapper	\N	3f969fa3-d862-4656-835e-07ea2f6f2c5e
0e655fd9-b01e-4225-bdca-7b3246f3f7fa	sub	openid-connect	oidc-sub-mapper	\N	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af
184edeec-d095-49f6-a5b6-175f4dcd23a9	auth_time	openid-connect	oidc-usersessionmodel-note-mapper	\N	0dd9be49-c4bf-4de3-9b6a-b009ef75a9af
8bb87ad3-3332-4b17-8388-cc0351be655d	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	\N	1267b092-d449-4b01-8bcc-dfcbd2763276
9f0e8ef1-d144-4fbd-a50a-e88f3db25c02	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	\N	1267b092-d449-4b01-8bcc-dfcbd2763276
66439e67-3d6c-43e9-9e4c-7d46eb054e1e	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	\N	1267b092-d449-4b01-8bcc-dfcbd2763276
9153fe25-ced8-46f2-9acd-477396ff2162	full name	openid-connect	oidc-full-name-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
97817f4d-1c9c-4cb7-b609-10e38f60ecff	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
f07a7bd9-14ab-4296-a8a0-22e959d378d1	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
ef62f03c-1003-4fc6-a095-66dfafe451a3	website	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
e8e343b8-17dd-43ca-88d9-caaa41d75f37	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
782d040e-afa3-4e2a-8bf2-8d5c235f21ac	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
4714622c-fd95-4af7-b5a5-32481f799fdc	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
ef81e483-ced8-44f9-a185-a396428af215	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
a38f1089-d204-438f-b346-bfe502664cad	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
3a81fd75-a487-4db4-99be-dad1c4fd917f	username	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
53e64154-b936-4780-a8c1-66a014d7aed9	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
d2b0ab87-a576-4079-a977-c3ba67bbbdb2	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
f00a884a-da36-424f-b9f6-96bbf983d843	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
97b69ea9-c729-4361-92f7-0ee16b4333a8	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	d729010f-7c64-4a75-9eae-71f211ae4de2
620315d1-944d-4c36-b811-350dff90d902	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	943f5b4d-0bb5-4864-bace-22399ada546b
f973353b-059b-48c3-ac01-5c3f7acd2231	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	943f5b4d-0bb5-4864-bace-22399ada546b
dc2b2bf6-7494-4d01-bcb8-abeae7f7929d	organization	openid-connect	oidc-organization-membership-mapper	\N	79d8d9a4-6ac2-4e62-8bc2-e49442beaf66
4bee2fe5-cd5a-4743-9440-c23f355fcc07	role list	saml	saml-role-list-mapper	\N	6a4f95f0-80dc-4ca3-92e2-bd44b229837b
958be64d-341c-400d-9e5c-89be252156bd	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b
d63288e6-4430-401b-94e7-810315c4dfd1	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	9d0fdde3-fc6d-47a3-98c6-59ac6586ea3b
c2ea6294-2017-4ab7-b5fb-46fcdefff8b2	organization	saml	saml-organization-membership-mapper	\N	42a8e654-6d1e-48e7-806d-2c72dc42c30d
4466894c-6c5e-4198-9384-a1037fd15e82	email verified	openid-connect	oidc-usermodel-property-mapper	\N	1538aa9f-9009-4e70-b7fc-626af0cebfb2
f6fb8d6b-0333-42c8-b2e1-1e8cb1e5fe40	email	openid-connect	oidc-usermodel-attribute-mapper	\N	1538aa9f-9009-4e70-b7fc-626af0cebfb2
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	address	openid-connect	oidc-address-mapper	\N	82460a4f-02d3-4320-b9df-2d124ab1a3ff
d8f9c70d-d33d-4d01-8bb1-76c4e59cfcf4	acr loa level	openid-connect	oidc-acr-mapper	\N	59b64ca7-8476-4387-a6d1-946cb16bc586
0334ac7c-25ed-451a-b5e2-9c705b241286	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36
a7dd6972-ccaf-42a1-a5b2-e170e1124ed3	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36
4d9b65ab-4f30-4c31-bf63-4d3a74820b5e	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	b16c6a6c-6a24-4ef5-9b65-34bfde4bfc36
3a8a61c9-c442-4567-95f0-7938b4252913	teams	openid-connect	oidc-hardcoded-claim-mapper	\N	6fe2d901-9820-4971-a3a9-7990f11d8523
94e16377-3c5f-468d-9718-e3ceb35d804d	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	72a2873f-bbb0-4ede-92d4-a6a541ee07e8
5898ccd4-ef2e-4b96-98e5-8f5583407890	audience resolve	openid-connect	oidc-audience-resolve-mapper	ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	\N
d456da75-34e6-4a0e-bcd3-217c89c18918	locale	openid-connect	oidc-usermodel-attribute-mapper	b7e45a00-20df-4e74-b038-b5dbc6e46e8a	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
cfb40192-c666-4e42-811b-326380aa483c	true	introspection.token.claim
cfb40192-c666-4e42-811b-326380aa483c	true	userinfo.token.claim
cfb40192-c666-4e42-811b-326380aa483c	locale	user.attribute
cfb40192-c666-4e42-811b-326380aa483c	true	id.token.claim
cfb40192-c666-4e42-811b-326380aa483c	true	access.token.claim
cfb40192-c666-4e42-811b-326380aa483c	locale	claim.name
cfb40192-c666-4e42-811b-326380aa483c	String	jsonType.label
95c35fee-10b7-44be-b242-104ab24e5b31	false	single
95c35fee-10b7-44be-b242-104ab24e5b31	Basic	attribute.nameformat
95c35fee-10b7-44be-b242-104ab24e5b31	Role	attribute.name
2564dd2d-06b4-48d6-a561-e988a491984c	true	introspection.token.claim
2564dd2d-06b4-48d6-a561-e988a491984c	true	userinfo.token.claim
2564dd2d-06b4-48d6-a561-e988a491984c	nickname	user.attribute
2564dd2d-06b4-48d6-a561-e988a491984c	true	id.token.claim
2564dd2d-06b4-48d6-a561-e988a491984c	true	access.token.claim
2564dd2d-06b4-48d6-a561-e988a491984c	nickname	claim.name
2564dd2d-06b4-48d6-a561-e988a491984c	String	jsonType.label
45385339-b446-4565-8a56-44b8fc65df32	true	introspection.token.claim
45385339-b446-4565-8a56-44b8fc65df32	true	userinfo.token.claim
45385339-b446-4565-8a56-44b8fc65df32	website	user.attribute
45385339-b446-4565-8a56-44b8fc65df32	true	id.token.claim
45385339-b446-4565-8a56-44b8fc65df32	true	access.token.claim
45385339-b446-4565-8a56-44b8fc65df32	website	claim.name
45385339-b446-4565-8a56-44b8fc65df32	String	jsonType.label
5ba64cec-826e-45d4-a4d0-201a9c287f41	true	introspection.token.claim
5ba64cec-826e-45d4-a4d0-201a9c287f41	true	userinfo.token.claim
5ba64cec-826e-45d4-a4d0-201a9c287f41	lastName	user.attribute
5ba64cec-826e-45d4-a4d0-201a9c287f41	true	id.token.claim
5ba64cec-826e-45d4-a4d0-201a9c287f41	true	access.token.claim
5ba64cec-826e-45d4-a4d0-201a9c287f41	family_name	claim.name
5ba64cec-826e-45d4-a4d0-201a9c287f41	String	jsonType.label
654a6315-4225-484c-b1ad-0d5e201670ad	true	introspection.token.claim
654a6315-4225-484c-b1ad-0d5e201670ad	true	userinfo.token.claim
654a6315-4225-484c-b1ad-0d5e201670ad	zoneinfo	user.attribute
654a6315-4225-484c-b1ad-0d5e201670ad	true	id.token.claim
654a6315-4225-484c-b1ad-0d5e201670ad	true	access.token.claim
654a6315-4225-484c-b1ad-0d5e201670ad	zoneinfo	claim.name
654a6315-4225-484c-b1ad-0d5e201670ad	String	jsonType.label
7e15a3ab-1e1a-488c-97d6-de6c31ed85f0	true	introspection.token.claim
7e15a3ab-1e1a-488c-97d6-de6c31ed85f0	true	userinfo.token.claim
7e15a3ab-1e1a-488c-97d6-de6c31ed85f0	locale	user.attribute
7e15a3ab-1e1a-488c-97d6-de6c31ed85f0	true	id.token.claim
7e15a3ab-1e1a-488c-97d6-de6c31ed85f0	true	access.token.claim
7e15a3ab-1e1a-488c-97d6-de6c31ed85f0	locale	claim.name
7e15a3ab-1e1a-488c-97d6-de6c31ed85f0	String	jsonType.label
7e3a9cba-298b-4605-b907-5642cb3819e8	true	introspection.token.claim
7e3a9cba-298b-4605-b907-5642cb3819e8	true	userinfo.token.claim
7e3a9cba-298b-4605-b907-5642cb3819e8	firstName	user.attribute
7e3a9cba-298b-4605-b907-5642cb3819e8	true	id.token.claim
7e3a9cba-298b-4605-b907-5642cb3819e8	true	access.token.claim
7e3a9cba-298b-4605-b907-5642cb3819e8	given_name	claim.name
7e3a9cba-298b-4605-b907-5642cb3819e8	String	jsonType.label
88449648-4220-4272-a7aa-24300ac4aa8b	true	introspection.token.claim
88449648-4220-4272-a7aa-24300ac4aa8b	true	userinfo.token.claim
88449648-4220-4272-a7aa-24300ac4aa8b	gender	user.attribute
88449648-4220-4272-a7aa-24300ac4aa8b	true	id.token.claim
88449648-4220-4272-a7aa-24300ac4aa8b	true	access.token.claim
88449648-4220-4272-a7aa-24300ac4aa8b	gender	claim.name
88449648-4220-4272-a7aa-24300ac4aa8b	String	jsonType.label
90411d1a-68c1-49e3-9bfb-b44ad40bc7c7	true	introspection.token.claim
90411d1a-68c1-49e3-9bfb-b44ad40bc7c7	true	userinfo.token.claim
90411d1a-68c1-49e3-9bfb-b44ad40bc7c7	true	id.token.claim
90411d1a-68c1-49e3-9bfb-b44ad40bc7c7	true	access.token.claim
91a8ac9a-a8cf-46ad-bd2d-18f305c95c01	true	introspection.token.claim
91a8ac9a-a8cf-46ad-bd2d-18f305c95c01	true	userinfo.token.claim
91a8ac9a-a8cf-46ad-bd2d-18f305c95c01	birthdate	user.attribute
91a8ac9a-a8cf-46ad-bd2d-18f305c95c01	true	id.token.claim
91a8ac9a-a8cf-46ad-bd2d-18f305c95c01	true	access.token.claim
91a8ac9a-a8cf-46ad-bd2d-18f305c95c01	birthdate	claim.name
91a8ac9a-a8cf-46ad-bd2d-18f305c95c01	String	jsonType.label
9c0def1a-35fd-4e05-8ac9-7d4c17bbaef2	true	introspection.token.claim
9c0def1a-35fd-4e05-8ac9-7d4c17bbaef2	true	userinfo.token.claim
9c0def1a-35fd-4e05-8ac9-7d4c17bbaef2	updatedAt	user.attribute
9c0def1a-35fd-4e05-8ac9-7d4c17bbaef2	true	id.token.claim
9c0def1a-35fd-4e05-8ac9-7d4c17bbaef2	true	access.token.claim
9c0def1a-35fd-4e05-8ac9-7d4c17bbaef2	updated_at	claim.name
9c0def1a-35fd-4e05-8ac9-7d4c17bbaef2	long	jsonType.label
b36cfe17-fde1-4934-af6b-2de7b3bedb06	true	introspection.token.claim
b36cfe17-fde1-4934-af6b-2de7b3bedb06	true	userinfo.token.claim
b36cfe17-fde1-4934-af6b-2de7b3bedb06	picture	user.attribute
b36cfe17-fde1-4934-af6b-2de7b3bedb06	true	id.token.claim
b36cfe17-fde1-4934-af6b-2de7b3bedb06	true	access.token.claim
b36cfe17-fde1-4934-af6b-2de7b3bedb06	picture	claim.name
b36cfe17-fde1-4934-af6b-2de7b3bedb06	String	jsonType.label
bd609757-2ad5-413f-9fdf-0266e58b435c	true	introspection.token.claim
bd609757-2ad5-413f-9fdf-0266e58b435c	true	userinfo.token.claim
bd609757-2ad5-413f-9fdf-0266e58b435c	profile	user.attribute
bd609757-2ad5-413f-9fdf-0266e58b435c	true	id.token.claim
bd609757-2ad5-413f-9fdf-0266e58b435c	true	access.token.claim
bd609757-2ad5-413f-9fdf-0266e58b435c	profile	claim.name
bd609757-2ad5-413f-9fdf-0266e58b435c	String	jsonType.label
d80ab5bd-7412-45b7-a08a-adaf29939a81	true	introspection.token.claim
d80ab5bd-7412-45b7-a08a-adaf29939a81	true	userinfo.token.claim
d80ab5bd-7412-45b7-a08a-adaf29939a81	middleName	user.attribute
d80ab5bd-7412-45b7-a08a-adaf29939a81	true	id.token.claim
d80ab5bd-7412-45b7-a08a-adaf29939a81	true	access.token.claim
d80ab5bd-7412-45b7-a08a-adaf29939a81	middle_name	claim.name
d80ab5bd-7412-45b7-a08a-adaf29939a81	String	jsonType.label
f5bd048e-d59e-44b5-97e1-578cae24125b	true	introspection.token.claim
f5bd048e-d59e-44b5-97e1-578cae24125b	true	userinfo.token.claim
f5bd048e-d59e-44b5-97e1-578cae24125b	username	user.attribute
f5bd048e-d59e-44b5-97e1-578cae24125b	true	id.token.claim
f5bd048e-d59e-44b5-97e1-578cae24125b	true	access.token.claim
f5bd048e-d59e-44b5-97e1-578cae24125b	preferred_username	claim.name
f5bd048e-d59e-44b5-97e1-578cae24125b	String	jsonType.label
804549e4-25c1-435f-9581-8c52e604dbe8	true	introspection.token.claim
804549e4-25c1-435f-9581-8c52e604dbe8	true	userinfo.token.claim
804549e4-25c1-435f-9581-8c52e604dbe8	emailVerified	user.attribute
804549e4-25c1-435f-9581-8c52e604dbe8	true	id.token.claim
804549e4-25c1-435f-9581-8c52e604dbe8	true	access.token.claim
804549e4-25c1-435f-9581-8c52e604dbe8	email_verified	claim.name
804549e4-25c1-435f-9581-8c52e604dbe8	boolean	jsonType.label
dbb24bef-e160-4cce-9c9e-0cae66d1659f	true	introspection.token.claim
dbb24bef-e160-4cce-9c9e-0cae66d1659f	true	userinfo.token.claim
dbb24bef-e160-4cce-9c9e-0cae66d1659f	email	user.attribute
dbb24bef-e160-4cce-9c9e-0cae66d1659f	true	id.token.claim
dbb24bef-e160-4cce-9c9e-0cae66d1659f	true	access.token.claim
dbb24bef-e160-4cce-9c9e-0cae66d1659f	email	claim.name
dbb24bef-e160-4cce-9c9e-0cae66d1659f	String	jsonType.label
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	formatted	user.attribute.formatted
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	country	user.attribute.country
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	true	introspection.token.claim
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	postal_code	user.attribute.postal_code
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	true	userinfo.token.claim
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	street	user.attribute.street
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	true	id.token.claim
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	region	user.attribute.region
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	true	access.token.claim
e2ce8ddd-8e75-492c-907b-e5bdb8ceda67	locality	user.attribute.locality
7cc02f0f-9ffe-45b2-964d-914af1db4537	true	introspection.token.claim
7cc02f0f-9ffe-45b2-964d-914af1db4537	true	userinfo.token.claim
7cc02f0f-9ffe-45b2-964d-914af1db4537	phoneNumber	user.attribute
7cc02f0f-9ffe-45b2-964d-914af1db4537	true	id.token.claim
7cc02f0f-9ffe-45b2-964d-914af1db4537	true	access.token.claim
7cc02f0f-9ffe-45b2-964d-914af1db4537	phone_number	claim.name
7cc02f0f-9ffe-45b2-964d-914af1db4537	String	jsonType.label
ac9e1b85-4fe9-4ccc-ad25-fc76807bf7db	true	introspection.token.claim
ac9e1b85-4fe9-4ccc-ad25-fc76807bf7db	true	userinfo.token.claim
ac9e1b85-4fe9-4ccc-ad25-fc76807bf7db	phoneNumberVerified	user.attribute
ac9e1b85-4fe9-4ccc-ad25-fc76807bf7db	true	id.token.claim
ac9e1b85-4fe9-4ccc-ad25-fc76807bf7db	true	access.token.claim
ac9e1b85-4fe9-4ccc-ad25-fc76807bf7db	phone_number_verified	claim.name
ac9e1b85-4fe9-4ccc-ad25-fc76807bf7db	boolean	jsonType.label
11496a1f-2a28-4f70-b771-e25397930653	true	introspection.token.claim
11496a1f-2a28-4f70-b771-e25397930653	true	multivalued
11496a1f-2a28-4f70-b771-e25397930653	foo	user.attribute
11496a1f-2a28-4f70-b771-e25397930653	true	access.token.claim
11496a1f-2a28-4f70-b771-e25397930653	realm_access.roles	claim.name
11496a1f-2a28-4f70-b771-e25397930653	String	jsonType.label
41d29636-bc39-442c-b54c-bbfd0bc8be77	true	introspection.token.claim
41d29636-bc39-442c-b54c-bbfd0bc8be77	true	access.token.claim
aad8526e-9f3e-4730-99ad-e63cfb325224	true	introspection.token.claim
aad8526e-9f3e-4730-99ad-e63cfb325224	true	multivalued
aad8526e-9f3e-4730-99ad-e63cfb325224	foo	user.attribute
aad8526e-9f3e-4730-99ad-e63cfb325224	true	access.token.claim
aad8526e-9f3e-4730-99ad-e63cfb325224	resource_access.${client_id}.roles	claim.name
aad8526e-9f3e-4730-99ad-e63cfb325224	String	jsonType.label
02b81481-f22b-4f10-a761-4afdb29efafa	true	introspection.token.claim
02b81481-f22b-4f10-a761-4afdb29efafa	true	access.token.claim
800b578a-8db3-401c-876a-7d576ad487e7	true	introspection.token.claim
800b578a-8db3-401c-876a-7d576ad487e7	true	userinfo.token.claim
800b578a-8db3-401c-876a-7d576ad487e7	username	user.attribute
800b578a-8db3-401c-876a-7d576ad487e7	true	id.token.claim
800b578a-8db3-401c-876a-7d576ad487e7	true	access.token.claim
800b578a-8db3-401c-876a-7d576ad487e7	upn	claim.name
800b578a-8db3-401c-876a-7d576ad487e7	String	jsonType.label
9a0b55d4-8000-49ef-9efc-d4e00a765da6	true	introspection.token.claim
9a0b55d4-8000-49ef-9efc-d4e00a765da6	true	multivalued
9a0b55d4-8000-49ef-9efc-d4e00a765da6	foo	user.attribute
9a0b55d4-8000-49ef-9efc-d4e00a765da6	true	id.token.claim
9a0b55d4-8000-49ef-9efc-d4e00a765da6	true	access.token.claim
9a0b55d4-8000-49ef-9efc-d4e00a765da6	groups	claim.name
9a0b55d4-8000-49ef-9efc-d4e00a765da6	String	jsonType.label
ea7e3cb2-a436-4225-9d0f-b16577444cff	true	introspection.token.claim
ea7e3cb2-a436-4225-9d0f-b16577444cff	true	id.token.claim
ea7e3cb2-a436-4225-9d0f-b16577444cff	true	access.token.claim
7ca2206b-f49c-4dd4-8a01-2c3fe677aa48	AUTH_TIME	user.session.note
7ca2206b-f49c-4dd4-8a01-2c3fe677aa48	true	introspection.token.claim
7ca2206b-f49c-4dd4-8a01-2c3fe677aa48	true	id.token.claim
7ca2206b-f49c-4dd4-8a01-2c3fe677aa48	true	access.token.claim
7ca2206b-f49c-4dd4-8a01-2c3fe677aa48	auth_time	claim.name
7ca2206b-f49c-4dd4-8a01-2c3fe677aa48	long	jsonType.label
84ce1341-9e4f-41ed-9daf-ad1cc75b96e1	true	introspection.token.claim
84ce1341-9e4f-41ed-9daf-ad1cc75b96e1	true	access.token.claim
5d6e7f82-8ef5-4e4c-9605-d8078e9554c8	clientAddress	user.session.note
5d6e7f82-8ef5-4e4c-9605-d8078e9554c8	true	introspection.token.claim
5d6e7f82-8ef5-4e4c-9605-d8078e9554c8	true	id.token.claim
5d6e7f82-8ef5-4e4c-9605-d8078e9554c8	true	access.token.claim
5d6e7f82-8ef5-4e4c-9605-d8078e9554c8	clientAddress	claim.name
5d6e7f82-8ef5-4e4c-9605-d8078e9554c8	String	jsonType.label
6fb655e7-0983-438c-8d38-64aa2cb67b59	clientHost	user.session.note
6fb655e7-0983-438c-8d38-64aa2cb67b59	true	introspection.token.claim
6fb655e7-0983-438c-8d38-64aa2cb67b59	true	id.token.claim
6fb655e7-0983-438c-8d38-64aa2cb67b59	true	access.token.claim
6fb655e7-0983-438c-8d38-64aa2cb67b59	clientHost	claim.name
6fb655e7-0983-438c-8d38-64aa2cb67b59	String	jsonType.label
f8b1e57e-b507-4bc0-a75b-e2865e497bc3	client_id	user.session.note
f8b1e57e-b507-4bc0-a75b-e2865e497bc3	true	introspection.token.claim
f8b1e57e-b507-4bc0-a75b-e2865e497bc3	true	id.token.claim
f8b1e57e-b507-4bc0-a75b-e2865e497bc3	true	access.token.claim
f8b1e57e-b507-4bc0-a75b-e2865e497bc3	client_id	claim.name
f8b1e57e-b507-4bc0-a75b-e2865e497bc3	String	jsonType.label
c7ab2a8c-61ce-4054-9752-0548bc27344a	true	introspection.token.claim
c7ab2a8c-61ce-4054-9752-0548bc27344a	true	multivalued
c7ab2a8c-61ce-4054-9752-0548bc27344a	true	id.token.claim
c7ab2a8c-61ce-4054-9752-0548bc27344a	true	access.token.claim
c7ab2a8c-61ce-4054-9752-0548bc27344a	organization	claim.name
c7ab2a8c-61ce-4054-9752-0548bc27344a	String	jsonType.label
0e655fd9-b01e-4225-bdca-7b3246f3f7fa	true	introspection.token.claim
0e655fd9-b01e-4225-bdca-7b3246f3f7fa	true	access.token.claim
184edeec-d095-49f6-a5b6-175f4dcd23a9	AUTH_TIME	user.session.note
184edeec-d095-49f6-a5b6-175f4dcd23a9	true	introspection.token.claim
184edeec-d095-49f6-a5b6-175f4dcd23a9	true	userinfo.token.claim
184edeec-d095-49f6-a5b6-175f4dcd23a9	true	id.token.claim
184edeec-d095-49f6-a5b6-175f4dcd23a9	true	access.token.claim
184edeec-d095-49f6-a5b6-175f4dcd23a9	auth_time	claim.name
184edeec-d095-49f6-a5b6-175f4dcd23a9	long	jsonType.label
66439e67-3d6c-43e9-9e4c-7d46eb054e1e	clientHost	user.session.note
66439e67-3d6c-43e9-9e4c-7d46eb054e1e	true	introspection.token.claim
66439e67-3d6c-43e9-9e4c-7d46eb054e1e	true	userinfo.token.claim
66439e67-3d6c-43e9-9e4c-7d46eb054e1e	true	id.token.claim
66439e67-3d6c-43e9-9e4c-7d46eb054e1e	true	access.token.claim
66439e67-3d6c-43e9-9e4c-7d46eb054e1e	clientHost	claim.name
66439e67-3d6c-43e9-9e4c-7d46eb054e1e	String	jsonType.label
8bb87ad3-3332-4b17-8388-cc0351be655d	client_id	user.session.note
8bb87ad3-3332-4b17-8388-cc0351be655d	true	introspection.token.claim
8bb87ad3-3332-4b17-8388-cc0351be655d	true	userinfo.token.claim
8bb87ad3-3332-4b17-8388-cc0351be655d	true	id.token.claim
8bb87ad3-3332-4b17-8388-cc0351be655d	true	access.token.claim
8bb87ad3-3332-4b17-8388-cc0351be655d	client_id	claim.name
8bb87ad3-3332-4b17-8388-cc0351be655d	String	jsonType.label
9f0e8ef1-d144-4fbd-a50a-e88f3db25c02	clientAddress	user.session.note
9f0e8ef1-d144-4fbd-a50a-e88f3db25c02	true	introspection.token.claim
9f0e8ef1-d144-4fbd-a50a-e88f3db25c02	true	userinfo.token.claim
9f0e8ef1-d144-4fbd-a50a-e88f3db25c02	true	id.token.claim
9f0e8ef1-d144-4fbd-a50a-e88f3db25c02	true	access.token.claim
9f0e8ef1-d144-4fbd-a50a-e88f3db25c02	clientAddress	claim.name
9f0e8ef1-d144-4fbd-a50a-e88f3db25c02	String	jsonType.label
3a81fd75-a487-4db4-99be-dad1c4fd917f	true	introspection.token.claim
3a81fd75-a487-4db4-99be-dad1c4fd917f	true	userinfo.token.claim
3a81fd75-a487-4db4-99be-dad1c4fd917f	username	user.attribute
3a81fd75-a487-4db4-99be-dad1c4fd917f	true	id.token.claim
3a81fd75-a487-4db4-99be-dad1c4fd917f	true	access.token.claim
3a81fd75-a487-4db4-99be-dad1c4fd917f	preferred_username	claim.name
3a81fd75-a487-4db4-99be-dad1c4fd917f	String	jsonType.label
4714622c-fd95-4af7-b5a5-32481f799fdc	true	introspection.token.claim
4714622c-fd95-4af7-b5a5-32481f799fdc	true	userinfo.token.claim
4714622c-fd95-4af7-b5a5-32481f799fdc	middleName	user.attribute
4714622c-fd95-4af7-b5a5-32481f799fdc	true	id.token.claim
4714622c-fd95-4af7-b5a5-32481f799fdc	true	access.token.claim
4714622c-fd95-4af7-b5a5-32481f799fdc	middle_name	claim.name
4714622c-fd95-4af7-b5a5-32481f799fdc	String	jsonType.label
53e64154-b936-4780-a8c1-66a014d7aed9	true	introspection.token.claim
53e64154-b936-4780-a8c1-66a014d7aed9	true	userinfo.token.claim
53e64154-b936-4780-a8c1-66a014d7aed9	gender	user.attribute
53e64154-b936-4780-a8c1-66a014d7aed9	true	id.token.claim
53e64154-b936-4780-a8c1-66a014d7aed9	true	access.token.claim
53e64154-b936-4780-a8c1-66a014d7aed9	gender	claim.name
53e64154-b936-4780-a8c1-66a014d7aed9	String	jsonType.label
782d040e-afa3-4e2a-8bf2-8d5c235f21ac	true	introspection.token.claim
782d040e-afa3-4e2a-8bf2-8d5c235f21ac	true	userinfo.token.claim
782d040e-afa3-4e2a-8bf2-8d5c235f21ac	birthdate	user.attribute
782d040e-afa3-4e2a-8bf2-8d5c235f21ac	true	id.token.claim
782d040e-afa3-4e2a-8bf2-8d5c235f21ac	true	access.token.claim
782d040e-afa3-4e2a-8bf2-8d5c235f21ac	birthdate	claim.name
782d040e-afa3-4e2a-8bf2-8d5c235f21ac	String	jsonType.label
9153fe25-ced8-46f2-9acd-477396ff2162	true	id.token.claim
9153fe25-ced8-46f2-9acd-477396ff2162	true	introspection.token.claim
9153fe25-ced8-46f2-9acd-477396ff2162	true	access.token.claim
9153fe25-ced8-46f2-9acd-477396ff2162	true	userinfo.token.claim
97817f4d-1c9c-4cb7-b609-10e38f60ecff	true	introspection.token.claim
97817f4d-1c9c-4cb7-b609-10e38f60ecff	true	userinfo.token.claim
97817f4d-1c9c-4cb7-b609-10e38f60ecff	picture	user.attribute
97817f4d-1c9c-4cb7-b609-10e38f60ecff	true	id.token.claim
97817f4d-1c9c-4cb7-b609-10e38f60ecff	true	access.token.claim
97817f4d-1c9c-4cb7-b609-10e38f60ecff	picture	claim.name
97817f4d-1c9c-4cb7-b609-10e38f60ecff	String	jsonType.label
97b69ea9-c729-4361-92f7-0ee16b4333a8	true	introspection.token.claim
97b69ea9-c729-4361-92f7-0ee16b4333a8	true	userinfo.token.claim
97b69ea9-c729-4361-92f7-0ee16b4333a8	firstName	user.attribute
97b69ea9-c729-4361-92f7-0ee16b4333a8	true	id.token.claim
97b69ea9-c729-4361-92f7-0ee16b4333a8	true	access.token.claim
97b69ea9-c729-4361-92f7-0ee16b4333a8	given_name	claim.name
97b69ea9-c729-4361-92f7-0ee16b4333a8	String	jsonType.label
a38f1089-d204-438f-b346-bfe502664cad	true	introspection.token.claim
a38f1089-d204-438f-b346-bfe502664cad	true	userinfo.token.claim
a38f1089-d204-438f-b346-bfe502664cad	profile	user.attribute
a38f1089-d204-438f-b346-bfe502664cad	true	id.token.claim
a38f1089-d204-438f-b346-bfe502664cad	true	access.token.claim
a38f1089-d204-438f-b346-bfe502664cad	profile	claim.name
a38f1089-d204-438f-b346-bfe502664cad	String	jsonType.label
d2b0ab87-a576-4079-a977-c3ba67bbbdb2	true	introspection.token.claim
d2b0ab87-a576-4079-a977-c3ba67bbbdb2	true	userinfo.token.claim
d2b0ab87-a576-4079-a977-c3ba67bbbdb2	nickname	user.attribute
d2b0ab87-a576-4079-a977-c3ba67bbbdb2	true	id.token.claim
d2b0ab87-a576-4079-a977-c3ba67bbbdb2	true	access.token.claim
d2b0ab87-a576-4079-a977-c3ba67bbbdb2	nickname	claim.name
d2b0ab87-a576-4079-a977-c3ba67bbbdb2	String	jsonType.label
e8e343b8-17dd-43ca-88d9-caaa41d75f37	true	introspection.token.claim
e8e343b8-17dd-43ca-88d9-caaa41d75f37	true	userinfo.token.claim
e8e343b8-17dd-43ca-88d9-caaa41d75f37	updatedAt	user.attribute
e8e343b8-17dd-43ca-88d9-caaa41d75f37	true	id.token.claim
e8e343b8-17dd-43ca-88d9-caaa41d75f37	true	access.token.claim
e8e343b8-17dd-43ca-88d9-caaa41d75f37	updated_at	claim.name
e8e343b8-17dd-43ca-88d9-caaa41d75f37	long	jsonType.label
ef62f03c-1003-4fc6-a095-66dfafe451a3	true	introspection.token.claim
ef62f03c-1003-4fc6-a095-66dfafe451a3	true	userinfo.token.claim
ef62f03c-1003-4fc6-a095-66dfafe451a3	website	user.attribute
ef62f03c-1003-4fc6-a095-66dfafe451a3	true	id.token.claim
ef62f03c-1003-4fc6-a095-66dfafe451a3	true	access.token.claim
ef62f03c-1003-4fc6-a095-66dfafe451a3	website	claim.name
ef62f03c-1003-4fc6-a095-66dfafe451a3	String	jsonType.label
ef81e483-ced8-44f9-a185-a396428af215	true	introspection.token.claim
ef81e483-ced8-44f9-a185-a396428af215	true	userinfo.token.claim
ef81e483-ced8-44f9-a185-a396428af215	lastName	user.attribute
ef81e483-ced8-44f9-a185-a396428af215	true	id.token.claim
ef81e483-ced8-44f9-a185-a396428af215	true	access.token.claim
ef81e483-ced8-44f9-a185-a396428af215	family_name	claim.name
ef81e483-ced8-44f9-a185-a396428af215	String	jsonType.label
f00a884a-da36-424f-b9f6-96bbf983d843	true	introspection.token.claim
f00a884a-da36-424f-b9f6-96bbf983d843	true	userinfo.token.claim
f00a884a-da36-424f-b9f6-96bbf983d843	zoneinfo	user.attribute
f00a884a-da36-424f-b9f6-96bbf983d843	true	id.token.claim
f00a884a-da36-424f-b9f6-96bbf983d843	true	access.token.claim
f00a884a-da36-424f-b9f6-96bbf983d843	zoneinfo	claim.name
f00a884a-da36-424f-b9f6-96bbf983d843	String	jsonType.label
f07a7bd9-14ab-4296-a8a0-22e959d378d1	true	introspection.token.claim
f07a7bd9-14ab-4296-a8a0-22e959d378d1	true	userinfo.token.claim
f07a7bd9-14ab-4296-a8a0-22e959d378d1	locale	user.attribute
f07a7bd9-14ab-4296-a8a0-22e959d378d1	true	id.token.claim
f07a7bd9-14ab-4296-a8a0-22e959d378d1	true	access.token.claim
f07a7bd9-14ab-4296-a8a0-22e959d378d1	locale	claim.name
f07a7bd9-14ab-4296-a8a0-22e959d378d1	String	jsonType.label
620315d1-944d-4c36-b811-350dff90d902	true	introspection.token.claim
620315d1-944d-4c36-b811-350dff90d902	true	userinfo.token.claim
620315d1-944d-4c36-b811-350dff90d902	username	user.attribute
620315d1-944d-4c36-b811-350dff90d902	true	id.token.claim
620315d1-944d-4c36-b811-350dff90d902	true	access.token.claim
620315d1-944d-4c36-b811-350dff90d902	upn	claim.name
620315d1-944d-4c36-b811-350dff90d902	String	jsonType.label
f973353b-059b-48c3-ac01-5c3f7acd2231	true	introspection.token.claim
f973353b-059b-48c3-ac01-5c3f7acd2231	true	multivalued
f973353b-059b-48c3-ac01-5c3f7acd2231	true	userinfo.token.claim
f973353b-059b-48c3-ac01-5c3f7acd2231	foo	user.attribute
f973353b-059b-48c3-ac01-5c3f7acd2231	true	id.token.claim
f973353b-059b-48c3-ac01-5c3f7acd2231	true	access.token.claim
f973353b-059b-48c3-ac01-5c3f7acd2231	groups	claim.name
f973353b-059b-48c3-ac01-5c3f7acd2231	String	jsonType.label
dc2b2bf6-7494-4d01-bcb8-abeae7f7929d	true	introspection.token.claim
dc2b2bf6-7494-4d01-bcb8-abeae7f7929d	true	multivalued
dc2b2bf6-7494-4d01-bcb8-abeae7f7929d	true	userinfo.token.claim
dc2b2bf6-7494-4d01-bcb8-abeae7f7929d	true	id.token.claim
dc2b2bf6-7494-4d01-bcb8-abeae7f7929d	true	access.token.claim
dc2b2bf6-7494-4d01-bcb8-abeae7f7929d	organization	claim.name
dc2b2bf6-7494-4d01-bcb8-abeae7f7929d	String	jsonType.label
4bee2fe5-cd5a-4743-9440-c23f355fcc07	false	single
4bee2fe5-cd5a-4743-9440-c23f355fcc07	Basic	attribute.nameformat
4bee2fe5-cd5a-4743-9440-c23f355fcc07	Role	attribute.name
958be64d-341c-400d-9e5c-89be252156bd	true	introspection.token.claim
958be64d-341c-400d-9e5c-89be252156bd	true	userinfo.token.claim
958be64d-341c-400d-9e5c-89be252156bd	phoneNumberVerified	user.attribute
958be64d-341c-400d-9e5c-89be252156bd	true	id.token.claim
958be64d-341c-400d-9e5c-89be252156bd	true	access.token.claim
958be64d-341c-400d-9e5c-89be252156bd	phone_number_verified	claim.name
958be64d-341c-400d-9e5c-89be252156bd	boolean	jsonType.label
d63288e6-4430-401b-94e7-810315c4dfd1	true	introspection.token.claim
d63288e6-4430-401b-94e7-810315c4dfd1	true	userinfo.token.claim
d63288e6-4430-401b-94e7-810315c4dfd1	phoneNumber	user.attribute
d63288e6-4430-401b-94e7-810315c4dfd1	true	id.token.claim
d63288e6-4430-401b-94e7-810315c4dfd1	true	access.token.claim
d63288e6-4430-401b-94e7-810315c4dfd1	phone_number	claim.name
d63288e6-4430-401b-94e7-810315c4dfd1	String	jsonType.label
4466894c-6c5e-4198-9384-a1037fd15e82	true	introspection.token.claim
4466894c-6c5e-4198-9384-a1037fd15e82	true	userinfo.token.claim
4466894c-6c5e-4198-9384-a1037fd15e82	emailVerified	user.attribute
4466894c-6c5e-4198-9384-a1037fd15e82	true	id.token.claim
4466894c-6c5e-4198-9384-a1037fd15e82	true	access.token.claim
4466894c-6c5e-4198-9384-a1037fd15e82	email_verified	claim.name
4466894c-6c5e-4198-9384-a1037fd15e82	boolean	jsonType.label
f6fb8d6b-0333-42c8-b2e1-1e8cb1e5fe40	true	introspection.token.claim
f6fb8d6b-0333-42c8-b2e1-1e8cb1e5fe40	true	userinfo.token.claim
f6fb8d6b-0333-42c8-b2e1-1e8cb1e5fe40	email	user.attribute
f6fb8d6b-0333-42c8-b2e1-1e8cb1e5fe40	true	id.token.claim
f6fb8d6b-0333-42c8-b2e1-1e8cb1e5fe40	true	access.token.claim
f6fb8d6b-0333-42c8-b2e1-1e8cb1e5fe40	email	claim.name
f6fb8d6b-0333-42c8-b2e1-1e8cb1e5fe40	String	jsonType.label
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	formatted	user.attribute.formatted
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	country	user.attribute.country
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	true	introspection.token.claim
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	postal_code	user.attribute.postal_code
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	true	userinfo.token.claim
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	street	user.attribute.street
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	true	id.token.claim
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	region	user.attribute.region
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	true	access.token.claim
0ebcb706-07b8-4dff-b7dd-9a55a86ee305	locality	user.attribute.locality
d8f9c70d-d33d-4d01-8bb1-76c4e59cfcf4	true	id.token.claim
d8f9c70d-d33d-4d01-8bb1-76c4e59cfcf4	true	access.token.claim
d8f9c70d-d33d-4d01-8bb1-76c4e59cfcf4	true	introspection.token.claim
d8f9c70d-d33d-4d01-8bb1-76c4e59cfcf4	true	userinfo.token.claim
0334ac7c-25ed-451a-b5e2-9c705b241286	true	introspection.token.claim
0334ac7c-25ed-451a-b5e2-9c705b241286	true	access.token.claim
4d9b65ab-4f30-4c31-bf63-4d3a74820b5e	foo	user.attribute
4d9b65ab-4f30-4c31-bf63-4d3a74820b5e	true	introspection.token.claim
4d9b65ab-4f30-4c31-bf63-4d3a74820b5e	true	access.token.claim
4d9b65ab-4f30-4c31-bf63-4d3a74820b5e	resource_access.${client_id}.roles	claim.name
4d9b65ab-4f30-4c31-bf63-4d3a74820b5e	String	jsonType.label
4d9b65ab-4f30-4c31-bf63-4d3a74820b5e	true	multivalued
a7dd6972-ccaf-42a1-a5b2-e170e1124ed3	foo	user.attribute
a7dd6972-ccaf-42a1-a5b2-e170e1124ed3	true	introspection.token.claim
a7dd6972-ccaf-42a1-a5b2-e170e1124ed3	true	access.token.claim
a7dd6972-ccaf-42a1-a5b2-e170e1124ed3	realm_access.roles	claim.name
a7dd6972-ccaf-42a1-a5b2-e170e1124ed3	String	jsonType.label
a7dd6972-ccaf-42a1-a5b2-e170e1124ed3	true	multivalued
3a8a61c9-c442-4567-95f0-7938b4252913	true	introspection.token.claim
3a8a61c9-c442-4567-95f0-7938b4252913	true	userinfo.token.claim
3a8a61c9-c442-4567-95f0-7938b4252913	true	id.token.claim
3a8a61c9-c442-4567-95f0-7938b4252913	false	lightweight.claim
3a8a61c9-c442-4567-95f0-7938b4252913	true	access.token.claim
3a8a61c9-c442-4567-95f0-7938b4252913	teams	claim.name
3a8a61c9-c442-4567-95f0-7938b4252913	JSON	jsonType.label
3a8a61c9-c442-4567-95f0-7938b4252913	false	access.tokenResponse.claim
94e16377-3c5f-468d-9718-e3ceb35d804d	true	access.token.claim
94e16377-3c5f-468d-9718-e3ceb35d804d	true	introspection.token.claim
d456da75-34e6-4a0e-bcd3-217c89c18918	true	introspection.token.claim
d456da75-34e6-4a0e-bcd3-217c89c18918	true	userinfo.token.claim
d456da75-34e6-4a0e-bcd3-217c89c18918	locale	user.attribute
d456da75-34e6-4a0e-bcd3-217c89c18918	true	id.token.claim
d456da75-34e6-4a0e-bcd3-217c89c18918	true	access.token.claim
d456da75-34e6-4a0e-bcd3-217c89c18918	locale	claim.name
d456da75-34e6-4a0e-bcd3-217c89c18918	String	jsonType.label
3a8a61c9-c442-4567-95f0-7938b4252913	["67d0aeb17172416c411d419e","67d0aec77172416c411d419f","69449d71588729179bf2f0aa"]	claim.value
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
fa932e74-3d72-4028-b476-3620d13514ce	60	300	300				t	f	0	linqra-theme	Linqra	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	7b932313-b8f6-4d43-a1c1-ed146786e0c0	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	803ca1fd-289a-4c54-b30c-04718c0df84e	adc517ec-2579-46f0-890a-0767e4164933	90c1ffd5-ef3f-44b6-928f-a5329357ae09	d3cab41a-a046-47fa-82bd-102f2eaa30bd	68c9a0f5-5a94-41de-994e-1d42d0bed85f	2592000	f	900	t	f	0b39e949-21bd-421d-b721-5a3b57f6c368	0	f	0	0	45609a37-719b-40d8-bcc8-e4e9cc614416
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	14d66edd-004a-4fd0-af78-44f38b17dd06	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	067cc22b-8326-4b60-b59b-fa2ca639a9fd	eddeb59f-2cfa-43b4-98bd-a28132ec8573	05ed9dde-a791-4d92-ba9c-65e0d1ddd305	bcd57c27-8337-4762-834b-38901958e885	2f6cc1e2-d37b-4a08-8442-7ba42bc2a4d8	2592000	f	900	t	f	38fd801f-4567-4956-b0df-fa5af6202886	0	f	0	0	1b500e6d-2a2e-4210-b0b9-4abd2cad2a1d
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	
_browser_header.xContentTypeOptions	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	nosniff
_browser_header.referrerPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	no-referrer
_browser_header.xRobotsTag	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	none
_browser_header.xFrameOptions	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	SAMEORIGIN
_browser_header.contentSecurityPolicy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.strictTransportSecurity	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	max-age=31536000; includeSubDomains
bruteForceProtected	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	false
permanentLockout	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	false
maxTemporaryLockouts	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	0
bruteForceStrategy	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	MULTIPLE
maxFailureWaitSeconds	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	900
minimumQuickLoginWaitSeconds	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	60
waitIncrementSeconds	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	60
quickLoginCheckMilliSeconds	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	1000
maxDeltaTimeSeconds	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	43200
failureFactor	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	30
realmReusableOtpCode	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	false
firstBrokerLoginFlowId	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	4773322d-ee6d-4a8f-ad31-6612a80030f1
displayName	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	Keycloak
displayNameHtml	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	RS256
offlineSessionMaxLifespanEnabled	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	false
offlineSessionMaxLifespan	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	5184000
_browser_header.contentSecurityPolicyReportOnly	fa932e74-3d72-4028-b476-3620d13514ce	
_browser_header.xContentTypeOptions	fa932e74-3d72-4028-b476-3620d13514ce	nosniff
_browser_header.referrerPolicy	fa932e74-3d72-4028-b476-3620d13514ce	no-referrer
_browser_header.xRobotsTag	fa932e74-3d72-4028-b476-3620d13514ce	none
_browser_header.xFrameOptions	fa932e74-3d72-4028-b476-3620d13514ce	SAMEORIGIN
_browser_header.contentSecurityPolicy	fa932e74-3d72-4028-b476-3620d13514ce	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.strictTransportSecurity	fa932e74-3d72-4028-b476-3620d13514ce	max-age=31536000; includeSubDomains
bruteForceProtected	fa932e74-3d72-4028-b476-3620d13514ce	false
permanentLockout	fa932e74-3d72-4028-b476-3620d13514ce	false
maxTemporaryLockouts	fa932e74-3d72-4028-b476-3620d13514ce	0
bruteForceStrategy	fa932e74-3d72-4028-b476-3620d13514ce	MULTIPLE
maxFailureWaitSeconds	fa932e74-3d72-4028-b476-3620d13514ce	900
minimumQuickLoginWaitSeconds	fa932e74-3d72-4028-b476-3620d13514ce	60
waitIncrementSeconds	fa932e74-3d72-4028-b476-3620d13514ce	60
quickLoginCheckMilliSeconds	fa932e74-3d72-4028-b476-3620d13514ce	1000
maxDeltaTimeSeconds	fa932e74-3d72-4028-b476-3620d13514ce	43200
failureFactor	fa932e74-3d72-4028-b476-3620d13514ce	30
realmReusableOtpCode	fa932e74-3d72-4028-b476-3620d13514ce	false
displayName	fa932e74-3d72-4028-b476-3620d13514ce	Linqra
displayNameHtml	fa932e74-3d72-4028-b476-3620d13514ce	
defaultSignatureAlgorithm	fa932e74-3d72-4028-b476-3620d13514ce	RS256
offlineSessionMaxLifespanEnabled	fa932e74-3d72-4028-b476-3620d13514ce	false
offlineSessionMaxLifespan	fa932e74-3d72-4028-b476-3620d13514ce	5184000
clientSessionIdleTimeout	fa932e74-3d72-4028-b476-3620d13514ce	0
clientSessionMaxLifespan	fa932e74-3d72-4028-b476-3620d13514ce	0
clientOfflineSessionIdleTimeout	fa932e74-3d72-4028-b476-3620d13514ce	0
clientOfflineSessionMaxLifespan	fa932e74-3d72-4028-b476-3620d13514ce	0
actionTokenGeneratedByAdminLifespan	fa932e74-3d72-4028-b476-3620d13514ce	43200
actionTokenGeneratedByUserLifespan	fa932e74-3d72-4028-b476-3620d13514ce	300
oauth2DeviceCodeLifespan	fa932e74-3d72-4028-b476-3620d13514ce	600
oauth2DevicePollingInterval	fa932e74-3d72-4028-b476-3620d13514ce	5
organizationsEnabled	fa932e74-3d72-4028-b476-3620d13514ce	false
adminPermissionsEnabled	fa932e74-3d72-4028-b476-3620d13514ce	false
webAuthnPolicyRpEntityName	fa932e74-3d72-4028-b476-3620d13514ce	keycloak
webAuthnPolicySignatureAlgorithms	fa932e74-3d72-4028-b476-3620d13514ce	ES256,RS256
webAuthnPolicyRpId	fa932e74-3d72-4028-b476-3620d13514ce	
webAuthnPolicyAttestationConveyancePreference	fa932e74-3d72-4028-b476-3620d13514ce	not specified
webAuthnPolicyAuthenticatorAttachment	fa932e74-3d72-4028-b476-3620d13514ce	not specified
webAuthnPolicyRequireResidentKey	fa932e74-3d72-4028-b476-3620d13514ce	not specified
webAuthnPolicyUserVerificationRequirement	fa932e74-3d72-4028-b476-3620d13514ce	not specified
webAuthnPolicyCreateTimeout	fa932e74-3d72-4028-b476-3620d13514ce	0
webAuthnPolicyAvoidSameAuthenticatorRegister	fa932e74-3d72-4028-b476-3620d13514ce	false
webAuthnPolicyRpEntityNamePasswordless	fa932e74-3d72-4028-b476-3620d13514ce	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	fa932e74-3d72-4028-b476-3620d13514ce	ES256,RS256
webAuthnPolicyRpIdPasswordless	fa932e74-3d72-4028-b476-3620d13514ce	
webAuthnPolicyAttestationConveyancePreferencePasswordless	fa932e74-3d72-4028-b476-3620d13514ce	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	fa932e74-3d72-4028-b476-3620d13514ce	not specified
webAuthnPolicyRequireResidentKeyPasswordless	fa932e74-3d72-4028-b476-3620d13514ce	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	fa932e74-3d72-4028-b476-3620d13514ce	not specified
webAuthnPolicyCreateTimeoutPasswordless	fa932e74-3d72-4028-b476-3620d13514ce	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	fa932e74-3d72-4028-b476-3620d13514ce	false
cibaBackchannelTokenDeliveryMode	fa932e74-3d72-4028-b476-3620d13514ce	poll
cibaExpiresIn	fa932e74-3d72-4028-b476-3620d13514ce	120
cibaInterval	fa932e74-3d72-4028-b476-3620d13514ce	5
cibaAuthRequestedUserHint	fa932e74-3d72-4028-b476-3620d13514ce	login_hint
parRequestUriLifespan	fa932e74-3d72-4028-b476-3620d13514ce	60
firstBrokerLoginFlowId	fa932e74-3d72-4028-b476-3620d13514ce	8684d5c1-cd79-4cf7-82cb-1180982b96f4
saml.signature.algorithm	fa932e74-3d72-4028-b476-3620d13514ce	
acr.loa.map	fa932e74-3d72-4028-b476-3620d13514ce	{}
verifiableCredentialsEnabled	fa932e74-3d72-4028-b476-3620d13514ce	false
client-policies.profiles	fa932e74-3d72-4028-b476-3620d13514ce	{"profiles":[]}
client-policies.policies	fa932e74-3d72-4028-b476-3620d13514ce	{"policies":[]}
darkMode	fa932e74-3d72-4028-b476-3620d13514ce	true
frontendUrl	fa932e74-3d72-4028-b476-3620d13514ce	http://localhost:8281
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
064b05aa-b123-4727-a3ba-cbcb0f63c5d5	jboss-logging
fa932e74-3d72-4028-b476-3620d13514ce	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	064b05aa-b123-4727-a3ba-cbcb0f63c5d5
password	password	t	t	fa932e74-3d72-4028-b476-3620d13514ce
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.redirect_uris (client_id, value) FROM stdin;
e685bf33-6dc9-45b6-b45e-0613070a3f57	/realms/master/account/*
43b0209c-b0f6-48fd-b331-172944afaab9	/realms/master/account/*
8395b40e-acfd-4834-b2bd-605b68e96a3c	/admin/master/console/*
a64e78ff-429f-461c-85ca-11095df7667f	/realms/Linqra/account/*
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	/realms/Linqra/account/*
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	/admin/Linqra/console/*
c6f5ede9-6791-43d3-8430-f485361bf7d5	https://localhost:3000/callback
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
7c92d7ce-625f-40d2-8c8c-aac948578a42	VERIFY_EMAIL	Verify Email	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	VERIFY_EMAIL	50
8d7767b1-b0ef-45be-b07d-8984beb026af	UPDATE_PROFILE	Update Profile	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	UPDATE_PROFILE	40
96883dd8-3b0a-4e49-a9c3-3a44fb261e2c	CONFIGURE_TOTP	Configure OTP	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	CONFIGURE_TOTP	10
a446d4a3-7eef-4bd4-a2a3-f97679cb0a86	UPDATE_PASSWORD	Update Password	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	UPDATE_PASSWORD	30
3eb1b6d8-2b7a-410c-82ed-bcfe10af43a6	TERMS_AND_CONDITIONS	Terms and Conditions	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	f	f	TERMS_AND_CONDITIONS	20
803af77e-b635-4660-8116-437272da2640	delete_account	Delete Account	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	f	f	delete_account	60
2a2e3c6a-8a37-43ad-819b-c2e1a2d7f292	delete_credential	Delete Credential	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	delete_credential	110
b005109a-00c1-4105-abb7-fdfb11240e45	update_user_locale	Update User Locale	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	update_user_locale	1000
99074632-14d1-4cce-b6cb-6fad6478276c	UPDATE_EMAIL	Update Email	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	f	f	UPDATE_EMAIL	70
a72453b8-fa24-4fc8-9359-ed76d4acd220	CONFIGURE_RECOVERY_AUTHN_CODES	Recovery Authentication Codes	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	CONFIGURE_RECOVERY_AUTHN_CODES	130
79b49aa7-5a17-47a6-a7bb-44be4ec74c9a	webauthn-register	Webauthn Register	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	webauthn-register	80
e5208ad3-9653-4300-a11a-972d8e4ec4fb	webauthn-register-passwordless	Webauthn Register Passwordless	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	webauthn-register-passwordless	90
8ee7de77-001a-4aab-8c0a-ba8a335195b8	VERIFY_PROFILE	Verify Profile	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	VERIFY_PROFILE	100
4e1c09ae-3f00-44b0-aaba-e045520a5c62	idp_link	Linking Identity Provider	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	t	f	idp_link	120
7248ea50-27d1-4684-9415-5e356625b9fb	CONFIGURE_TOTP	Configure OTP	fa932e74-3d72-4028-b476-3620d13514ce	t	f	CONFIGURE_TOTP	10
c7d75f48-bf51-4a03-a9ac-59b24a2dd417	TERMS_AND_CONDITIONS	Terms and Conditions	fa932e74-3d72-4028-b476-3620d13514ce	f	f	TERMS_AND_CONDITIONS	20
0eb61dad-ff93-4a79-bb17-2c3b9ad4f30a	UPDATE_PASSWORD	Update Password	fa932e74-3d72-4028-b476-3620d13514ce	t	f	UPDATE_PASSWORD	30
4b93fcb6-aa39-4127-99e4-0b605c8de713	UPDATE_PROFILE	Update Profile	fa932e74-3d72-4028-b476-3620d13514ce	t	f	UPDATE_PROFILE	40
bd3be2b8-8f19-40e6-a013-530181c095c9	VERIFY_EMAIL	Verify Email	fa932e74-3d72-4028-b476-3620d13514ce	t	f	VERIFY_EMAIL	50
eda9750a-763c-44f2-99f4-340de3c7b5c8	delete_account	Delete Account	fa932e74-3d72-4028-b476-3620d13514ce	f	f	delete_account	60
e0b36024-5a9e-454e-8550-c8a9404ab4a9	webauthn-register	Webauthn Register	fa932e74-3d72-4028-b476-3620d13514ce	t	f	webauthn-register	70
bab126be-68bc-489f-b2f9-26ffe21d6b6d	webauthn-register-passwordless	Webauthn Register Passwordless	fa932e74-3d72-4028-b476-3620d13514ce	t	f	webauthn-register-passwordless	80
e36cae41-06d6-4944-8da0-8c08c2116c6f	VERIFY_PROFILE	Verify Profile	fa932e74-3d72-4028-b476-3620d13514ce	t	f	VERIFY_PROFILE	90
8537e96e-50f2-4d93-badb-940eda928caf	delete_credential	Delete Credential	fa932e74-3d72-4028-b476-3620d13514ce	t	f	delete_credential	100
ddc7374c-e567-48d9-a90b-021ac22ec902	idp_link	Linking Identity Provider	fa932e74-3d72-4028-b476-3620d13514ce	t	f	idp_link	110
ffa61ae9-e460-4958-8b58-5633895f1132	CONFIGURE_RECOVERY_AUTHN_CODES	Recovery Authentication Codes	fa932e74-3d72-4028-b476-3620d13514ce	t	f	CONFIGURE_RECOVERY_AUTHN_CODES	120
78d74634-e066-4718-a702-e739283e54eb	update_user_locale	Update User Locale	fa932e74-3d72-4028-b476-3620d13514ce	t	f	update_user_locale	1000
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: revoked_token; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.revoked_token (id, expire) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
43b0209c-b0f6-48fd-b331-172944afaab9	7dd2f528-14d0-4254-8df6-e0a8ae7f2722
43b0209c-b0f6-48fd-b331-172944afaab9	9d14fd06-b39e-4f9a-8fa5-e010efd2f9a6
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	43fc98b5-72ce-4e2e-872e-d4e3d4043833
ed6202d2-06e0-4bbc-ae49-1fab28b49bfe	31394836-54ec-4ed7-b108-bdef64964f48
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: server_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.server_config (server_config_key, value, version) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_attribute (name, value, user_id, id, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
is_temporary_admin	true	8697b1cc-57e8-4536-88d8-d6cf67d29485	bd33ea04-f75d-4706-8f0c-0dea48b167a7	\N	\N	\N
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
8697b1cc-57e8-4536-88d8-d6cf67d29485	\N	be982c7a-d3ac-4c06-a195-0c11a180b840	f	t	\N	\N	\N	064b05aa-b123-4727-a3ba-cbcb0f63c5d5	admin	1759688369188	\N	0
a26cb2b9-8681-45d6-a486-5440522ceae4	\N	c3ea8c81-b75a-411f-9266-2040ed789b3b	f	t	\N	\N	\N	fa932e74-3d72-4028-b476-3620d13514ce	service-account-linqra-gateway-client	1759199833235	c6f5ede9-6791-43d3-8430-f485361bf7d5	0
bba243e8-4c79-4da5-8063-667c7e041b0e	mehmetsen80@hotmail.com	mehmetsen80@hotmail.com	t	t	\N	Mehmet Timur	Se n	fa932e74-3d72-4028-b476-3620d13514ce	timursen	1759689398440	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_group_membership (group_id, user_id, membership_type) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
1b500e6d-2a2e-4210-b0b9-4abd2cad2a1d	8697b1cc-57e8-4536-88d8-d6cf67d29485
e06df0b5-75b3-461f-a4f8-60c9e33ebc6d	8697b1cc-57e8-4536-88d8-d6cf67d29485
45609a37-719b-40d8-bcc8-e4e9cc614416	a26cb2b9-8681-45d6-a486-5440522ceae4
8df9234a-22b6-496e-817f-f02ffcf641ca	a26cb2b9-8681-45d6-a486-5440522ceae4
fa8d2230-c1a1-4b74-ab06-054303837057	a26cb2b9-8681-45d6-a486-5440522ceae4
45609a37-719b-40d8-bcc8-e4e9cc614416	bba243e8-4c79-4da5-8063-667c7e041b0e
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.web_origins (client_id, value) FROM stdin;
8395b40e-acfd-4834-b2bd-605b68e96a3c	+
b7e45a00-20df-4e74-b038-b5dbc6e46e8a	+
c6f5ede9-6791-43d3-8430-f485361bf7d5	https://localhost:3000
\.


--
-- Data for Name: workflow_state; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.workflow_state (execution_id, resource_id, workflow_id, workflow_provider_id, resource_type, scheduled_step_id, scheduled_step_timestamp) FROM stdin;
\.


--
-- Name: org_domain ORG_DOMAIN_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.org_domain
    ADD CONSTRAINT "ORG_DOMAIN_pkey" PRIMARY KEY (id, name);


--
-- Name: org ORG_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT "ORG_pkey" PRIMARY KEY (id);


--
-- Name: server_config SERVER_CONFIG_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.server_config
    ADD CONSTRAINT "SERVER_CONFIG_pkey" PRIMARY KEY (server_config_key);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: jgroups_ping constraint_jgroups_ping; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.jgroups_ping
    ADD CONSTRAINT constraint_jgroups_ping PRIMARY KEY (address);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: revoked_token constraint_rt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.revoked_token
    ADD CONSTRAINT constraint_rt PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: workflow_state pk_workflow_state; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.workflow_state
    ADD CONSTRAINT pk_workflow_state PRIMARY KEY (execution_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: user_consent uk_external_consent; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_external_consent UNIQUE (client_storage_provider, external_client_id, user_id);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_local_consent; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_local_consent UNIQUE (client_id, user_id);


--
-- Name: migration_model uk_migration_update_time; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT uk_migration_update_time UNIQUE (update_time);


--
-- Name: migration_model uk_migration_version; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT uk_migration_version UNIQUE (version);


--
-- Name: org uk_org_alias; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_alias UNIQUE (realm_id, alias);


--
-- Name: org uk_org_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_group UNIQUE (group_id);


--
-- Name: org uk_org_name; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_name UNIQUE (realm_id, name);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: workflow_state uq_workflow_resource; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.workflow_state
    ADD CONSTRAINT uq_workflow_resource UNIQUE (workflow_id, resource_id);


--
-- Name: fed_user_attr_long_values; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX fed_user_attr_long_values ON public.fed_user_attribute USING btree (long_value_hash, name);


--
-- Name: fed_user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX fed_user_attr_long_values_lower_case ON public.fed_user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_att_by_name_value; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_att_by_name_value ON public.client_attributes USING btree (name, substr(value, 1, 255));


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_entity_user_id_type; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_event_entity_user_id_type ON public.event_entity USING btree (user_id, type, event_time);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_idp_for_login; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_idp_for_login ON public.identity_provider USING btree (realm_id, enabled, link_only, hide_on_login, organization_id);


--
-- Name: idx_idp_realm_org; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_idp_realm_org ON public.identity_provider USING btree (realm_id, organization_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_by_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_css_by_client ON public.offline_client_session USING btree (client_id, offline_flag) WHERE ((client_id)::text <> 'external'::text);


--
-- Name: idx_offline_css_by_client_storage_provider; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_css_by_client_storage_provider ON public.offline_client_session USING btree (client_storage_provider, external_client_id, offline_flag) WHERE ((client_storage_provider)::text <> 'internal'::text);


--
-- Name: idx_offline_uss_by_broker_session_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_broker_session_id ON public.offline_user_session USING btree (broker_session_id, realm_id);


--
-- Name: idx_offline_uss_by_last_session_refresh; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_last_session_refresh ON public.offline_user_session USING btree (realm_id, offline_flag, last_session_refresh);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_org_domain_org_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_org_domain_org_id ON public.org_domain USING btree (org_id);


--
-- Name: idx_perm_ticket_owner; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_perm_ticket_owner ON public.resource_server_perm_ticket USING btree (owner);


--
-- Name: idx_perm_ticket_requester; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_perm_ticket_requester ON public.resource_server_perm_ticket USING btree (requester);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_rev_token_on_expire; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_rev_token_on_expire ON public.revoked_token USING btree (expire);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_usconsent_scope_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usconsent_scope_id ON public.user_consent_client_scope USING btree (scope_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: idx_workflow_state_provider; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_workflow_state_provider ON public.workflow_state USING btree (resource_id, workflow_provider_id);


--
-- Name: idx_workflow_state_step; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_workflow_state_step ON public.workflow_state USING btree (workflow_id, scheduled_step_id);


--
-- Name: user_attr_long_values; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX user_attr_long_values ON public.user_attribute USING btree (long_value_hash, name);


--
-- Name: user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX user_attr_long_values_lower_case ON public.user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

\unrestrict 3ZuAg1mdX4e3qBrBIuw7ZHS6XECsgWbFEzmxigs4BC6Z8GrNCkAZsXXiIVMwTBW

